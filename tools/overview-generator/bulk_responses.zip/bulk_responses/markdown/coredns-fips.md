**Container Documentation for Coredns-Fips**

CoreDNS-FIPS is a FIPS 140-2 compliant DNS server that provides flexible and extensible DNS services for containerized environments. It features plugin architecture, high performance, and security-hardened configuration suitable for enterprise and government deployments requiring FIPS compliance.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/coredns-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Plugin-based architecture for extensibility
- Native Kubernetes integration
- High-performance DNS resolution

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster DNS service
- Enterprise DNS infrastructure
- Government and regulated environments
- Service discovery in microservices

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/coredns-fips:latest
```

```bash
docker pull {registry.example.com}/coredns-fips:1.9.3-fips
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name coredns-fips \
  -p 53:53/udp \
  -p 53:53/tcp \
  {registry.example.com}/coredns-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name coredns-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -p 53:53/udp \
  -p 53:53/tcp \
  -v $(pwd)/Corefile:/Corefile:ro \
  {registry.example.com}/coredns-fips:latest
```

**Volume Mount**
Mount configuration and zone files

```bash
docker run -v $(pwd)/Corefile:/Corefile:ro -v $(pwd)/zones:/zones:ro {registry.example.com}/coredns-fips:latest
```

**Port Forwarding**
Run with DNS ports exposed

```bash
docker run -p 53:53/udp -p 53:53/tcp {registry.example.com}/coredns-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| COREDNS_FIPS_MODE | enabled | Enable/disable FIPS mode |
| DNS_PORT | 53 | DNS service port |
| COREFILE | /Corefile | CoreDNS configuration file path |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use read-only filesystem mounts
- Implement proper access controls
- Regular security updates and patches
- Monitor DNS query logs
- Configure DNSSEC where appropriate

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    add: ["NET_BIND_SERVICE"]
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **CoreDNS Documentation**: https://coredns.io/manual/toc/
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance