**Container Documentation for Consul-Fips**

HashiCorp Consul container image with FIPS 140-2 compliance for secure service networking in regulated environments. Features service discovery, health checking, and secure service-to-service communication with FIPS-validated cryptographic modules.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/consul-fips`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Service mesh and service discovery capabilities
- Advanced health checking and monitoring
- Zero-trust network architecture support

**Common Use Cases**
Typical scenarios where this container excels

- Government and regulated industry deployments
- Healthcare and financial services infrastructure
- Secure service networking in enterprise environments
- Compliance-focused microservices architecture

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/consul-fips:latest
```

```bash
docker pull registry.example.com/consul-fips:1.16-fips
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name consul-fips -p 8500:8500 registry.example.com/consul-fips:latest agent -dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name consul-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user consul:consul \
  -v consul-data:/consul/data \
  -v consul-config:/consul/config \
  registry.example.com/consul-fips:latest agent -server -bootstrap-expect=1
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d -v $(pwd)/consul-data:/consul/data -v $(pwd)/consul-config:/consul/config registry.example.com/consul-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d -p 8500:8500 -p 8600:8600/udp registry.example.com/consul-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CONSUL_HTTP_ADDR | http://localhost:8500 | HTTP API address |
| CONSUL_HTTP_TOKEN |  | ACL token for API access |
| CONSUL_DATACENTER | dc1 | Datacenter name |
| CONSUL_ENCRYPT |  | Encryption key for gossip |

**Security Best Practices**
Recommended security configurations and practices

- Enable ACLs in production environments
- Use TLS for all communication
- Implement gossip encryption
- Regular rotation of encryption keys
- Configure secure token handling
- Enable audit logging
- Use dedicated service accounts
- Regular security updates and patches

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 100
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/consul-fips
- **FIPS Compliance Documentation**: https://registry.example.com/docs/fips