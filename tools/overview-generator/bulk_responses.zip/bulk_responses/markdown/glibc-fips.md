**Container Documentation for Glibc-Fips**

Enterprise-grade FIPS 140-2 compliant GNU C Library (glibc) container image providing cryptographic modules and security-hardened runtime environment for regulated industries and government applications. Features NIST-validated cryptographic implementations, STIG compliance, and optimized performance for mission-critical workloads.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/glibc-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- Optimized performance for enterprise workloads
- Multi-architecture support (amd64/arm64)

**Common Use Cases**
Typical scenarios where this container excels

- Government and military applications
- Financial services and banking systems
- Healthcare information systems
- Regulated industry deployments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/glibc-fips:latest
```

```bash
docker pull {registry.example.com}/glibc-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name glibc-fips-test {registry.example.com}/glibc-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name glibc-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/glibc-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/glibc-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/glibc-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FIPS_MODE | 1 | Enable/disable FIPS mode (1/0) |
| FIPS_POLICY | strict | FIPS policy enforcement level |
| CRYPTO_POLICY | FIPS:OSPP | System-wide crypto policy |
| STIG_PROFILE | high | STIG compliance profile |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled before deployment
- Implement strict access controls and audit logging
- Regular security compliance scanning
- Monitor cryptographic operations for compliance
- Maintain up-to-date security patches
- Follow STIG hardening guidelines

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/glibc-fips
- **FIPS 140-2 Certification**: https://csrc.nist.gov/projects/cryptographic-module-validation-program