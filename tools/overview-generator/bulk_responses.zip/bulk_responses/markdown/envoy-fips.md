**Container Documentation for Envoy-Fips**

FIPS-compliant Envoy proxy container optimized for secure enterprise environments. Features FIPS 140-2 validated cryptographic modules, STIG-hardened configuration, and enhanced security controls for regulated industries requiring strict compliance standards. Ideal for government, healthcare, and financial services deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/envoy-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configuration
- Enhanced access control and logging
- Zero-trust security architecture support

**Common Use Cases**
Typical scenarios where this container excels

- Government and military deployments
- Healthcare and HIPAA-compliant environments
- Financial services infrastructure
- Regulated industry applications

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/envoy-fips:latest
```

```bash
docker pull {registry.example.com}/envoy-fips:1.26-stable
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name envoy-proxy {registry.example.com}/envoy-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name envoy-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --cap-drop=ALL \
  --user 1000:1000 \
  -v $(pwd)/config:/etc/envoy \
  {registry.example.com}/envoy-fips:latest
```

**Volume Mount**
Mount configuration and certificates

```bash
docker run -v $(pwd)/config:/etc/envoy -v $(pwd)/certs:/etc/certs {registry.example.com}/envoy-fips:latest
```

**Port Forwarding**
Run with standard Envoy ports

```bash
docker run -p 8080:8080 -p 8443:8443 -p 9901:9901 {registry.example.com}/envoy-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ENVOY_CONFIG_PATH | /etc/envoy/envoy.yaml | Path to Envoy configuration file |
| ENVOY_LOG_LEVEL | info | Logging level (trace, debug, info, warning, error, critical) |
| ENVOY_CONCURRENCY | 2 | Number of worker threads |
| ENVOY_ADMIN_PORT | 9901 | Admin interface port |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled and functioning
- Implement TLS 1.2/1.3 for all connections
- Configure access logging for audit requirements
- Use secure certificate management
- Enable rate limiting for DDoS protection
- Implement proper authentication mechanisms
- Regular security scanning and updates
- Monitor security metrics and alerts

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Security Documentation**: https://{registry.example.com}/envoy-fips/security
- **FIPS Compliance**: https://{registry.example.com}/envoy-fips/fips-compliance