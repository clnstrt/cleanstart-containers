**Container Documentation for Curl-Fips**

FIPS-validated cURL container image providing secure file transfer and API interaction capabilities. Built with FIPS 140-2 compliant cryptographic modules and security-hardened configuration for enterprise environments requiring regulatory compliance.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/curl-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Security-hardened base configuration
- Multi-protocol support (HTTP, HTTPS, FTP, FTPS, SCP, SFTP, etc.)
- Enterprise-ready SSL/TLS implementation

**Common Use Cases**
Typical scenarios where this container excels

- Secure file transfers in regulated environments
- API testing and integration in FIPS-compliant systems
- Automated security testing and validation
- Secure data transfer in CI/CD pipelines

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/curl-fips:latest
```

```bash
docker pull {registry.example.com}/curl-fips:1.0.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name curl-fips-test {registry.example.com}/curl-fips:latest curl https://api.example.com
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name curl-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  --cap-drop ALL \
  {registry.example.com}/curl-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/certs:/etc/ssl/certs:ro -v $(pwd)/output:/output {registry.example.com}/curl-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/curl-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CURL_CA_BUNDLE | /etc/ssl/certs/ca-certificates.crt | Custom CA certificate bundle path |
| SSL_CERT_DIR | /etc/ssl/certs | SSL certificate directory |
| CURL_VERBOSE | 0 | Enable verbose output (1=enabled, 0=disabled) |
| CURL_TIMEOUT | 60 | Default operation timeout in seconds |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled before production use
- Use custom CA certificates for enhanced security
- Implement proper certificate validation
- Regular security patch updates
- Monitor for compliance violations
- Implement proper access controls
- Use secure protocols (HTTPS, SFTP) only
- Regular security audits and logging

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/curl-fips
- **FIPS Validation**: https://{registry.example.com}/security/fips