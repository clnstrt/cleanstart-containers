**Container Documentation for External-Secrets-Fips**

External Secrets Operator FIPS-validated container for secure management of external secrets in Kubernetes environments. This container enables secure integration with various external secret management systems while maintaining FIPS 140-2 compliance for enterprise security requirements.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/external-secrets-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Secure external secrets management for Kubernetes
- Integration with multiple secret backend providers
- Automated secret synchronization and rotation

**Common Use Cases**
Typical scenarios where this container excels

- Enterprise Kubernetes secret management
- Regulated industry compliance requirements
- Cloud-native security implementations
- Multi-cloud secrets orchestration

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/external-secrets-fips:latest
```

```bash
docker pull {registry.example.com}/external-secrets-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name external-secrets-fips-test {registry.example.com}/external-secrets-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name external-secrets-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/external-secrets-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/external-secrets {registry.example.com}/external-secrets-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 3000:3000 {registry.example.com}/external-secrets-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| EXTERNAL_SECRETS_BACKEND | vault | Secret backend provider (vault, aws, gcp, azure) |
| EXTERNAL_SECRETS_NAMESPACE | default | Kubernetes namespace for operation |
| LOG_LEVEL | info | Logging level configuration |
| METRICS_PORT | 3000 | Port for metrics endpoint |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies to restrict access to secrets
- Enable audit logging for all secret access
- Implement secret rotation policies
- Use separate namespaces for different environments
- Regular security scanning of container images
- Monitor for unauthorized access attempts
- Implement network policies for pod communication
- Use encrypted communication channels

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/external-secrets-fips
- **Security Compliance**: https://{registry.example.com}/security/fips