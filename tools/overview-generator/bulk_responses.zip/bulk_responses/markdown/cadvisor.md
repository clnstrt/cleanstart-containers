**Container Documentation for Cadvisor**

cAdvisor (Container Advisor) provides container users an understanding of the resource usage and performance characteristics of their running containers. It is a running daemon that collects, aggregates, processes, and exports information about running containers. Specifically, for each container it keeps resource isolation parameters, historical resource usage, histograms of complete historical resource usage and network statistics.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cadvisor`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Real-time container resource usage metrics
- Historical resource usage statistics
- Network statistics monitoring
- Resource isolation parameter tracking

**Common Use Cases**
Typical scenarios where this container excels

- Container performance monitoring
- Resource usage analysis
- Container health monitoring
- Kubernetes cluster monitoring

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cadvisor:latest
```

```bash
docker pull {registry.example.com}/cadvisor:v0.47.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run \
  --volume=/:/rootfs:ro \
  --volume=/var/run:/var/run:ro \
  --volume=/sys:/sys:ro \
  --volume=/var/lib/docker/:/var/lib/docker:ro \
  --volume=/dev/disk/:/dev/disk:ro \
  --publish=8080:8080 \
  --detach=true \
  --name=cadvisor \
  {registry.example.com}/cadvisor:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cadvisor-prod \
  --volume=/:/rootfs:ro \
  --volume=/var/run:/var/run:ro \
  --volume=/sys:/sys:ro \
  --volume=/var/lib/docker/:/var/lib/docker:ro \
  --volume=/dev/disk/:/dev/disk:ro \
  --publish=8080:8080 \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cadvisor:latest
```

**Volume Mount**
Mount required system directories for monitoring

```bash
docker run \
  --volume=/:/rootfs:ro \
  --volume=/var/run:/var/run:ro \
  --volume=/sys:/sys:ro \
  --volume=/var/lib/docker/:/var/lib/docker:ro \
  --volume=/dev/disk/:/dev/disk:ro \
  {registry.example.com}/cadvisor:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:8080 {registry.example.com}/cadvisor:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CADVISOR_VERSION | v0.47.0 | Version of cAdvisor |
| PORT | 8080 | Port to listen on |
| STORAGE_DRIVER |  | Storage driver to use |
| STORAGE_DRIVER_HOST | localhost:8080 | Storage driver host |

**Security Best Practices**
Recommended security configurations and practices

- Mount filesystems as read-only
- Run container as non-root user
- Implement proper access controls
- Regular security updates
- Use specific version tags
- Configure resource limits
- Enable security options
- Monitor access logs

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["SYS_ADMIN"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cadvisor
- **GitHub Repository**: https://github.com/google/cadvisor