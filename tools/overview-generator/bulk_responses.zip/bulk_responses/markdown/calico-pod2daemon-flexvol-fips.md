**Container Documentation for Calico-Pod2Daemon-Flexvol-Fips**

Calico Pod2Daemon FlexVolume FIPS container provides secure volume management and pod-to-daemon communication for Calico networking in FIPS-compliant environments. It enables flexible volume mounting and secure data transfer between Kubernetes pods and node daemons while maintaining FIPS 140-2 compliance requirements.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-pod2daemon-flexvol-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant implementation
- Secure pod-to-daemon communication
- Flexible volume management capabilities
- Kubernetes integration support

**Common Use Cases**
Typical scenarios where this container excels

- FIPS-compliant Kubernetes deployments
- Secure container networking environments
- Government and regulated industry deployments
- Enterprise Kubernetes clusters

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-pod2daemon-flexvol-fips:latest
```

```bash
docker pull {registry.example.com}/calico-pod2daemon-flexvol-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-pod2daemon-flexvol-fips-test {registry.example.com}/calico-pod2daemon-flexvol-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-pod2daemon-flexvol-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/calico-pod2daemon-flexvol-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/calico-pod2daemon-flexvol-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/calico-pod2daemon-flexvol-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLEXVOL_DIR | /usr/libexec/kubernetes/kubelet-plugins/volume/exec/ | FlexVolume plugin directory |
| FIPS_MODE | enabled | FIPS mode configuration |
| LOG_LEVEL | info | Logging level configuration |
| NODE_NAME |  | Kubernetes node name |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS compliance requirements are met
- Use specific image tags for production deployments
- Configure appropriate security contexts
- Implement proper access controls
- Regular security audits and updates
- Monitor container security metrics

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-pod2daemon-flexvol-fips