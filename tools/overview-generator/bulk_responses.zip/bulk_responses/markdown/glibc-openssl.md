**Container Documentation for Glibc-Openssl**

Enterprise-grade container image providing glibc and OpenSSL libraries optimized for containerized applications. Features FIPS-compliant cryptographic modules, security hardening, and comprehensive SSL/TLS support for secure communications in cloud-native environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/glibc-openssl`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic modules
- Optimized glibc and OpenSSL runtime environment
- Security-hardened base configuration
- Multi-architecture support (amd64/arm64)

**Common Use Cases**
Typical scenarios where this container excels

- Secure communication in regulated environments
- SSL/TLS termination and encryption
- Base image for security-critical applications
- FIPS-compliant deployment requirements

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/glibc-openssl:latest
```

```bash
docker pull {registry.example.com}/glibc-openssl:fips
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name glibc-openssl-test {registry.example.com}/glibc-openssl:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name glibc-openssl-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/glibc-openssl:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/certs:/etc/ssl/certs {registry.example.com}/glibc-openssl:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 443:443 {registry.example.com}/glibc-openssl:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| OPENSSL_FIPS | 0 | Enable FIPS mode (1=enabled, 0=disabled) |
| SSL_CERT_DIR | /etc/ssl/certs | Directory containing trusted CA certificates |
| SSL_CERT_FILE | /etc/ssl/certs/ca-certificates.crt | Bundle of CA root certificates |

**Security Best Practices**
Recommended security configurations and practices

- Enable FIPS mode when required for compliance
- Regularly update SSL certificates and trust stores
- Implement proper certificate validation
- Use secure protocols (TLS 1.2/1.3) only
- Monitor SSL/TLS connections for security events
- Maintain up-to-date security patches

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/glibc-openssl
- **Security Advisories**: https://{registry.example.com}/security