**Container Documentation for Fluent-Bit-Fips**

Fluent Bit FIPS is a FIPS 140-2 compliant log processor and forwarder designed for enterprise environments requiring high security standards. This container provides fast and lightweight log processing with built-in support for multiple inputs and outputs, while maintaining FIPS compliance for government and regulated industry requirements.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/fluent-bit-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant logging operations
- High-performance log processing and forwarding
- Multiple input and output plugin support
- Stream processing and filtering capabilities

**Common Use Cases**
Typical scenarios where this container excels

- Government and military logging systems
- Healthcare data processing compliance
- Financial services log management
- Regulated industry monitoring solutions

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/fluent-bit-fips:latest
```

```bash
docker pull {registry.example.com}/fluent-bit-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name fluent-bit {registry.example.com}/fluent-bit-fips:latest -i cpu -o stdout
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name fluent-bit-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /path/to/config:/fluent-bit/etc \
  {registry.example.com}/fluent-bit-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/fluent-bit.conf:/fluent-bit/etc/fluent-bit.conf {registry.example.com}/fluent-bit-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 24224:24224 {registry.example.com}/fluent-bit-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLB_LOG_LEVEL | info | Logging level (debug, info, warn, error) |
| FLB_CONFIG_FILE | /fluent-bit/etc/fluent-bit.conf | Path to configuration file |
| FLB_PARSER_FILE | /fluent-bit/etc/parsers.conf | Path to parsers configuration file |
| FLB_FIPS_MODE | on | Enable/disable FIPS mode |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use TLS 1.2 or higher for all network communications
- Implement proper access controls for log files
- Regular security audits of logging configuration
- Monitor for unauthorized configuration changes
- Use secure protocols for log forwarding

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_BIND_SERVICE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/fluent-bit-fips
- **FIPS Compliance Documentation**: https://{registry.example.com}/docs/fips-compliance