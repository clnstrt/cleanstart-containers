**Container Documentation for Alpine-Socat-Fips**

A FIPS-compliant Alpine Linux container with socat networking utility, designed for secure network tunneling and port forwarding in enterprise environments. Features FIPS 140-2 validated cryptographic modules and STIG-hardened configuration for enhanced security compliance.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/alpine-socat-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security hardening
- Minimal Alpine Linux base for reduced attack surface
- Integrated socat networking utility for secure tunneling

**Common Use Cases**
Typical scenarios where this container excels

- Secure network tunneling in regulated environments
- Port forwarding with FIPS-compliant encryption
- TCP/UDP relay in high-security deployments
- Protocol translation for legacy systems

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/alpine-socat-fips:latest
```

```bash
docker pull {registry.example.com}/alpine-socat-fips:1.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name socat-relay {registry.example.com}/alpine-socat-fips:latest socat TCP-LISTEN:8080,fork TCP:destination:80
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name socat-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -p 8080:8080 \
  {registry.example.com}/alpine-socat-fips:latest \
  socat TCP-LISTEN:8080,fork,reuseaddr TCP:internal-service:80
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/certs:/etc/ssl/certs {registry.example.com}/alpine-socat-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8443:8443 {registry.example.com}/alpine-socat-fips:latest socat OPENSSL-LISTEN:8443,cert=/etc/ssl/certs/server.pem,verify=0,fork TCP:internal-service:443
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| SOCAT_OPTS |  | Additional socat options |
| FIPS_MODE | 1 | Enable/disable FIPS mode (1/0) |
| SSL_CERT_DIR | /etc/ssl/certs | SSL certificate directory |
| LISTEN_PORT | 8080 | Default listening port |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use TLS/SSL certificates for encrypted connections
- Implement proper access controls and authentication
- Regular security audits and compliance checks
- Monitor network traffic patterns
- Keep container image updated with security patches
- Use specific version tags in production
- Implement network segmentation

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_BIND_SERVICE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/alpine-socat-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance
- **Socat Documentation**: https://{registry.example.com}/docs/socat-usage