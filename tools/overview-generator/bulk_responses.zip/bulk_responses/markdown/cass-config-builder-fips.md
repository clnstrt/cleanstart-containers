**Container Documentation for Cass-Config-Builder-Fips**

A specialized container image designed for building and managing Cassandra configurations in FIPS-compliant environments. This container provides tools and utilities for generating secure, compliant configuration files for Cassandra database deployments while maintaining FIPS 140-2 compliance requirements. Ideal for enterprise environments requiring high security standards and regulatory compliance.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cass-config-builder-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant configuration generation
- Automated Cassandra configuration management
- Security-hardened base configuration
- Enterprise-ready deployment capabilities

**Common Use Cases**
Typical scenarios where this container excels

- Generating FIPS-compliant Cassandra configurations
- Managing secure database deployments
- Automated configuration updates
- Regulatory compliance maintenance

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cass-config-builder-fips:latest
```

```bash
docker pull {registry.example.com}/cass-config-builder-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cass-config-builder-fips-test {registry.example.com}/cass-config-builder-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cass-config-builder-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cass-config-builder-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/config {registry.example.com}/cass-config-builder-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9042:9042 {registry.example.com}/cass-config-builder-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CASSANDRA_VERSION | 4.0 | Target Cassandra version |
| CONFIG_PATH | /config | Configuration output directory |
| FIPS_MODE | true | Enable FIPS mode |
| TEMPLATE_PATH | /templates | Custom template directory |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS compliance requirements are met
- Use specific image tags for production deployments
- Implement proper access controls for configuration files
- Regular security audits of generated configurations
- Maintain secure backup procedures
- Monitor for compliance violations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cass-config-builder-fips