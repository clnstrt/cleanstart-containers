**Container Documentation for Dex-Fips**

Dex-Fips is a FIPS 140-2 compliant identity service that uses OpenID Connect to drive authentication for enterprise applications. This container provides a secure, FIPS-validated implementation for federated identity management, supporting multiple identity providers and offering robust authentication flows for enterprise environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/dex-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Multi-provider authentication support
- OpenID Connect protocol implementation
- Enterprise-grade security controls

**Common Use Cases**
Typical scenarios where this container excels

- Enterprise identity federation
- Single Sign-On (SSO) implementation
- Kubernetes authentication provider
- Multi-factor authentication services

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/dex-fips:latest
```

```bash
docker pull {registry.example.com}/dex-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name dex-fips-test -p 5556:5556 {registry.example.com}/dex-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name dex-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -p 5556:5556 \
  -v $(pwd)/config:/etc/dex \
  {registry.example.com}/dex-fips:latest
```

**Volume Mount**
Mount configuration directory for Dex

```bash
docker run -v $(pwd)/config:/etc/dex {registry.example.com}/dex-fips:latest
```

**Port Forwarding**
Run with default Dex port mapping

```bash
docker run -p 5556:5556 {registry.example.com}/dex-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| DEX_FRONTEND_DIR | /srv/dex/web | Directory containing web assets |
| DEX_CONFIG | /etc/dex/config.yaml | Path to configuration file |
| FIPS_MODE | true | Enable FIPS mode |
| LOG_LEVEL | info | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Use TLS for all connections
- Implement proper secret management
- Regular rotation of client secrets
- Monitor authentication attempts
- Configure appropriate session timeouts
- Use secure password policies
- Enable audit logging
- Regular security updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/dex-fips
- **FIPS Compliance Documentation**: https://{registry.example.com}/docs/fips