**Container Documentation for Etcd-Fips**

FIPS-validated etcd container image designed for secure, distributed key-value storage in enterprise environments. Features FIPS 140-2 cryptographic modules, STIG-hardening, and enhanced security controls for regulated industries and government deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/etcd-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- Distributed key-value store capabilities
- High-availability cluster support

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster data store
- Service discovery and configuration
- Distributed locking and leader election
- Secure configuration storage

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/etcd-fips:latest
```

```bash
docker pull {registry.example.com}/etcd-fips:3.5
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name etcd-fips \
  -p 2379:2379 \
  -p 2380:2380 \
  {registry.example.com}/etcd-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name etcd-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -p 2379:2379 \
  -p 2380:2380 \
  -v etcd-data:/var/lib/etcd \
  {registry.example.com}/etcd-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d --name etcd-fips \
  -v $(pwd)/etcd-data:/var/lib/etcd \
  {registry.example.com}/etcd-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d --name etcd-fips \
  -p 12379:2379 \
  -p 12380:2380 \
  {registry.example.com}/etcd-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ETCD_DATA_DIR | /var/lib/etcd | Data directory location |
| ETCD_LISTEN_CLIENT_URLS | http://0.0.0.0:2379 | List of URLs to listen on for client traffic |
| ETCD_LISTEN_PEER_URLS | http://0.0.0.0:2380 | List of URLs to listen on for peer traffic |
| ETCD_INITIAL_CLUSTER_TOKEN | etcd-cluster | Initial cluster token for etcd cluster |

**Security Best Practices**
Recommended security configurations and practices

- Enable TLS for client and peer communication
- Implement role-based access control (RBAC)
- Regular backup of etcd data
- Monitor cluster health and metrics
- Use secure token-based authentication
- Implement proper network segmentation
- Regular security patches and updates
- Audit logging and monitoring

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/etcd-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance
- **Security Hardening Guide**: https://{registry.example.com}/docs/security-hardening