**Container Documentation for Fluent-Watcher-Fips**

Fluent-Watcher-FIPS is a FIPS 140-2 compliant log monitoring and forwarding container designed for enterprise environments requiring strict security compliance. It provides secure log collection, processing, and forwarding capabilities while maintaining FIPS validation throughout the entire data pipeline.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/fluent-watcher-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Real-time log monitoring and processing
- Secure log forwarding with encryption
- Compliance-ready audit logging

**Common Use Cases**
Typical scenarios where this container excels

- Government and military log management
- Healthcare data compliance monitoring
- Financial services audit logging
- Secure enterprise log aggregation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/fluent-watcher-fips:latest
```

```bash
docker pull {registry.example.com}/fluent-watcher-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name fluent-watcher-fips-test {registry.example.com}/fluent-watcher-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name fluent-watcher-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/fluent-watcher-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/logs:/var/log \
  -v $(pwd)/config:/etc/fluent-watcher/conf.d \
  {registry.example.com}/fluent-watcher-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 24224:24224 -p 24224:24224/udp {registry.example.com}/fluent-watcher-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLUENT_WATCHER_MODE | forward | Operating mode (forward/aggregate) |
| FLUENT_WATCHER_BUFFER_SIZE | 256m | Maximum buffer size for log processing |
| FLUENT_WATCHER_FIPS_MODE | enabled | FIPS mode enforcement |
| FLUENT_WATCHER_LOG_LEVEL | info | Logging verbosity level |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled and enforced
- Implement secure TLS communication
- Regular security compliance audits
- Monitor cryptographic operations
- Maintain access control lists
- Enable audit logging for all operations
- Regular security patch updates
- Implement proper backup procedures

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/fluent-watcher-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance