**Container Documentation for Go1.22-Fips**

Enterprise-grade Go 1.22 runtime environment with FIPS 140-2 validated cryptographic modules, designed for secure cloud-native applications requiring regulatory compliance. Features comprehensive security hardening, optimized performance, and full compatibility with standard Go tooling.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/go1.22-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 validated cryptographic modules
- Security-hardened runtime environment
- Enterprise-ready Go 1.22 toolchain
- Optimized for cloud-native applications

**Common Use Cases**
Typical scenarios where this runtime container excels

- Government and regulated industry applications
- Financial services and banking systems
- Healthcare application development
- Secure microservices deployment

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/go1.22-fips:latest
```

```bash
docker pull {registry.example.com}/go1.22-fips:latest-dev
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name go1.22-fips-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/go1.22-fips:latest-dev /bin/sh
```

**Run Hello World**
Execute a simple Hello World program

```bash
docker run --rm {registry.example.com}/go1.22-fips:latest-dev go run -e 'package main; func main() { println("Hello, World!") }'
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/go1.22-fips:latest-dev go version
```

**Application Server**
Run application with port forwarding

```bash
docker run -d --name go1.22-fips-app \
  -p 8080:8080 \
  -v $(pwd):/app \
  -w /app \
  {registry.example.com}/go1.22-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| GOPATH | /go | Go workspace directory |
| GOROOT | /usr/local/go | Go installation directory |
| GO111MODULE | on | Module support |
| GOOS | linux | Target operating system |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled for cryptographic operations
- Use vendored dependencies for reproducible builds
- Implement secure coding guidelines
- Regular security patches and updates
- Enable Go modules checksum database
- Configure appropriate resource limits

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Go Documentation**: https://golang.org/doc/
- **FIPS 140-2 Documentation**: https://csrc.nist.gov/publications/detail/fips/140/2/final