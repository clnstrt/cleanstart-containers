**Container Documentation for Calico-Node**

Calico-node is a core networking and network security component for Kubernetes clusters, providing highly scalable layer 3 networking, network policy enforcement, and advanced security features. It enables secure pod-to-pod networking, network isolation, and fine-grained access controls across container workloads.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-node`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Layer 3 networking with BGP integration
- Network policy enforcement and microsegmentation
- High-performance data plane with eBPF
- Advanced security features including encryption and FIPS compliance

**Common Use Cases**
Typical scenarios where this runtime container excels

- Kubernetes cluster networking infrastructure
- Zero-trust network security implementation
- Multi-cluster networking and federation
- Cloud-native network security and compliance

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/calico-node:latest
```

```bash
docker pull {registry.example.com}/calico-node:v3.26.1
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name calico-node-dev \
  --privileged \
  --net=host \
  {registry.example.com}/calico-node:latest
```

**Run Hello World**
Execute a simple status check

```bash
docker run --rm {registry.example.com}/calico-node:latest calico-node -v
```

**Mount Workspace**
Run container with local configuration mounted

```bash
docker run --rm -v /etc/calico:/etc/calico {registry.example.com}/calico-node:latest
```

**Node Deployment**
Deploy calico-node with required privileges

```bash
docker run -d --name calico-node \
  --privileged \
  --net=host \
  -v /lib/modules:/lib/modules \
  -v /var/run/calico:/var/run/calico \
  {registry.example.com}/calico-node:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CALICO_NETWORKING_BACKEND | bird | Networking backend (bird, vxlan, none) |
| IP | autodetect | IPv4 address of node |
| IP6 | autodetect | IPv6 address of node |
| FELIX_LOGSEVERITYSCREEN | INFO | Log severity level |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Configure network policies for pod isolation
- Enable encryption for pod-to-pod traffic
- Implement proper RBAC controls
- Regular security updates and patches
- Monitor network traffic and policy violations
- Use secure BGP peering configurations
- Enable audit logging for security events

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["NET_ADMIN", "NET_RAW"]
  allowPrivilegeEscalation: true
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Calico Documentation**: https://docs.projectcalico.org/
- **GitHub Repository**: https://github.com/projectcalico/calico