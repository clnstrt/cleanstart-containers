**Container Documentation for Etcd-Bitnami**

Enterprise-grade etcd container image based on Bitnami's trusted build, offering a distributed key-value store designed for configuration management, service discovery, and distributed locking in cloud-native environments. Features high availability, strong consistency, and secure communication with TLS encryption.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/etcd-bitnami`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Distributed key-value store with strong consistency
- Built-in disaster recovery with automatic snapshots
- TLS-based security for client and peer communication
- High availability with automatic leader election

**Common Use Cases**
Typical scenarios where this container excels

- Service discovery in microservices architectures
- Configuration management for distributed systems
- Distributed locking and leader election
- Kubernetes backing store

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/etcd-bitnami:latest
```

```bash
docker pull {registry.example.com}/etcd-bitnami:3.5.9
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name etcd \
  -p 2379:2379 \
  -p 2380:2380 \
  {registry.example.com}/etcd-bitnami:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name etcd-prod \
  --read-only \
  --security-opt=no-new-privileges \
  -p 2379:2379 -p 2380:2380 \
  -v etcd-data:/bitnami/etcd \
  -e ETCD_ADVERTISE_CLIENT_URLS=http://etcd:2379 \
  -e ALLOW_NONE_AUTHENTICATION=no \
  -e ETCD_ROOT_PASSWORD=your-secure-password \
  {registry.example.com}/etcd-bitnami:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d --name etcd \
  -v /path/to/etcd-persistence:/bitnami/etcd \
  {registry.example.com}/etcd-bitnami:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d --name etcd \
  -p 12379:2379 \
  -p 12380:2380 \
  {registry.example.com}/etcd-bitnami:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ALLOW_NONE_AUTHENTICATION | no | Allow unauthenticated access |
| ETCD_ROOT_PASSWORD |  | Root password for etcd authentication |
| ETCD_CLUSTER_DOMAIN | cluster.local | Kubernetes cluster domain |
| ETCD_ADVERTISE_CLIENT_URLS | http://127.0.0.1:2379 | List of advertised client URLs |

**Security Best Practices**
Recommended security configurations and practices

- Enable authentication and set strong root password
- Configure TLS certificates for client and peer communication
- Implement proper backup and snapshot policies
- Use specific version tags instead of latest
- Regularly update to latest security patches
- Configure proper network segmentation
- Enable audit logging
- Implement resource limits and quotas

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1001
  fsGroup: 1001
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
resources:
  limits:
    cpu: 1000m
    memory: 1Gi
  requests:
    cpu: 500m
    memory: 512Mi
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/etcd-bitnami
- **Etcd Official Documentation**: https://etcd.io/docs/