**Container Documentation for Aws-Cli-V2-Fips**

AWS CLI v2 container with FIPS-validated cryptographic modules, designed for secure cloud operations in regulated environments. Features complete AWS command-line functionality with FIPS 140-2 compliance for government and enterprise use cases requiring validated cryptography.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/aws-cli-v2-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Complete AWS CLI v2 functionality
- Security-hardened base configuration
- Multi-architecture support (amd64/arm64)

**Common Use Cases**
Typical scenarios where this container excels

- Government cloud operations requiring FIPS compliance
- Regulated industry AWS resource management
- Secure CI/CD pipeline automation
- Enterprise cloud infrastructure management

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/aws-cli-v2-fips:latest
```

```bash
docker pull {registry.example.com}/aws-cli-v2-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name aws-cli-fips {registry.example.com}/aws-cli-v2-fips:latest aws --version
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name aws-cli-fips \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v ~/.aws:/home/aws/.aws:ro \
  {registry.example.com}/aws-cli-v2-fips:latest
```

**Volume Mount**
Mount AWS credentials and configuration

```bash
docker run -v ~/.aws:/home/aws/.aws:ro {registry.example.com}/aws-cli-v2-fips:latest aws s3 ls
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/aws-cli-v2-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_DEFAULT_REGION | us-east-1 | Default AWS region |
| AWS_PROFILE | default | AWS credentials profile |
| AWS_CONFIG_FILE | /home/aws/.aws/config | AWS config file location |
| AWS_SHARED_CREDENTIALS_FILE | /home/aws/.aws/credentials | AWS credentials file location |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Mount AWS credentials as read-only volumes
- Enable read-only root filesystem
- Run container with non-root user
- Implement proper IAM roles and permissions
- Regular security patches and updates
- Use AWS credential best practices
- Monitor AWS CLI activity logs

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **AWS CLI Documentation**: https://docs.aws.amazon.com/cli/
- **FIPS 140-2 Documentation**: https://csrc.nist.gov/publications/detail/fips/140/2/final