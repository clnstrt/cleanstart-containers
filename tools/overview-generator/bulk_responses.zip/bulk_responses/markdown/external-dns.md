**Container Documentation for External-Dns**

ExternalDNS synchronizes exposed Kubernetes Services and Ingresses with DNS providers. It automatically manages external DNS records based on your Kubernetes resources, enabling automatic DNS configuration for cloud-native applications and microservices deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/external-dns`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automatic DNS record management for Kubernetes Services and Ingresses
- Support for multiple DNS providers including AWS Route53, Google Cloud DNS, and Azure DNS
- Kubernetes-native configuration and deployment
- Flexible annotation-based configuration

**Common Use Cases**
Typical scenarios where this container excels

- Automated DNS management in Kubernetes clusters
- Multi-cloud DNS record synchronization
- Dynamic DNS updates for microservices
- Cloud-native application DNS automation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/external-dns:latest
```

```bash
docker pull {registry.example.com}/external-dns:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name external-dns \
  -e AWS_ACCESS_KEY_ID=<key> \
  -e AWS_SECRET_ACCESS_KEY=<secret> \
  {registry.example.com}/external-dns:latest \
  --provider=aws \
  --source=service \
  --domain-filter=example.com
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name external-dns-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -e AWS_ACCESS_KEY_ID=<key> \
  -e AWS_SECRET_ACCESS_KEY=<secret> \
  {registry.example.com}/external-dns:latest \
  --provider=aws \
  --policy=sync \
  --registry=txt \
  --txt-owner-id=my-cluster
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/config {registry.example.com}/external-dns:latest --config-file=/config/config.yaml
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 7979:7979 {registry.example.com}/external-dns:latest --metrics-address=:7979
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_ACCESS_KEY_ID |  | AWS credentials for Route53 access |
| AWS_SECRET_ACCESS_KEY |  | AWS secret key for Route53 access |
| GOOGLE_APPLICATION_CREDENTIALS |  | Path to Google Cloud credentials file |
| AZURE_SUBSCRIPTION_ID |  | Azure subscription ID for DNS management |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper RBAC policies in Kubernetes
- Use separate DNS credentials for different environments
- Enable read-only root filesystem
- Run as non-root user
- Regularly rotate DNS provider credentials
- Monitor DNS changes and audit logs
- Use TXT records for ownership verification

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/external-dns
- **GitHub Repository**: https://github.com/kubernetes-sigs/external-dns