**Container Documentation for Flux-Notification-Controller-Bitnami-Compat**

A Flux notification controller container image optimized for Bitnami compatibility, providing event notification and alerting capabilities for GitOps workflows. This container enables automated notifications for Flux operations, supporting various notification providers and offering enterprise-grade reliability for GitOps deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-notification-controller-bitnami-compat`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Integrated notification system for Flux GitOps events
- Support for multiple notification providers (Slack, Discord, MS Teams)
- Bitnami-compatible runtime environment
- Enhanced security features and hardening

**Common Use Cases**
Typical scenarios where this container excels

- GitOps workflow notifications and alerts
- Kubernetes deployment status monitoring
- Continuous delivery event tracking
- Team collaboration and deployment visibility

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-notification-controller-bitnami-compat:latest
```

```bash
docker pull {registry.example.com}/flux-notification-controller-bitnami-compat:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-notification-controller {registry.example.com}/flux-notification-controller-bitnami-compat:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-notification-controller \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/flux/notifications:/etc/flux/notifications \
  {registry.example.com}/flux-notification-controller-bitnami-compat:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/flux/notifications {registry.example.com}/flux-notification-controller-bitnami-compat:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9292:9292 {registry.example.com}/flux-notification-controller-bitnami-compat:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| NOTIFICATION_PROVIDER | slack | Notification provider type (slack, discord, teams) |
| WEBHOOK_URL |  | Webhook URL for notifications |
| LOG_LEVEL | info | Logging level (debug, info, warn, error) |
| WATCH_NAMESPACE |  | Kubernetes namespace to watch |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper secret management for webhook URLs
- Enable read-only filesystem
- Run as non-root user
- Regular security updates and patches
- Configure resource limits
- Use network policies for access control
- Enable audit logging

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-notification-controller-bitnami-compat
- **Flux Documentation**: https://fluxcd.io/docs/