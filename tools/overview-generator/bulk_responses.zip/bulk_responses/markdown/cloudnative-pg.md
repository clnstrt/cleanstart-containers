**Container Documentation for Cloudnative-Pg**

CloudNativePG is a Kubernetes operator that manages PostgreSQL workloads on any supported Kubernetes cluster. It provides high availability, scalability, and automated management features for PostgreSQL databases in cloud-native environments. The operator enables automated failover, backup management, and monitoring integration while maintaining enterprise-grade security and performance.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cloudnative-pg`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Native Kubernetes integration for PostgreSQL management
- Automated failover and high availability configuration
- Backup and recovery automation
- Advanced monitoring and metrics integration

**Common Use Cases**
Typical scenarios where this container excels

- Production PostgreSQL deployments on Kubernetes
- High-availability database clusters
- Cloud-native application databases
- Enterprise database management

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cloudnative-pg:latest
```

```bash
docker pull {registry.example.com}/cloudnative-pg:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cloudnative-pg-test {registry.example.com}/cloudnative-pg:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cloudnative-pg-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cloudnative-pg:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/cloudnative-pg:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 5432:5432 {registry.example.com}/cloudnative-pg:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| POSTGRES_PASSWORD |  | PostgreSQL admin password |
| POSTGRES_USER | postgres | PostgreSQL admin username |
| POSTGRES_DB | postgres | Default database name |
| PGDATA | /var/lib/postgresql/data | Data directory location |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper database authentication
- Enable SSL/TLS for database connections
- Regular backup and recovery testing
- Monitor database metrics and logs
- Apply security patches promptly
- Use network policies for access control
- Implement proper role-based access control

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cloudnative-pg
- **Official Documentation**: https://cloudnative-pg.io