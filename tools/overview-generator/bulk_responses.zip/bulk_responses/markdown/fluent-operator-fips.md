**Container Documentation for Fluent-Operator-Fips**

The Fluent Operator FIPS container provides a FIPS-compliant logging and data collection solution for enterprise Kubernetes environments. It manages Fluent Bit and Fluentd deployments with enhanced security features, centralized logging capabilities, and compliance with Federal Information Processing Standards (FIPS 140-2). This operator simplifies log management while maintaining strict security requirements for government and regulated industries.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/fluent-operator-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant logging operations
- Automated deployment and management of Fluent Bit and Fluentd
- Kubernetes-native logging infrastructure
- Enhanced security features for regulated environments

**Common Use Cases**
Typical scenarios where this container excels

- Government and military logging systems
- Financial services compliance logging
- Healthcare data collection and monitoring
- Enterprise-scale log aggregation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/fluent-operator-fips:latest
```

```bash
docker pull {registry.example.com}/fluent-operator-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name fluent-operator-fips-test {registry.example.com}/fluent-operator-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name fluent-operator-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/fluent-operator-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/fluent-operator/config \
  -v $(pwd)/logs:/var/log \
  {registry.example.com}/fluent-operator-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 24224:24224 -p 24224:24224/udp {registry.example.com}/fluent-operator-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLUENT_OPERATOR_LOG_LEVEL | info | Logging level for the operator |
| WATCH_NAMESPACE |  | Namespace to watch for custom resources |
| OPERATOR_NAME | fluent-operator | Name of the operator deployment |
| FIPS_MODE | true | Enable/disable FIPS mode |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production environments
- Implement proper RBAC policies for Kubernetes deployments
- Use secure transport protocols for log forwarding
- Regular security scanning of deployed images
- Monitor operator logs for security events
- Implement network policies to restrict traffic

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/fluent-operator-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance