**Container Documentation for Flux-Helm-Controller**

The Flux Helm Controller is a specialized component that manages Helm releases in a GitOps fashion. It enables declarative management of Helm charts through Kubernetes custom resources, providing automated deployment, updates, and rollbacks of Helm releases based on source changes. This controller is essential for organizations implementing GitOps practices with Helm charts in their Kubernetes environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-helm-controller`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automated Helm release management through GitOps
- Declarative configuration using Kubernetes custom resources
- Automated rollback capabilities on failed releases
- Integration with Flux source controller for chart sources

**Common Use Cases**
Typical scenarios where this container excels

- GitOps-based Helm release management
- Automated application deployment via Helm charts
- Continuous delivery pipelines with Helm
- Multi-cluster Helm release synchronization

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-helm-controller:latest
```

```bash
docker pull {registry.example.com}/flux-helm-controller:v1.0.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name helm-controller \
  -v $HOME/.kube/config:/etc/kubernetes/config \
  {registry.example.com}/flux-helm-controller:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name helm-controller-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v $HOME/.kube/config:/etc/kubernetes/config:ro \
  {registry.example.com}/flux-helm-controller:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $HOME/.kube:/etc/kubernetes:ro \
  -v $HOME/.helm:/helm:ro \
  {registry.example.com}/flux-helm-controller:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9440:9440 {registry.example.com}/flux-helm-controller:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| KUBERNETES_SERVICE_HOST | kubernetes.default.svc | Kubernetes API server host |
| KUBERNETES_SERVICE_PORT | 443 | Kubernetes API server port |
| HELM_CONTROLLER_METRICS_ADDR | :9440 | Metrics server address |
| RUNTIME_NAMESPACE | flux-system | Namespace for controller operation |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Implement RBAC policies for Kubernetes access
- Mount configuration files as read-only
- Run container with non-root user
- Enable read-only root filesystem
- Configure resource limits and requests
- Use network policies to restrict communication
- Regularly update to latest security patches

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-helm-controller
- **Flux Documentation**: https://fluxcd.io/docs/components/helm/