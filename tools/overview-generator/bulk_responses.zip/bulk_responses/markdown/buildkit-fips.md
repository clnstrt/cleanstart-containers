**Container Documentation for Buildkit-Fips**

BuildKit-FIPS is a FIPS 140-2 compliant container build toolkit designed for secure, enterprise-grade container image creation. It provides cryptographic modules validation, secure build environments, and compliance with federal security standards while maintaining high performance and reliability.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/buildkit-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Secure container build pipeline integration
- Enhanced security controls and audit capabilities
- Federal compliance ready configuration

**Common Use Cases**
Typical scenarios where this container excels

- Government and military applications
- Financial services deployments
- Healthcare systems integration
- Secure enterprise container builds

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/buildkit-fips:latest
```

```bash
docker pull {registry.example.com}/buildkit-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name buildkit-fips-test {registry.example.com}/buildkit-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name buildkit-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/buildkit-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/buildkit-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/buildkit-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| BUILDKIT_FIPS_MODE | enabled | Enable/disable FIPS mode |
| BUILDKIT_MAX_PARALLEL_JOBS | 4 | Maximum parallel build jobs |
| BUILDKIT_DEBUG | 0 | Enable debug logging |
| BUILDKIT_WORKER_LABELS |  | Custom worker labels |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Implement proper access controls and authentication
- Regular security scanning of built images
- Maintain audit logs of all build operations
- Use secure registry connections (HTTPS)
- Implement build-time security scanning

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/buildkit-fips