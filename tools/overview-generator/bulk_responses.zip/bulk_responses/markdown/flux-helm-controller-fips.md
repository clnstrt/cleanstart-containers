**Container Documentation for Flux-Helm-Controller-Fips**

The Flux Helm Controller FIPS container provides a FIPS-validated implementation of the Flux Helm Controller, enabling secure and compliant Kubernetes-native Helm operations. It manages Helm chart releases in a GitOps fashion, ensuring consistent, auditable, and secure deployment of Helm charts across clusters while maintaining FIPS 140-2 compliance for regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-helm-controller-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Automated Helm chart reconciliation
- GitOps-based deployment workflow
- Kubernetes-native Helm operations

**Common Use Cases**
Typical scenarios where this container excels

- Regulated environment Helm deployments
- Automated chart release management
- Secure GitOps workflows
- Compliance-focused Kubernetes operations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-helm-controller-fips:latest
```

```bash
docker pull {registry.example.com}/flux-helm-controller-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-helm-controller {registry.example.com}/flux-helm-controller-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-helm-controller-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/kubernetes/config:/etc/kubernetes/config \
  {registry.example.com}/flux-helm-controller-fips:latest
```

**Volume Mount**
Mount configuration and credentials

```bash
docker run -v $(pwd)/config:/etc/flux/config -v $(pwd)/credentials:/etc/flux/credentials {registry.example.com}/flux-helm-controller-fips:latest
```

**Port Forwarding**
Run with metrics port exposed

```bash
docker run -p 9000:9000 {registry.example.com}/flux-helm-controller-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| HELM_CONTROLLER_CHARTS_PATH | /charts | Path to Helm charts directory |
| HELM_CONTROLLER_INTERVAL | 1m | Reconciliation interval |
| HELM_CONTROLLER_METRICS_ADDR | :9000 | Metrics server address |
| HELM_CONTROLLER_LOG_LEVEL | info | Logging level |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies to limit controller permissions
- Enable audit logging for all Helm operations
- Implement network policies to restrict communication
- Regular security scanning of Helm charts
- Use signed container images
- Configure resource quotas and limits
- Implement proper secret management
- Regular security updates and patching

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-helm-controller-fips
- **Flux Documentation**: https://fluxcd.io/docs/