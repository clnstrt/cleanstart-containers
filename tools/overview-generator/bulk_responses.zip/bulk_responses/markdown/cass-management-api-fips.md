**Container Documentation for Cass-Management-Api-Fips**

Enterprise-grade Cassandra management API container with FIPS 140-2 compliance, providing secure database administration capabilities for regulated environments. Features include role-based access control, audit logging, and encrypted communications for managing Apache Cassandra clusters.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cass-management-api-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic modules
- Secure REST API for Cassandra management
- Role-based access control implementation
- Comprehensive audit logging capabilities

**Common Use Cases**
Typical scenarios where this container excels

- Government and military database management
- Healthcare data administration
- Financial services database operations
- Regulated industry deployments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cass-management-api-fips:latest
```

```bash
docker pull {registry.example.com}/cass-management-api-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cass-management-api-fips-test {registry.example.com}/cass-management-api-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cass-management-api-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cass-management-api-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/cass-management-api-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/cass-management-api-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CASSANDRA_HOST | localhost | Cassandra host address |
| CASSANDRA_PORT | 9042 | Cassandra port |
| API_PORT | 8080 | Management API port |
| SSL_ENABLED | true | Enable SSL/TLS encryption |

**Security Best Practices**
Recommended security configurations and practices

- Enable FIPS mode for all cryptographic operations
- Configure SSL/TLS with FIPS-compliant certificates
- Implement proper authentication mechanisms
- Enable audit logging for all operations
- Regular security patch updates
- Network segmentation and firewall rules

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cass-management-api-fips