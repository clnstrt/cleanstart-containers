**Container Documentation for Argocd-Fips**

ArgoCD FIPS is a declarative continuous delivery tool for Kubernetes that follows Federal Information Processing Standards (FIPS) compliance requirements. It automates the deployment of applications while maintaining strict security standards required for government and regulated enterprise environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argocd-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 compliant cryptographic modules
- Automated deployment and sync of applications
- GitOps workflow support with security controls
- Role-based access control (RBAC) integration

**Common Use Cases**
Typical scenarios where this runtime container excels

- Government and regulated industry Kubernetes deployments
- Secure multi-cluster application management
- Compliance-focused continuous delivery pipelines
- Enterprise GitOps implementations

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argocd-fips:latest
```

```bash
docker pull {registry.example.com}/argocd-fips:v2.8-fips
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argocd-fips-dev \
  -v $(pwd):/workspace \
  -p 8080:8080 \
  {registry.example.com}/argocd-fips:latest
```

**Run Hello World**
Start a basic ArgoCD FIPS instance

```bash
docker run --rm -p 8080:8080 {registry.example.com}/argocd-fips:latest
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app \
  -v ~/.kube:/home/argocd/.kube \
  -w /app {registry.example.com}/argocd-fips:latest
```

**Application Server**
Run ArgoCD FIPS server with standard configuration

```bash
docker run -d --name argocd-fips-server \
  -p 443:443 \
  -v argocd-config:/home/argocd/.config \
  -v argocd-data:/home/argocd/data \
  {registry.example.com}/argocd-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGOCD_SERVER_INSECURE | false | Disable TLS for the API server |
| ARGOCD_SERVER_PORT | 8080 | API server listening port |
| ARGOCD_REPO_SERVER_PORT | 8081 | Repository server port |
| ARGOCD_SERVER_LOG_LEVEL | info | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Enable RBAC and configure appropriate roles
- Use SSL/TLS for all communications
- Implement secure secret management
- Regular security patches and updates
- Configure network policies
- Enable audit logging
- Use SSO integration when possible
- Implement proper backup strategies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 999
  fsGroup: 999
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **ArgoCD Documentation**: https://argo-cd.readthedocs.io/
- **FIPS Security Guide**: https://{registry.example.com}/docs/security/fips