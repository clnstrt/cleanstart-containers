**Container Documentation for Calico-Typha-Fips**

Calico Typha FIPS is a specialized container image that provides FIPS 140-2 compliant networking capabilities for Kubernetes clusters. It serves as a fan-out proxy that helps optimize Calico's control plane, reducing load on the Kubernetes API server in large clusters while maintaining FIPS compliance for regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-typha-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Optimized control plane scaling for large clusters
- Reduced Kubernetes API server load
- Enhanced security compliance for regulated environments

**Common Use Cases**
Typical scenarios where this container excels

- Government and military deployments requiring FIPS compliance
- Large-scale enterprise Kubernetes clusters
- Regulated industry environments (healthcare, finance)
- High-security containerized networking implementations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-typha-fips:latest
```

```bash
docker pull {registry.example.com}/calico-typha-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-typha-fips {registry.example.com}/calico-typha-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-typha-fips \
  --read-only \
  --security-opt=no-new-privileges \
  --cap-drop=ALL \
  --user 1000:1000 \
  -e TYPHA_LOGSEVERITYSCREEN=INFO \
  -e TYPHA_PROMETHEUSMETRICSENABLED=true \
  {registry.example.com}/calico-typha-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v /var/run/calico:/var/run/calico {registry.example.com}/calico-typha-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 5473:5473 {registry.example.com}/calico-typha-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| TYPHA_LOGSEVERITYSCREEN | INFO | Log severity level |
| TYPHA_PROMETHEUSMETRICSENABLED | true | Enable Prometheus metrics |
| TYPHA_HEALTHENABLED | true | Enable health checks |
| TYPHA_DATASTORETYPE | kubernetes | Backend datastore type |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is properly enabled
- Implement strict network policies
- Regular security compliance audits
- Monitor Typha metrics for anomalies
- Use secure communication channels
- Implement proper access controls
- Regular security patches and updates
- Maintain audit logs

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-typha-fips
- **Calico Documentation**: https://docs.projectcalico.org/reference/typha/