**Container Documentation for Cert-Manager-Cainjector**

The cert-manager-cainjector container is a critical component of the cert-manager ecosystem, responsible for automatically injecting CA bundles into webhook configurations. It ensures proper certificate validation by maintaining up-to-date CA information across your Kubernetes cluster, enabling secure certificate management and automated TLS certificate provisioning.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cert-manager-cainjector`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automatic CA bundle injection for webhook configurations
- Seamless integration with cert-manager ecosystem
- Real-time CA synchronization across cluster
- Enhanced security through automated certificate management

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes certificate management automation
- TLS certificate validation and distribution
- Webhook configuration management
- CA bundle synchronization across namespaces

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cert-manager-cainjector:latest
```

```bash
docker pull {registry.example.com}/cert-manager-cainjector:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cert-manager-cainjector-test {registry.example.com}/cert-manager-cainjector:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cert-manager-cainjector-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cert-manager-cainjector:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/certs:/certs {registry.example.com}/cert-manager-cainjector:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9402:9402 {registry.example.com}/cert-manager-cainjector:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| NAMESPACE | cert-manager | Namespace where cert-manager is deployed |
| LOG_LEVEL | 2 | Logging verbosity level |
| LEADER_ELECT | true | Enable leader election |
| KUBECONFIG |  | Path to kubeconfig file |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies to limit access permissions
- Enable pod security policies
- Regularly update cert-manager components
- Monitor CA bundle injection logs
- Implement network policies
- Use secure communication channels
- Regular security audits
- Backup CA configurations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1001
  fsGroup: 1001
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cert-manager-cainjector
- **Cert-Manager Documentation**: https://cert-manager.io/docs/