**Container Documentation for Grype**

Grype is a vulnerability scanner for container images and filesystems. It provides comprehensive scanning capabilities to identify known vulnerabilities in your container images, dependencies, and operating system packages. Designed for enterprise security teams and DevSecOps workflows, Grype enables automated security scanning in CI/CD pipelines and supports multiple output formats for integration with existing security tools.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/grype`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- Fast and accurate vulnerability scanning
- Support for multiple Linux distributions
- Integration with CI/CD pipelines
- Multiple output formats (JSON, SARIF, Table)

**Common Use Cases**
Typical scenarios where this container excels

- Automated vulnerability scanning in CI/CD pipelines
- Container image security validation
- Compliance checking and reporting
- Development security testing

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/grype:latest
```

```bash
docker pull registry.example.com/grype:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --rm registry.example.com/grype:latest <image-to-scan>
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name grype-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  registry.example.com/grype:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd):/workspace registry.example.com/grype:latest /workspace/my-image:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9279:9279 registry.example.com/grype:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| GRYPE_DB_UPDATE_URL | https://toolbox-data.anchore.io/grype/databases/listing.json | Database update URL |
| GRYPE_CHECK_FOR_APP_UPDATE | true | Enable/disable update checks |
| GRYPE_OUTPUT | table | Output format (table, json, sarif) |
| GRYPE_FAIL_ON_SEVERITY |  | Fail on specific vulnerability severity |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Regularly update vulnerability database
- Configure appropriate severity thresholds
- Implement proper access controls
- Monitor scan results and trends
- Integrate with security response workflows

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/grype
- **Official Grype Documentation**: https://github.com/anchore/grype