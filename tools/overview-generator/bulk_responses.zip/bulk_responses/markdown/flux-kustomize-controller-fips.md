**Container Documentation for Flux-Kustomize-Controller-Fips**

The Flux Kustomize Controller FIPS container provides a FIPS-validated implementation of the Flux Kustomize Controller, enabling secure GitOps workflows in regulated environments. It manages the reconciliation of Kubernetes resources defined with Kustomize, ensuring compliance with Federal Information Processing Standards (FIPS 140-2/140-3) while supporting automated deployment and configuration management.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-kustomize-controller-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2/140-3 validated cryptographic modules
- Automated Kubernetes resource reconciliation
- Native Kustomize integration for GitOps workflows
- Enhanced security controls for regulated environments

**Common Use Cases**
Typical scenarios where this container excels

- Government and regulated industry deployments
- Secure GitOps implementation
- Automated Kubernetes configuration management
- Compliance-focused container orchestration

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-kustomize-controller-fips:latest
```

```bash
docker pull {registry.example.com}/flux-kustomize-controller-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-kustomize-controller-fips-test {registry.example.com}/flux-kustomize-controller-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-kustomize-controller-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/flux-kustomize-controller-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/manifests:/manifests {registry.example.com}/flux-kustomize-controller-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:8080 {registry.example.com}/flux-kustomize-controller-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| RUNTIME_NAMESPACE | flux-system | Namespace where the controller runs |
| WATCH_NAMESPACE |  | Namespace to watch for resources |
| METRICS_PORT | 8080 | Port for metrics endpoint |
| LOG_LEVEL | info | Logging verbosity level |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in your environment
- Implement strict RBAC policies
- Use secure communication channels for Git operations
- Regular security scanning of manifests
- Enable audit logging
- Implement network policies
- Use signed container images
- Regular security updates and patches

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-kustomize-controller-fips
- **Flux Documentation**: https://fluxcd.io/docs/