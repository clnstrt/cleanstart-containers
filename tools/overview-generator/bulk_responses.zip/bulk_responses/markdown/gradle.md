**Container Documentation for Gradle**

Enterprise-ready Gradle build tool container image optimized for Java and JVM-based project builds. Features security hardening, multi-stage builds, and comprehensive build tool chain integration. Ideal for CI/CD pipelines, automated builds, and development environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/gradle`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- Pre-configured Gradle build environment with optimized settings
- Multi-stage build optimization for minimal image size
- Integrated security scanning and vulnerability patches
- Support for major Java versions and build tools

**Common Use Cases**
Typical scenarios where this container excels

- Continuous Integration/Continuous Deployment (CI/CD) pipelines
- Automated build and test environments
- Development workspace containerization
- Multi-module Java project builds

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/gradle:latest
```

```bash
docker pull registry.example.com/gradle:7.6.1-jdk17
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name gradle-build registry.example.com/gradle:latest gradle build
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name gradle-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v $PWD:/home/gradle/project \
  -w /home/gradle/project \
  registry.example.com/gradle:latest gradle build
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $PWD:/home/gradle/project -w /home/gradle/project registry.example.com/gradle:latest gradle build
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:8080 registry.example.com/gradle:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| GRADLE_HOME | /opt/gradle | Gradle installation directory |
| GRADLE_USER_HOME | /home/gradle/.gradle | Gradle user home directory |
| JAVA_HOME | /usr/lib/jvm/java-17 | Java installation directory |
| PATH | $GRADLE_HOME/bin:$JAVA_HOME/bin:$PATH | System PATH including Gradle and Java |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Run as non-root gradle user
- Mount Gradle cache as volume for better performance
- Enable Gradle build scan for security analysis
- Implement proper dependency verification
- Configure resource limits for builds
- Use checksums for dependency verification
- Regular security patches and updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
volumeMounts:
  - name: gradle-cache
    mountPath: /home/gradle/.gradle
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/gradle
- **Gradle Documentation**: https://docs.gradle.org