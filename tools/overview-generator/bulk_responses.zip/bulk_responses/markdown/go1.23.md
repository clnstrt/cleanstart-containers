**Container Documentation for Go1.23**

Enterprise-ready Go 1.23 runtime container optimized for cloud-native development and deployment. Features comprehensive development tools, security hardening, and production-ready configurations for building and running Go applications at scale.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/go1.23`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Integrated development runtime environment
- Built-in package management system
- Support for multiple programming paradigms
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- Web application development and deployment
- Data processing and analysis pipelines
- API service development
- Automation and scripting tasks

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/go1.23:latest
```

```bash
docker pull {registry.example.com}/go1.23:latest-dev
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name go1.23-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/go1.23:latest-dev /bin/sh
```

**Run Hello World**
Execute a simple Hello World program

```bash
docker run --rm {registry.example.com}/go1.23:latest-dev -c 'print("Hello, World!")'
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/go1.23:latest-dev go1.23 --version
```

**Application Server**
Run application with port forwarding

```bash
docker run -d --name go1.23-app \
  -p 8000:8000 \
  -v $(pwd):/app \
  -w /app \
  {registry.example.com}/go1.23:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| PATH | /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin | System PATH configuration |
| LANG | C.UTF-8 | Language and locale settings |
| GO1.23_VERSION | latest | Runtime version |
| HOME | /home/go1.23 | User home directory |

**Security Best Practices**
Recommended security configurations and practices

- Use specific runtime versions in production
- Implement proper dependency management
- Configure secure coding practices
- Regular security updates and vulnerability scanning
- Use read-only filesystems where possible
- Implement proper logging and monitoring
- Configure resource limits and constraints
- Use multi-stage builds for production images

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Go1.23 Official Documentation**: https://go1.23.org/