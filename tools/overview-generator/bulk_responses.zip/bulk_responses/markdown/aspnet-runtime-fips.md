**Container Documentation for Aspnet-Runtime-Fips**

ASP.NET Core runtime container with FIPS-compliant cryptographic modules, designed for secure enterprise applications requiring Federal Information Processing Standards compliance. Features hardened security configurations, optimized performance, and validated cryptographic implementations for regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/aspnet-runtime-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic modules
- Security-hardened runtime environment
- Optimized for enterprise deployment
- Multi-architecture support (amd64/arm64)

**Common Use Cases**
Typical scenarios where this container excels

- Government and regulated industry applications
- Financial services and healthcare systems
- Enterprise web applications requiring FIPS compliance
- Secure microservices deployments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/aspnet-runtime-fips:latest
```

```bash
docker pull {registry.example.com}/aspnet-runtime-fips:6.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name aspnet-fips-app {registry.example.com}/aspnet-runtime-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name aspnet-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  --health-cmd='curl -f http://localhost/health || exit 1' \
  --health-interval=30s \
  {registry.example.com}/aspnet-runtime-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/app:/app {registry.example.com}/aspnet-runtime-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 -p 8443:443 {registry.example.com}/aspnet-runtime-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ASPNETCORE_ENVIRONMENT | Production | Runtime environment setting |
| DOTNET_RUNNING_IN_CONTAINER | true | Container runtime indicator |
| ASPNETCORE_URLS | http://+:80 | HTTP listening endpoints |
| COMPlus_EnableDiagnostics | 0 | Diagnostics configuration |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Implement proper SSL/TLS certificate management
- Configure appropriate logging levels
- Regular security scanning and updates
- Use secrets management for sensitive data
- Enable health monitoring endpoints

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **ASP.NET Core Documentation**: https://docs.microsoft.com/aspnet/core
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance