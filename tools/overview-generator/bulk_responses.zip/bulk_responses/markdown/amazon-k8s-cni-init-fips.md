**Container Documentation for Amazon-K8S-Cni-Init-Fips**

Amazon Kubernetes CNI initialization container with FIPS compliance for secure network configuration in enterprise Kubernetes clusters. Provides essential network setup and configuration for AWS VPC CNI plugin while maintaining FIPS 140-2 compliance requirements.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/amazon-k8s-cni-init-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant networking components
- AWS VPC CNI plugin initialization and setup
- Kubernetes network policy configuration
- Secure container networking capabilities

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster network initialization
- AWS EKS cluster setup
- Regulated environment deployments
- Government cloud implementations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/amazon-k8s-cni-init-fips:latest
```

```bash
docker pull {registry.example.com}/amazon-k8s-cni-init-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name amazon-k8s-cni-init-fips-test {registry.example.com}/amazon-k8s-cni-init-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name amazon-k8s-cni-init-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/amazon-k8s-cni-init-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/amazon-k8s-cni-init-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/amazon-k8s-cni-init-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_VPC_K8S_CNI_LOGLEVEL | DEBUG | CNI plugin log level |
| AWS_VPC_ENI_MTU | 9001 | MTU size for network interfaces |
| DISABLE_TCP_EARLY_DEMUX | false | Disable TCP early demux |
| ENABLE_IPv4 | true | Enable IPv4 networking |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use specific image tags for version control
- Implement proper network policies
- Regular security scanning of container images
- Monitor CNI logs for security events
- Follow AWS security best practices
- Implement proper RBAC policies
- Regular audit of network configurations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_ADMIN", "NET_RAW"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/amazon-k8s-cni-init-fips
- **AWS VPC CNI Documentation**: https://github.com/aws/amazon-vpc-cni-k8s