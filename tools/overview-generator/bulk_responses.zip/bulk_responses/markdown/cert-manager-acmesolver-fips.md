**Container Documentation for Cert-Manager-Acmesolver-Fips**

FIPS-compliant ACME solver component for cert-manager, designed for automated certificate management and validation in enterprise Kubernetes environments. Provides secure, compliant certificate challenge resolution while maintaining FIPS 140-2 standards for cryptographic operations.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cert-manager-acmesolver-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic operations
- Automated ACME challenge resolution
- Kubernetes-native certificate management
- Enterprise-grade security compliance

**Common Use Cases**
Typical scenarios where this container excels

- Automated SSL/TLS certificate management
- FIPS-compliant environments requiring certificate automation
- Enterprise Kubernetes certificate orchestration
- Secure DNS challenge resolution

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cert-manager-acmesolver-fips:latest
```

```bash
docker pull {registry.example.com}/cert-manager-acmesolver-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cert-manager-acmesolver-fips-test {registry.example.com}/cert-manager-acmesolver-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cert-manager-acmesolver-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cert-manager-acmesolver-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/challenges:/challenges {registry.example.com}/cert-manager-acmesolver-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8089:8089 {registry.example.com}/cert-manager-acmesolver-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ACME_CHALLENGE_TYPE | http-01 | Type of ACME challenge to solve |
| ACME_TOKEN |  | Token for ACME challenge validation |
| ACME_KEY |  | Key for ACME challenge response |
| DEBUG | false | Enable debug logging |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production environments
- Use specific image tags for production deployments
- Implement proper network policies for challenge endpoints
- Regular security scanning of container images
- Monitor certificate lifecycle and renewal processes
- Implement proper access controls for certificate storage
- Use secure communication channels for ACME challenges
- Regular audit of certificate management processes

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cert-manager-acmesolver-fips
- **Cert-Manager Documentation**: https://cert-manager.io/docs/