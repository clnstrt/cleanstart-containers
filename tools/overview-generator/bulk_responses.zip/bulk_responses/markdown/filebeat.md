**Container Documentation for Filebeat**

Filebeat is a lightweight shipper for forwarding and centralizing log data. Installed as an agent on your servers, Filebeat monitors the log files or locations that you specify, collects log events, and forwards them to either Elasticsearch or Logstash for indexing. This container provides an optimized, security-hardened deployment of Filebeat suitable for enterprise environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/filebeat`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Lightweight log data collection and forwarding
- Automatic discovery of log sources
- Built-in modules for common log formats
- Secure data shipping with TLS encryption

**Common Use Cases**
Typical scenarios where this container excels

- Centralized logging infrastructure
- Container and Kubernetes log collection
- Application performance monitoring
- Security and compliance logging

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/filebeat:latest
```

```bash
docker pull {registry.example.com}/filebeat:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d \
  --name filebeat \
  --user root \
  --volume="$(pwd)/filebeat.yml:/usr/share/filebeat/filebeat.yml:ro" \
  --volume="/var/lib/docker/containers:/var/lib/docker/containers:ro" \
  --volume="/var/run/docker.sock:/var/run/docker.sock:ro" \
  {registry.example.com}/filebeat:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d \
  --name filebeat-prod \
  --user root \
  --security-opt=no-new-privileges \
  --volume="/etc/filebeat/filebeat.yml:/usr/share/filebeat/filebeat.yml:ro" \
  --volume="/var/log:/var/log:ro" \
  --volume="/var/lib/docker/containers:/var/lib/docker/containers:ro" \
  {registry.example.com}/filebeat:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d \
  --name filebeat \
  --volume="/path/to/logs:/logs:ro" \
  --volume="/path/to/filebeat.yml:/usr/share/filebeat/filebeat.yml:ro" \
  {registry.example.com}/filebeat:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d \
  --name filebeat \
  -p 5066:5066 \
  {registry.example.com}/filebeat:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ELASTICSEARCH_HOST | elasticsearch:9200 | Elasticsearch host address |
| ELASTICSEARCH_USERNAME | elastic | Elasticsearch authentication username |
| ELASTICSEARCH_PASSWORD |  | Elasticsearch authentication password |
| KIBANA_HOST | kibana:5601 | Kibana host address |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper access controls for log files
- Enable TLS encryption for data transmission
- Regularly rotate authentication credentials
- Monitor Filebeat metrics and performance
- Keep Filebeat configuration files read-only
- Use minimal required permissions for log access
- Implement proper log rotation policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsUser: 0
  privileged: false
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["CHOWN", "DAC_OVERRIDE", "FOWNER", "FSETID", "KILL", "SETGID", "SETUID"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/filebeat
- **Filebeat Documentation**: https://www.elastic.co/guide/en/beats/filebeat/current/index.html