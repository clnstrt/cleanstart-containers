**Container Documentation for Calico-Node-Driver-Registrar**

The Calico Node Driver Registrar is a critical component for Kubernetes clusters using Calico networking. It handles the registration of Calico's CNI driver with the Kubernetes container runtime, enabling proper network interface management and policy enforcement. This container is essential for establishing secure pod-to-pod networking and implementing network policies in enterprise Kubernetes environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-node-driver-registrar`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Automatic CNI driver registration with Kubernetes
- Seamless integration with Calico networking
- Support for multiple container runtimes
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- Kubernetes cluster networking setup
- Container network interface management
- Multi-cluster networking configurations
- Enterprise Kubernetes deployments

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/calico-node-driver-registrar:latest
```

```bash
docker pull {registry.example.com}/calico-node-driver-registrar:v3.24.0
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name calico-node-driver-registrar \
  --privileged \
  -v /var/lib/kubelet:/var/lib/kubelet \
  {registry.example.com}/calico-node-driver-registrar:latest /bin/sh
```

**Run Hello World**
Execute a simple test registration

```bash
docker run --rm {registry.example.com}/calico-node-driver-registrar:latest --version
```

**Mount Workspace**
Run container with required mounts

```bash
docker run --rm \
  -v /var/lib/kubelet:/var/lib/kubelet \
  -v /var/lib/kubelet/plugins:/var/lib/kubelet/plugins \
  {registry.example.com}/calico-node-driver-registrar:latest
```

**Kubernetes Deployment**
Deploy as part of Calico installation

```bash
kubectl apply -f https://raw.githubusercontent.com/projectcalico/calico/master/manifests/calico.yaml
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| KUBELET_REGISTRATION_PATH | /var/lib/kubelet/plugins/calico/cni-plugin.sock | Path for plugin registration |
| LOG_LEVEL | info | Logging verbosity level |
| DRIVER_NAME | calico | Name of the CNI driver |
| NODE_NAME |  | Kubernetes node name |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Implement proper RBAC policies
- Regular security updates and patches
- Monitor container logs for issues
- Use read-only root filesystem
- Configure resource limits
- Implement network policies
- Regular vulnerability scanning

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["SYS_ADMIN"]
  seLinuxOptions:
    type: spc_t
  readOnlyRootFilesystem: true
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Calico Documentation**: https://docs.projectcalico.org/
- **Kubernetes CSI Documentation**: https://kubernetes-csi.github.io/docs/