**Container Documentation for Argocd-Image-Updater-Fips**

ArgoCD Image Updater FIPS is a specialized container designed for automated image updates in Kubernetes deployments, with FIPS 140-2 compliance for enhanced security. It automatically monitors container registries for new versions of images used in ArgoCD applications and updates them according to defined policies, ensuring continuous delivery while maintaining security standards.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argocd-image-updater-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 compliant image updating capabilities
- Automated container image version detection
- Policy-based update automation
- Integration with multiple container registries

**Common Use Cases**
Typical scenarios where this runtime container excels

- Automated Kubernetes deployment updates
- Continuous delivery pipelines
- GitOps workflow automation
- Secure enterprise deployment automation

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argocd-image-updater-fips:latest
```

```bash
docker pull {registry.example.com}/argocd-image-updater-fips:stable
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argocd-image-updater-fips \
  -v ~/.kube:/home/argocd/.kube \
  -v ~/.config/argocd:/home/argocd/.config/argocd \
  {registry.example.com}/argocd-image-updater-fips:latest /bin/sh
```

**Run Hello World**
Execute a simple version check

```bash
docker run --rm {registry.example.com}/argocd-image-updater-fips:latest version
```

**Mount Workspace**
Run container with configuration mounted

```bash
docker run --rm -v $(pwd)/config:/app/config \
  {registry.example.com}/argocd-image-updater-fips:latest \
  --config /app/config/config.yaml
```

**Application Server**
Run image updater with ArgoCD server connection

```bash
docker run -d --name argocd-image-updater \
  -v ~/.kube:/home/argocd/.kube \
  -e ARGOCD_SERVER=argocd-server.default.svc.cluster.local \
  -e ARGOCD_INSECURE=false \
  {registry.example.com}/argocd-image-updater-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGOCD_SERVER | argocd-server.default.svc.cluster.local | ArgoCD server address |
| ARGOCD_INSECURE | false | Skip TLS verification for ArgoCD server |
| ARGOCD_TOKEN |  | ArgoCD API token |
| ARGOCD_GIT_COMMIT_USER | argocd-image-updater | Git commit author name |

**Security Best Practices**
Recommended security configurations and practices

- Use HTTPS for registry connections
- Implement proper RBAC policies
- Regular security patches and updates
- Use secure token management
- Enable audit logging
- Configure resource quotas
- Use network policies
- Regular security scanning

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 999
  runAsGroup: 999
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **ArgoCD Image Updater Documentation**: https://argocd-image-updater.readthedocs.io/