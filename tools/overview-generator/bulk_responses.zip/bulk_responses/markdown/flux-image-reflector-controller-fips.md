**Container Documentation for Flux-Image-Reflector-Controller-Fips**

The Flux Image Reflector Controller FIPS is a specialized container that automatically monitors container registries for image updates and synchronizes them with Kubernetes clusters. This FIPS-compliant version ensures compliance with Federal Information Processing Standards, making it suitable for government and highly regulated enterprise environments. It enables automated image updates, policy enforcement, and secure container image management within GitOps workflows.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-image-reflector-controller-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic modules
- Automated container image update detection
- Multi-registry support with secure authentication
- GitOps-native image policy enforcement

**Common Use Cases**
Typical scenarios where this container excels

- Government and regulated industry deployments
- Automated container image updates in Kubernetes
- Secure GitOps implementations
- Compliance-focused container environments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-image-reflector-controller-fips:latest
```

```bash
docker pull {registry.example.com}/flux-image-reflector-controller-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-image-reflector-controller-fips {registry.example.com}/flux-image-reflector-controller-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-image-reflector-controller-fips \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/kubernetes/config:/config \
  {registry.example.com}/flux-image-reflector-controller-fips:latest
```

**Volume Mount**
Mount configuration and credentials

```bash
docker run -v /path/to/config:/config -v /path/to/certs:/certs {registry.example.com}/flux-image-reflector-controller-fips:latest
```

**Port Forwarding**
Run with metrics endpoint exposed

```bash
docker run -p 8080:8080 {registry.example.com}/flux-image-reflector-controller-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| RUNTIME_NAMESPACE | flux-system | Namespace where the controller runs |
| WATCH_ALL_NAMESPACES | true | Watch for image repository objects in all namespaces |
| LOG_LEVEL | info | Controller log level |
| METRICS_PORT | 8080 | Port for metrics endpoint |

**Security Best Practices**
Recommended security configurations and practices

- Use FIPS mode enforcement flags
- Implement proper RBAC policies
- Secure registry credentials management
- Regular security scanning of images
- Network policy implementation
- Audit logging configuration
- Certificate rotation procedures
- Resource quota enforcement

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-image-reflector-controller-fips
- **FIPS Compliance Documentation**: https://{registry.example.com}/docs/fips-compliance