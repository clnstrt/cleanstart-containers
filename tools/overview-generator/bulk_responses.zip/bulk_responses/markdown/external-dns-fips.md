**Container Documentation for External-Dns-Fips**

ExternalDNS FIPS-compliant container for synchronizing exposed Kubernetes Services and Ingresses with DNS providers. Features FIPS 140-2 validated cryptographic modules and security hardening for enterprise environments requiring strict compliance standards.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/external-dns-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Automated DNS management for Kubernetes resources
- Support for multiple DNS providers
- Security-hardened configuration for enterprise use

**Common Use Cases**
Typical scenarios where this container excels

- Automated DNS record management in Kubernetes clusters
- Cloud-native DNS integration for microservices
- Multi-cloud DNS orchestration
- Compliance-focused environments requiring FIPS validation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/external-dns-fips:latest
```

```bash
docker pull {registry.example.com}/external-dns-fips:1.13.1-fips
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name external-dns {registry.example.com}/external-dns-fips:latest --provider=aws --source=service --source=ingress --domain-filter=example.com
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name external-dns-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v ${PWD}/config:/config \
  {registry.example.com}/external-dns-fips:latest \
  --provider=aws \
  --policy=sync \
  --registry=txt \
  --txt-owner-id=my-cluster
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v ${PWD}/config:/config {registry.example.com}/external-dns-fips:latest --provider=aws --config=/config/config.yaml
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 7979:7979 {registry.example.com}/external-dns-fips:latest --provider=aws --metrics-address=:7979
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_ACCESS_KEY_ID |  | AWS credentials access key |
| AWS_SECRET_ACCESS_KEY |  | AWS credentials secret key |
| AWS_REGION | us-east-1 | AWS region for DNS operations |
| EXTERNAL_DNS_LOG_LEVEL | info | Logging level (debug, info, warn, error) |

**Security Best Practices**
Recommended security configurations and practices

- Use IAM roles with minimal required permissions
- Enable FIPS mode for all cryptographic operations
- Implement proper RBAC in Kubernetes deployments
- Regular security scanning of container images
- Monitor DNS changes and maintain audit logs
- Use separate DNS zones for different environments

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **ExternalDNS Documentation**: https://{registry.example.com}/external-dns-fips/docs
- **FIPS Compliance Guide**: https://{registry.example.com}/external-dns-fips/fips-compliance