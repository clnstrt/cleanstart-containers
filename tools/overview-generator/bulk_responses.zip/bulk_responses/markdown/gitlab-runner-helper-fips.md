**Container Documentation for Gitlab-Runner-Helper-Fips**

GitLab Runner Helper FIPS container provides a FIPS-compliant environment for GitLab CI/CD job execution. This helper container is specifically designed to support GitLab Runner operations in environments requiring Federal Information Processing Standards (FIPS) compliance, making it suitable for government, healthcare, and other regulated enterprise environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/gitlab-runner-helper-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic modules
- Optimized for GitLab CI/CD job execution
- Security-hardened configuration for regulated environments
- Multi-architecture support for diverse deployment scenarios

**Common Use Cases**
Typical scenarios where this container excels

- Government and military CI/CD pipelines
- Healthcare software development environments
- Financial services deployment pipelines
- Regulated industry CI/CD workflows

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/gitlab-runner-helper-fips:latest
```

```bash
docker pull {registry.example.com}/gitlab-runner-helper-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name gitlab-runner-helper-fips-test {registry.example.com}/gitlab-runner-helper-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name gitlab-runner-helper-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/gitlab-runner-helper-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/builds:/builds {registry.example.com}/gitlab-runner-helper-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8093:8093 {registry.example.com}/gitlab-runner-helper-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CI_RUNNER_ID |  | GitLab Runner ID |
| CI_PROJECT_DIR | /builds | Project build directory |
| FIPS_MODE | enabled | FIPS mode configuration |
| RUNNER_HELPER_VERSION | latest | Helper version specification |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is properly enabled
- Use specific version tags in production
- Implement proper access controls for CI/CD environments
- Regular security scanning of container images
- Monitor for compliance violations
- Maintain audit logs of container activities
- Use secure communication channels
- Regular updates for security patches

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/gitlab-runner-helper-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance