**Container Documentation for Cert-Manager-Controller**

Cert-manager-controller is an automated certificate management solution for Kubernetes clusters. It simplifies the process of obtaining, renewing and using SSL/TLS certificates from various issuers including Let's Encrypt, HashiCorp Vault, and Venafi. This container provides enterprise-grade certificate management capabilities with automated certificate request handling, validation, and lifecycle management.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cert-manager-controller`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automated certificate issuance and renewal
- Multiple issuer support (ACME, Vault, Venafi)
- Kubernetes-native certificate management
- Certificate lifecycle automation

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes TLS certificate automation
- Multi-domain SSL certificate management
- Automated Let's Encrypt integration
- Enterprise PKI infrastructure automation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cert-manager-controller:latest
```

```bash
docker pull {registry.example.com}/cert-manager-controller:v1.12.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cert-manager {registry.example.com}/cert-manager-controller:latest --v=2 --cluster-resource-namespace=cert-manager
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cert-manager-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/cert-manager:/etc/cert-manager \
  {registry.example.com}/cert-manager-controller:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v /etc/cert-manager:/etc/cert-manager \
  -v /var/run/cert-manager:/var/run/cert-manager \
  {registry.example.com}/cert-manager-controller:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9402:9402 {registry.example.com}/cert-manager-controller:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| NAMESPACE | cert-manager | Namespace for cert-manager deployment |
| LOG_LEVEL | 2 | Logging verbosity level |
| LEADER_ELECTION_NAMESPACE | kube-system | Namespace for leader election |
| ACME_HTTP01_SOLVER_IMAGE | cert-manager-acmesolver | HTTP01 solver image |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies to restrict certificate management access
- Implement proper secret management for issuer credentials
- Regular audit of certificate requests and issuance
- Monitor certificate expiration and renewal events
- Use secure transport for certificate private keys
- Enable validation webhooks for certificate requests

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1001
  fsGroup: 1001
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cert-manager-controller
- **Cert-Manager Documentation**: https://cert-manager.io/docs/