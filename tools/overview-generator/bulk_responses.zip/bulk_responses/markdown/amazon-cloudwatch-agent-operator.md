**Container Documentation for Amazon-Cloudwatch-Agent-Operator**

The Amazon CloudWatch Agent Operator container provides automated deployment and management of CloudWatch agents in containerized environments. It enables comprehensive monitoring, metrics collection, and log aggregation for containerized workloads, supporting enterprise-grade observability and operational insights across container clusters.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/amazon-cloudwatch-agent-operator`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automated CloudWatch agent deployment and management
- Comprehensive metrics collection and monitoring
- Containerized log aggregation and forwarding
- Kubernetes-native operational integration

**Common Use Cases**
Typical scenarios where this container excels

- Container infrastructure monitoring
- Application performance tracking
- Log management and analysis
- Kubernetes cluster observability

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/amazon-cloudwatch-agent-operator:latest
```

```bash
docker pull {registry.example.com}/amazon-cloudwatch-agent-operator:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cloudwatch-operator {registry.example.com}/amazon-cloudwatch-agent-operator:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cloudwatch-operator-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /var/run/docker.sock:/var/run/docker.sock \
  {registry.example.com}/amazon-cloudwatch-agent-operator:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/cwagentconfig {registry.example.com}/amazon-cloudwatch-agent-operator:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8125:8125/udp {registry.example.com}/amazon-cloudwatch-agent-operator:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_REGION | us-east-1 | AWS region for CloudWatch |
| CW_CONFIG_CONTENT |  | CloudWatch agent configuration content |
| CLUSTER_NAME |  | Kubernetes cluster name |
| LOG_LEVEL | INFO | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Use IAM roles for authentication
- Implement least privilege access
- Enable encryption for metrics and logs
- Regular security patches and updates
- Network security group configuration
- Audit logging enabled

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_ADMIN", "NET_RAW"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/amazon-cloudwatch-agent-operator
- **AWS CloudWatch Documentation**: https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/