**Container Documentation for Crossplane-Fips**

FIPS-validated Crossplane container image designed for secure cloud infrastructure management and orchestration in regulated environments. Features enhanced security controls, STIG compliance, and enterprise-grade infrastructure provisioning capabilities.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/crossplane-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- Multi-cloud infrastructure orchestration
- Kubernetes-native resource management

**Common Use Cases**
Typical scenarios where this container excels

- Regulated cloud infrastructure management
- Secure multi-cloud resource provisioning
- Compliant Kubernetes cluster operations
- Enterprise infrastructure automation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/crossplane-fips:latest
```

```bash
docker pull {registry.example.com}/crossplane-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name crossplane-fips-test {registry.example.com}/crossplane-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name crossplane-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/crossplane-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/crossplane \
  -v $(pwd)/data:/var/lib/crossplane \
  {registry.example.com}/crossplane-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:8080 {registry.example.com}/crossplane-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CROSSPLANE_NAMESPACE | crossplane-system | Namespace for Crossplane resources |
| POD_NAMESPACE | crossplane-system | Kubernetes namespace for the pod |
| FIPS_MODE | enabled | FIPS mode configuration |
| LOG_LEVEL | info | Logging verbosity level |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use role-based access control (RBAC)
- Implement network policies for isolation
- Regular security compliance audits
- Monitor provider configurations
- Secure secret management
- Enable audit logging
- Regular vulnerability scanning

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/crossplane-fips
- **Security Compliance Guide**: https://{registry.example.com}/docs/compliance