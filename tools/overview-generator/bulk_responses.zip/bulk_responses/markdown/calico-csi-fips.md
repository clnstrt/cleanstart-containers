**Container Documentation for Calico-Csi-Fips**

Calico CSI FIPS container provides FIPS 140-2 compliant Container Storage Interface (CSI) implementation for Calico networking. It enables secure, compliant storage operations in regulated enterprise Kubernetes environments, offering encrypted volume management and access control features.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-csi-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Container Storage Interface (CSI) implementation
- Secure volume management capabilities
- Enterprise-grade access control features

**Common Use Cases**
Typical scenarios where this container excels

- Government and regulated industry deployments
- Secure container storage management
- Compliant Kubernetes environments
- Enterprise storage orchestration

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-csi-fips:latest
```

```bash
docker pull {registry.example.com}/calico-csi-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-csi-fips-test {registry.example.com}/calico-csi-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-csi-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/calico-csi-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/calico-csi-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/calico-csi-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CSI_ENDPOINT | unix:///csi/csi.sock | CSI endpoint socket path |
| FIPS_MODE | enabled | FIPS mode configuration |
| LOG_LEVEL | info | Logging level configuration |
| KUBERNETES_NODE_NAME |  | Node name in Kubernetes cluster |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Implement proper access controls for storage volumes
- Use secure communication channels for CSI operations
- Regular security audits of storage access patterns
- Monitor for compliance violations
- Implement encryption at rest for sensitive data
- Regular backup of critical storage volumes
- Maintain detailed access logs

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["SYS_ADMIN"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-csi-fips