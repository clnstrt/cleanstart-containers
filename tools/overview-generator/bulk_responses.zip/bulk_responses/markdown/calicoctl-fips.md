**Container Documentation for Calicoctl-Fips**

Calicoctl-FIPS is a FIPS 140-2 compliant command-line tool for managing Calico network policies and resources in Kubernetes environments. It provides secure network policy management, enhanced security controls, and compliance features for enterprise Kubernetes deployments requiring FIPS validation.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calicoctl-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant networking controls
- Kubernetes network policy management
- Security-hardened configuration
- Enterprise-grade access controls

**Common Use Cases**
Typical scenarios where this container excels

- Government and military deployments requiring FIPS compliance
- Enterprise Kubernetes network management
- Secure multi-tenant cluster environments
- Regulated industry deployments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calicoctl-fips:latest
```

```bash
docker pull {registry.example.com}/calicoctl-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -v /etc/calico:/etc/calico --name calicoctl-fips {registry.example.com}/calicoctl-fips:latest get nodes
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calicoctl-fips \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/calico:/etc/calico \
  {registry.example.com}/calicoctl-fips:latest
```

**Volume Mount**
Mount configuration directory for Calico

```bash
docker run -v /etc/calico:/etc/calico {registry.example.com}/calicoctl-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9091:9091 {registry.example.com}/calicoctl-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CALICO_DATASTORE_TYPE | kubernetes | Type of datastore (kubernetes or etcd) |
| KUBECONFIG | /etc/calico/kubeconfig | Path to Kubernetes config file |
| ETCD_ENDPOINTS |  | Comma-separated list of etcd endpoints |
| CALICO_NETWORKING_BACKEND | bird | Networking backend to use |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies for access control
- Enable TLS for all communications
- Implement network segmentation
- Regular security audits and updates
- Monitor network policy changes
- Use secure endpoints for etcd
- Implement proper backup procedures
- Regular compliance validation

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_ADMIN", "NET_RAW"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calicoctl-fips
- **Calico Documentation**: https://docs.projectcalico.org