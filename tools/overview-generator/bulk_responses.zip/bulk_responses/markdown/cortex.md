**Container Documentation for Cortex**

Cortex is an enterprise-grade observability platform container designed for collecting, storing, and analyzing machine data at scale. It provides powerful querying capabilities, alerting functions, and visualization tools for monitoring and troubleshooting distributed systems. Ideal for organizations requiring robust observability solutions with high reliability and security features.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/cortex`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- Scalable metrics collection and storage
- Advanced query and analytics capabilities
- Real-time alerting and notification system
- Multi-tenant architecture support

**Common Use Cases**
Typical scenarios where this container excels

- Enterprise monitoring and observability
- Distributed system metrics collection
- Log aggregation and analysis
- Performance monitoring and troubleshooting

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/cortex:latest
```

```bash
docker pull registry.example.com/cortex:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cortex-test registry.example.com/cortex:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cortex-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  registry.example.com/cortex:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data registry.example.com/cortex:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 registry.example.com/cortex:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CORTEX_AUTH_ENABLED | true | Enable authentication |
| CORTEX_STORAGE_PATH | /data | Data storage location |
| CORTEX_CLUSTER_NAME | cortex-cluster | Cluster identifier |
| CORTEX_LOG_LEVEL | info | Logging verbosity |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production (avoid latest)
- Configure resource limits: memory and CPU constraints
- Enable read-only root filesystem when possible
- Run containers with non-root user (--user 1000:1000)
- Use --security-opt=no-new-privileges flag
- Regularly update container images for security patches
- Implement proper network segmentation
- Monitor container metrics for anomalies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/cortex