**Container Documentation for Amazon-Cloudwatch-Agent-Fips**

The Amazon CloudWatch Agent FIPS container provides secure metrics and logs collection capabilities in compliance with Federal Information Processing Standards (FIPS). This agent enables monitoring of system and application metrics, log collection, and custom metrics gathering while maintaining FIPS 140-2 compliance for regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/amazon-cloudwatch-agent-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant monitoring capabilities
- Secure metrics and logs collection
- System and application performance monitoring
- Custom metrics support with FIPS encryption

**Common Use Cases**
Typical scenarios where this container excels

- Government and regulated industry deployments
- Secure cloud infrastructure monitoring
- Compliance-focused environments
- Enterprise security operations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/amazon-cloudwatch-agent-fips:latest
```

```bash
docker pull {registry.example.com}/amazon-cloudwatch-agent-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name cloudwatch-agent \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v /proc:/host/proc:ro \
  -v /sys:/host/sys:ro \
  {registry.example.com}/amazon-cloudwatch-agent-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cloudwatch-agent-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v /proc:/host/proc:ro \
  -v /sys:/host/sys:ro \
  -v /etc/cwagent/config.json:/etc/cwagent/config.json:ro \
  {registry.example.com}/amazon-cloudwatch-agent-fips:latest
```

**Volume Mount**
Mount configuration and log directories

```bash
docker run -d \
  -v /etc/cwagent:/etc/cwagent \
  -v /var/log:/var/log:ro \
  {registry.example.com}/amazon-cloudwatch-agent-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d -p 8125:8125/udp {registry.example.com}/amazon-cloudwatch-agent-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_REGION | us-east-1 | AWS region for CloudWatch |
| CW_CONFIG_CONTENT |  | CloudWatch Agent configuration as JSON string |
| CWAGENT_USER | cwagent | User to run the CloudWatch agent |
| CWAGENT_GROUP | cwagent | Group to run the CloudWatch agent |

**Security Best Practices**
Recommended security configurations and practices

- Use IAM roles for AWS authentication
- Implement least privilege access principles
- Enable FIPS mode in configuration
- Regular security patches and updates
- Secure configuration file permissions
- Monitor agent logs for security events
- Use encrypted communications
- Implement proper access controls

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["SYS_PTRACE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/amazon-cloudwatch-agent-fips