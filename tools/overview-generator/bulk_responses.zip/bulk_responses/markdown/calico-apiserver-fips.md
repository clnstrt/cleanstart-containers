**Container Documentation for Calico-Apiserver-Fips**

Calico API server FIPS-compliant container providing secure network policy management and enforcement for Kubernetes clusters. Features FIPS 140-2 validated cryptographic modules, enhanced security controls, and enterprise-grade network policy capabilities for regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-apiserver-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Enhanced security controls for regulated environments
- Kubernetes network policy management
- Enterprise-grade security compliance

**Common Use Cases**
Typical scenarios where this container excels

- Government and military deployments requiring FIPS compliance
- Financial services Kubernetes environments
- Healthcare systems requiring strict security controls
- Enterprise network policy management

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-apiserver-fips:latest
```

```bash
docker pull {registry.example.com}/calico-apiserver-fips:v3.26.0-fips
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name calico-apiserver-fips \
  --network host \
  {registry.example.com}/calico-apiserver-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-apiserver-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  --network host \
  -v /etc/kubernetes:/etc/kubernetes \
  {registry.example.com}/calico-apiserver-fips:latest
```

**Volume Mount**
Mount required Kubernetes configuration

```bash
docker run -v /etc/kubernetes:/etc/kubernetes:ro \
  -v /var/lib/calico:/var/lib/calico \
  {registry.example.com}/calico-apiserver-fips:latest
```

**Port Forwarding**
Run with API server port mappings

```bash
docker run -p 5443:5443 {registry.example.com}/calico-apiserver-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CALICO_DATASTORE_TYPE | kubernetes | Backend datastore type |
| KUBECONFIG | /etc/kubernetes/admin.conf | Path to Kubernetes configuration |
| FIPS_MODE | true | Enable FIPS mode |
| LOG_LEVEL | info | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled and properly configured
- Use specific version tags for production deployments
- Implement strict network policies
- Regular security audits and compliance checks
- Monitor API server logs for security events
- Implement proper RBAC policies
- Use secure communication channels
- Regular vulnerability scanning

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_ADMIN", "NET_RAW"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-apiserver-fips
- **Calico Documentation**: https://docs.projectcalico.org