**Container Documentation for Argocd-Repo-Server**

ArgoCD Repository Server is a critical component of the ArgoCD GitOps continuous delivery tool for Kubernetes. It is responsible for maintaining a local cache of Git repositories and generating Kubernetes manifests by utilizing configured tools and plugins. The server handles repository access, caching, and processing of application manifests, supporting multiple config management tools including Kustomize, Helm, and Jsonnet.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argocd-repo-server`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Git repository caching and management
- Support for multiple config management tools (Helm, Kustomize, Jsonnet)
- Plugin architecture for custom manifest generation
- Secure repository access and credential management

**Common Use Cases**
Typical scenarios where this runtime container excels

- GitOps-based continuous delivery workflows
- Kubernetes manifest generation and processing
- Multi-cluster application deployment
- Configuration management automation

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argocd-repo-server:latest
```

```bash
docker pull {registry.example.com}/argocd-repo-server:v2.8.0
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argocd-repo-server-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argocd-repo-server:latest /bin/sh
```

**Run Hello World**
Execute a simple Hello World program

```bash
docker run --rm {registry.example.com}/argocd-repo-server:latest argocd-repo-server version
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/argocd-repo-server:latest
```

**Application Server**
Run application with port forwarding

```bash
docker run -d --name argocd-repo-server \
  -p 8081:8081 \
  -v /tmp/argocd-repo:/tmp/argocd-repo \
  {registry.example.com}/argocd-repo-server:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGOCD_REPO_SERVER_LOGFORMAT | text | Log format (text|json) |
| ARGOCD_REPO_SERVER_LOGLEVEL | info | Log level |
| ARGOCD_REPO_SERVER_PORT | 8081 | Server listen port |
| ARGOCD_REPO_SERVER_CACHE_DIR | /tmp/argocd-repo | Repository cache directory |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Implement proper repository access controls
- Regularly update to latest security patches
- Configure TLS for repository connections
- Use secure credential management
- Enable audit logging
- Implement resource quotas
- Use read-only root filesystem

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 999
  fsGroup: 999
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **ArgoCD Documentation**: https://argo-cd.readthedocs.io/
- **Repository Server Guide**: https://argo-cd.readthedocs.io/en/stable/operator-manual/repo-server/