**Container Documentation for Fluent-Watcher**

Fluent-Watcher is an enterprise-grade container solution for log monitoring, aggregation, and analysis. It provides real-time log streaming capabilities, advanced filtering, and seamless integration with popular logging backends. Designed for scalability and performance in containerized environments, it supports distributed logging architectures and offers comprehensive monitoring features for cloud-native applications.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/fluent-watcher`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Real-time log streaming and aggregation
- Advanced filtering and pattern matching
- Multiple output plugin support
- High-performance log processing

**Common Use Cases**
Typical scenarios where this container excels

- Centralized logging infrastructure
- Container log management
- Application performance monitoring
- Security event logging

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/fluent-watcher:latest
```

```bash
docker pull {registry.example.com}/fluent-watcher:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name fluent-watcher-test {registry.example.com}/fluent-watcher:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name fluent-watcher-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/fluent-watcher:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/fluent-watcher:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/fluent-watcher:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLUENT_WATCHER_PORT | 24224 | Port for receiving log data |
| FLUENT_WATCHER_HOST | 0.0.0.0 | Binding address for the service |
| LOG_LEVEL | info | Logging level (debug, info, warn, error) |
| BUFFER_SIZE | 256m | Maximum buffer size for log processing |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production (avoid latest)
- Configure resource limits: memory and CPU constraints
- Enable read-only root filesystem when possible
- Run containers with non-root user (--user 1000:1000)
- Use --security-opt=no-new-privileges flag
- Regularly update container images for security patches
- Implement proper network segmentation
- Monitor container metrics for anomalies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/fluent-watcher