**Container Documentation for Argocd-Exetension-Installer-Fips**

A specialized container image designed for installing and managing ArgoCD extensions in FIPS-compliant environments. This container provides tools and utilities necessary for deploying, configuring, and maintaining ArgoCD extensions while ensuring compliance with Federal Information Processing Standards (FIPS).

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argocd-exetension-installer-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 compliant installation environment
- Automated ArgoCD extension deployment capabilities
- Secure package verification and installation
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- Installing ArgoCD extensions in regulated environments
- Automated deployment pipelines requiring FIPS compliance
- Secure GitOps implementation
- Enterprise Kubernetes deployment automation

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argocd-exetension-installer-fips:latest
```

```bash
docker pull {registry.example.com}/argocd-exetension-installer-fips:latest-dev
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argocd-extension-installer \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argocd-exetension-installer-fips:latest-dev /bin/sh
```

**Run Hello World**
Execute a simple Hello World program

```bash
docker run --rm {registry.example.com}/argocd-exetension-installer-fips:latest-dev version
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/extensions -w /extensions {registry.example.com}/argocd-exetension-installer-fips:latest install --extension-name=example
```

**Application Server**
Run application with port forwarding

```bash
docker run -d --name argocd-extension-installer \
  -v $(pwd):/extensions \
  -w /extensions \
  {registry.example.com}/argocd-exetension-installer-fips:latest serve
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FIPS_MODE | enabled | FIPS mode configuration |
| ARGOCD_EXTENSION_PATH | /extensions | Extension installation path |
| INSTALLER_LOG_LEVEL | info | Logging level configuration |
| VERIFY_SIGNATURES | true | Extension signature verification |

**Security Best Practices**
Recommended security configurations and practices

- Always verify extension signatures before installation
- Use specific version tags instead of latest
- Implement proper access controls for extension repositories
- Regular security scanning of installed extensions
- Maintain audit logs of installation activities
- Use read-only filesystem mounts where possible
- Configure resource limits for installer container
- Regular updates to maintain security compliance

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **ArgoCD Documentation**: https://argo-cd.readthedocs.io/
- **FIPS 140-2 Documentation**: https://csrc.nist.gov/publications/detail/fips/140/2/final