**Container Documentation for Flux-Fips**

FIPS-validated container image for Flux, the GitOps continuous delivery solution for Kubernetes. This hardened image provides secure, compliant GitOps operations for regulated enterprise environments, featuring FIPS 140-2 cryptographic modules and STIG-aligned security controls.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- GitOps workflow automation capabilities
- Kubernetes-native deployment management

**Common Use Cases**
Typical scenarios where this container excels

- Regulated enterprise GitOps deployments
- Government and military Kubernetes environments
- Financial services continuous delivery
- Healthcare infrastructure automation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-fips:latest
```

```bash
docker pull {registry.example.com}/flux-fips:1.0.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-fips {registry.example.com}/flux-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --cap-drop ALL \
  --user 1000:1000 \
  {registry.example.com}/flux-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/git-repo:/git-repo {registry.example.com}/flux-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9000:9000 {registry.example.com}/flux-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLUX_URL | http://localhost:9000 | Flux API endpoint URL |
| GITHUB_TOKEN |  | GitHub authentication token |
| FLUX_NAMESPACE | flux-system | Kubernetes namespace for Flux |
| GIT_BRANCH | main | Git branch to monitor |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled and operational
- Use secure Git repository connections (HTTPS/SSH)
- Implement proper RBAC policies
- Regular security scanning of manifests
- Enable audit logging for all operations
- Use sealed secrets for sensitive data
- Configure network policies
- Regular container image updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance
- **Security Hardening Guide**: https://{registry.example.com}/docs/security-hardening