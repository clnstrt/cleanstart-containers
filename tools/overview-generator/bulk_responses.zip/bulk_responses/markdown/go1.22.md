**Container Documentation for Go1.22**

Official Go 1.22 container image optimized for enterprise cloud-native development. Features the latest Go 1.22 runtime with enhanced security, performance optimizations, and enterprise-ready configurations. Ideal for building and deploying modern microservices, web applications, and cloud-native solutions.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/go1.22`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Complete Go 1.22 development environment with standard library
- Optimized for cloud-native development and microservices
- Enhanced security features and enterprise hardening
- Built-in dependency management and module support

**Common Use Cases**
Typical scenarios where this runtime container excels

- Cloud-native microservices development
- High-performance web services and APIs
- System utilities and DevOps tooling
- Enterprise application development

**Pull Commands**
Download the runtime container images

```bash
docker pull registry.example.com/go1.22:latest
```

```bash
docker pull registry.example.com/go1.22:1.22.0
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name go1.22-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  registry.example.com/go1.22:latest /bin/sh
```

**Run Hello World**
Execute a simple Hello World program

```bash
docker run --rm registry.example.com/go1.22:latest go run -e 'package main; func main() { println("Hello, World!") }'
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app registry.example.com/go1.22:latest go version
```

**Application Server**
Run application with port forwarding

```bash
docker run -d --name go1.22-app \
  -p 8080:8080 \
  -v $(pwd):/app \
  -w /app \
  registry.example.com/go1.22:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| GOPATH | /go | Go workspace directory |
| GOROOT | /usr/local/go | Go installation directory |
| GO111MODULE | on | Module support configuration |
| GOOS | linux | Target operating system |

**Security Best Practices**
Recommended security configurations and practices

- Use explicit version tags in production
- Implement proper dependency verification
- Enable Go modules checksum database
- Regular security updates and vulnerability scanning
- Configure appropriate resource limits
- Use multi-stage builds for minimal production images

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Go Documentation**: https://golang.org/doc/
- **Go Security Policy**: https://golang.org/security