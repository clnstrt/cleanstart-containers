**Container Documentation for Frr-Fips (Frr + Openssl-Fips)**

FRR (Free Range Routing) container with FIPS-validated OpenSSL integration, providing enterprise-grade routing capabilities with FIPS 140-2 compliance. This container combines the robust routing suite of FRR with FIPS-validated cryptographic modules for secure network routing in regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/frr-fips (frr + openssl-fips)`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Complete routing protocol suite (BGP, OSPF, IS-IS, RIP)
- Security-hardened configuration baseline
- Enterprise-ready routing capabilities

**Common Use Cases**
Typical scenarios where this container excels

- Secure enterprise network routing
- Government and military network deployments
- Regulated industry networking solutions
- FIPS-compliant infrastructure routing

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/frr-fips:latest
```

```bash
docker pull {registry.example.com}/frr-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name frr-fips-test --privileged --net=host {registry.example.com}/frr-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name frr-fips-prod \
  --privileged \
  --net=host \
  -v /etc/frr:/etc/frr \
  -v /etc/frr/fips:/etc/frr/fips \
  {registry.example.com}/frr-fips:latest
```

**Volume Mount**
Mount local directory for persistent configuration

```bash
docker run -v $(pwd)/frr-config:/etc/frr {registry.example.com}/frr-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 179:179 -p 2601:2601 {registry.example.com}/frr-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FRR_CONFIG_FILE | /etc/frr/frr.conf | FRR configuration file path |
| FIPS_MODE | enabled | Enable/disable FIPS mode |
| DAEMON_OPTIONS |  | Additional daemon options |
| LOG_LEVEL | info | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is properly enabled
- Implement secure BGP authentication
- Configure access control lists (ACLs)
- Regular security patch updates
- Monitor routing protocol security
- Implement route filtering
- Use secure passwords for routing protocols
- Enable logging and auditing

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["NET_ADMIN", "SYS_ADMIN"]
  allowPrivilegeEscalation: true
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **FRR Documentation**: https://frrouting.org/doc/
- **FIPS 140-2 Documentation**: https://csrc.nist.gov/publications/detail/fips/140/2/final