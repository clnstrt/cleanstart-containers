**Container Documentation for Flux-Notification-Controller-Bitnami-Compat-Fips**

A FIPS-compliant notification controller for Flux CD, designed for enterprise Kubernetes environments. This container provides secure event handling and notification delivery for GitOps workflows, with added compatibility for Bitnami environments and FIPS 140-2 validation.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-notification-controller-bitnami-compat-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Bitnami compatibility layer for enterprise environments
- Integrated notification handling for Flux CD events
- Secure event processing and delivery mechanisms

**Common Use Cases**
Typical scenarios where this container excels

- GitOps workflow notification management
- Kubernetes cluster state change monitoring
- Compliance-focused deployment notifications
- Enterprise GitOps automation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-notification-controller-bitnami-compat-fips:latest
```

```bash
docker pull {registry.example.com}/flux-notification-controller-bitnami-compat-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-notification-controller {registry.example.com}/flux-notification-controller-bitnami-compat-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-notification-controller \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/flux/notifications:/etc/flux/notifications \
  {registry.example.com}/flux-notification-controller-bitnami-compat-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/notifications:/etc/flux/notifications {registry.example.com}/flux-notification-controller-bitnami-compat-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9292:9292 {registry.example.com}/flux-notification-controller-bitnami-compat-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| NOTIFICATION_CONTROLLER_LOG_LEVEL | info | Log level (debug, info, warn, error) |
| NOTIFICATION_CONTROLLER_METRICS_ADDR | :9292 | Metrics server bind address |
| NOTIFICATION_CONTROLLER_WATCH_ALL_NAMESPACES | true | Watch for changes in all namespaces |
| NOTIFICATION_CONTROLLER_CONCURRENT | 2 | Number of concurrent notification providers |

**Security Best Practices**
Recommended security configurations and practices

- Use FIPS mode for all cryptographic operations
- Implement proper RBAC policies in Kubernetes
- Secure notification endpoints with TLS
- Regular security scanning of deployed images
- Monitor notification controller logs
- Use sealed secrets for sensitive configurations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-notification-controller-bitnami-compat-fips
- **Flux Documentation**: https://fluxcd.io/docs/