**Container Documentation for Argo Workflow (Argo-Workflows-Cli) Fips**

Enterprise-grade Argo Workflows CLI container with FIPS-validated cryptographic modules. Provides command-line tools for managing and interacting with Argo Workflows, a container-native workflow engine for orchestrating parallel jobs on Kubernetes. Features enhanced security controls and compliance with Federal Information Processing Standards.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/Argo Workflow (argo-workflows-cli) fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 validated cryptographic modules
- Complete Argo Workflows CLI toolkit
- Kubernetes-native workflow management
- Enterprise security hardening and compliance

**Common Use Cases**
Typical scenarios where this runtime container excels

- CI/CD pipeline orchestration
- Machine learning workflows
- Data processing pipelines
- Batch job automation

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/Argo Workflow (argo-workflows-cli) fips:latest
```

```bash
docker pull {registry.example.com}/Argo Workflow (argo-workflows-cli) fips:stable
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-workflows-cli \
  -v ~/.kube:/root/.kube \
  {registry.example.com}/Argo Workflow (argo-workflows-cli) fips:latest bash
```

**Run Hello World**
Execute a simple workflow submission

```bash
docker run --rm \
  -v ~/.kube:/root/.kube \
  {registry.example.com}/Argo Workflow (argo-workflows-cli) fips:latest \
  submit --watch hello-world.yaml
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm \
  -v $(pwd):/workspace \
  -v ~/.kube:/root/.kube \
  -w /workspace \
  {registry.example.com}/Argo Workflow (argo-workflows-cli) fips:latest \
  list
```

**Application Server**
Run Argo server with port forwarding

```bash
docker run -d --name argo-workflows \
  -p 2746:2746 \
  -v ~/.kube:/root/.kube \
  {registry.example.com}/Argo Workflow (argo-workflows-cli) fips:latest \
  server
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGO_SERVER | localhost:2746 | Argo Workflows API server address |
| KUBECONFIG | /root/.kube/config | Kubernetes configuration file path |
| ARGO_NAMESPACE | argo | Kubernetes namespace for Argo operations |
| ARGO_TOKEN |  | Authentication token for Argo server |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC for access control
- Enable audit logging
- Implement network policies
- Regular security patches and updates
- Use secrets management
- Configure resource quotas
- Enable pod security policies
- Implement proper authentication

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 999
  runAsGroup: 999
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo Workflows Documentation**: https://argoproj.github.io/argo-workflows/
- **FIPS Security Guide**: https://{registry.example.com}/docs/fips