**Container Documentation for Gitea**

Gitea is a lightweight, self-hosted Git service providing a complete DevOps platform for version control, issue tracking, and CI/CD integration. This enterprise-ready container image offers a secure, scalable solution for organizations requiring on-premises source code management with features comparable to GitHub.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/gitea`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Self-hosted Git service with web interface
- Built-in issue tracking and wiki functionality
- Integrated CI/CD pipeline support
- LDAP/OAuth authentication integration

**Common Use Cases**
Typical scenarios where this container excels

- Enterprise source code management
- Internal development collaboration
- Code review and pull request workflows
- Automated CI/CD environments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/gitea:latest
```

```bash
docker pull {registry.example.com}/gitea:1.20
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name gitea \
  -p 3000:3000 \
  -p 22:22 \
  -v gitea-data:/data \
  {registry.example.com}/gitea:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name gitea-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user git:git \
  -v gitea-data:/data \
  -p 3000:3000 \
  -p 22:22 \
  {registry.example.com}/gitea:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d \
  -v $(pwd)/gitea:/data \
  -v $(pwd)/conf:/etc/gitea \
  {registry.example.com}/gitea:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d \
  -p 8080:3000 \
  -p 2222:22 \
  {registry.example.com}/gitea:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| GITEA_CUSTOM | /data/gitea | Custom configuration directory |
| USER_UID | 1000 | User ID for git user |
| USER_GID | 1000 | Group ID for git user |
| GITEA_APP_NAME | Gitea | Application name |

**Security Best Practices**
Recommended security configurations and practices

- Use HTTPS for all Git operations
- Enable SSH key authentication
- Implement regular backup procedures
- Configure proper access controls
- Use secure password policies
- Enable audit logging
- Regular security updates
- Configure rate limiting

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/gitea
- **Gitea Documentation**: https://docs.gitea.io