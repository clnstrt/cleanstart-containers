**Container Documentation for Argo-Workflowcontroller**

Argo Workflow Controller is a Kubernetes-native workflow engine for orchestrating parallel jobs and managing complex workflows. It provides a robust platform for defining and executing multi-step workflows as Kubernetes resources, supporting DAG and step-based workflows, artifact management, and complex dependency management for enterprise container orchestration.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argo-workflowcontroller`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Kubernetes-native workflow orchestration
- DAG and step-based workflow support
- Artifact management and versioning
- Complex dependency management

**Common Use Cases**
Typical scenarios where this runtime container excels

- CI/CD pipeline orchestration
- Machine learning workflows
- Data processing pipelines
- Batch job scheduling

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argo-workflowcontroller:latest
```

```bash
docker pull {registry.example.com}/argo-workflowcontroller:stable
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-workflow-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argo-workflowcontroller:latest /bin/sh
```

**Run Hello World**
Execute a simple workflow

```bash
kubectl create -f https://raw.githubusercontent.com/argoproj/argo-workflows/master/examples/hello-world.yaml
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/workflows -w /workflows {registry.example.com}/argo-workflowcontroller:latest argo submit workflow.yaml
```

**Application Server**
Run workflow controller with port forwarding

```bash
docker run -d --name argo-workflow-controller \
  -p 2746:2746 \
  -v ~/.kube:/root/.kube \
  {registry.example.com}/argo-workflowcontroller:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGO_NAMESPACE | default | Kubernetes namespace for workflows |
| WORKFLOW_CONTROLLER_CONFIGMAP | workflow-controller-configmap | ConfigMap for controller configuration |
| WORKFLOW_WORKERS | 8 | Number of workflow workers |
| WORKFLOW_POD_CLEANUP_DELAY | 5s | Delay before pod cleanup |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC for workflow access control
- Enable workflow RBAC enforcement
- Implement artifact repository security
- Configure secure pod security contexts
- Use secrets management for sensitive data
- Enable audit logging
- Regular security patches and updates
- Network policy configuration

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 8737
  runAsGroup: 8737
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo Workflows Documentation**: https://argoproj.github.io/argo-workflows/
- **GitHub Repository**: https://github.com/argoproj/argo-workflows