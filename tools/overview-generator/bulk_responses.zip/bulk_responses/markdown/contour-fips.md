**Container Documentation for Contour-Fips**

Contour-FIPS is a FIPS 140-2 validated Kubernetes ingress controller that provides enterprise-grade traffic routing, load balancing, and TLS termination capabilities. Built on Envoy proxy technology, it ensures secure and efficient traffic management for cloud-native applications while maintaining compliance with federal security standards.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/contour-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Advanced HTTP/HTTPS routing and load balancing
- Native Kubernetes integration with CRDs
- TLS termination and certificate management
- Dynamic configuration updates without downtime
- Comprehensive metrics and monitoring support

**Common Use Cases**
Typical scenarios where this container excels

- Federal and regulated industry Kubernetes deployments
- Enterprise-grade ingress traffic management
- Multi-tenant Kubernetes clusters
- Zero-trust security architectures
- High-availability production workloads

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/contour-fips:latest
```

```bash
docker pull {registry.example.com}/contour-fips:1.24-fips
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name contour-fips \
  -p 8001:8001 \
  -v $PWD/config:/config \
  {registry.example.com}/contour-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name contour-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -p 8001:8001 \
  -v $PWD/config:/config:ro \
  -v $PWD/certs:/certs:ro \
  {registry.example.com}/contour-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $PWD/config:/config:ro \
  -v $PWD/certs:/certs:ro \
  {registry.example.com}/contour-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8001:8001 -p 8000:8000 {registry.example.com}/contour-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CONTOUR_NAMESPACE | projectcontour | Kubernetes namespace for Contour |
| CONTOUR_CERT_PATH | /certs | Path to TLS certificates |
| CONTOUR_CONFIG_PATH | /config/contour.yaml | Path to configuration file |
| CONTOUR_FIPS_MODE | true | Enable FIPS mode |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use TLS 1.2 or higher for all connections
- Implement proper RBAC policies
- Regular security scanning of deployed images
- Monitor audit logs for security events
- Use secure communication channels for config updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_BIND_SERVICE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/contour-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance