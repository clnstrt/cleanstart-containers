**Container Documentation for Amazon-K8S-Cni-Init**

Amazon Kubernetes CNI initialization container that configures networking components for Amazon EKS clusters. This container handles VPC networking setup, IP address management, and pod networking configuration for Kubernetes deployments on AWS infrastructure.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/amazon-k8s-cni-init`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- AWS VPC CNI plugin initialization and configuration
- Kubernetes networking setup automation
- IP address management for pod networking
- Multi-architecture support for diverse deployments

**Common Use Cases**
Typical scenarios where this container excels

- Amazon EKS cluster initialization
- Kubernetes networking configuration
- AWS VPC integration setup
- Container network interface management

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/amazon-k8s-cni-init:latest
```

```bash
docker pull {registry.example.com}/amazon-k8s-cni-init:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name amazon-k8s-cni-init-test {registry.example.com}/amazon-k8s-cni-init:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name amazon-k8s-cni-init-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  --net=host \
  --cap-add=NET_ADMIN \
  {registry.example.com}/amazon-k8s-cni-init:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v /opt/cni/bin:/host/opt/cni/bin \
  -v /etc/cni:/host/etc/cni \
  {registry.example.com}/amazon-k8s-cni-init:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run --net=host {registry.example.com}/amazon-k8s-cni-init:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_VPC_K8S_CNI_LOGLEVEL | DEBUG | Sets the logging level for the CNI |
| AWS_VPC_ENI_MTU | 9001 | Sets the MTU size for the network interface |
| AWS_VPC_K8S_CNI_EXTERNALSNAT | false | Configures SNAT for external traffic |
| AWS_VPC_K8S_CNI_VETHPREFIX | eni | Sets the prefix for the virtual ethernet interface |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper RBAC policies in Kubernetes
- Limit network access to required AWS services only
- Regular security updates and patch management
- Monitor CNI logs for security events
- Use AWS IAM roles for service accounts
- Implement network policies for pod isolation
- Regular security scanning of container images

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["NET_ADMIN"]
  allowPrivilegeEscalation: true
  readOnlyRootFilesystem: true
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/amazon-k8s-cni-init
- **AWS VPC CNI Documentation**: https://github.com/aws/amazon-vpc-cni-k8s