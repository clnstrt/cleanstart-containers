**Container Documentation for Cert-Manager-Cmctl**

Cert-manager-cmctl is a command-line interface tool for managing and interacting with cert-manager resources in Kubernetes clusters. It provides essential functionality for certificate management, validation, and troubleshooting in enterprise environments requiring robust TLS certificate automation.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cert-manager-cmctl`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Certificate management and validation tools
- Kubernetes integration for certificate automation
- TLS certificate lifecycle management
- Troubleshooting and diagnostic capabilities

**Common Use Cases**
Typical scenarios where this container excels

- Automated TLS certificate management
- Kubernetes certificate validation
- Certificate renewal automation
- SSL/TLS infrastructure maintenance

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cert-manager-cmctl:latest
```

```bash
docker pull {registry.example.com}/cert-manager-cmctl:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cert-manager-cmctl {registry.example.com}/cert-manager-cmctl:latest status
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cert-manager-cmctl \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v $HOME/.kube:/home/user/.kube:ro \
  {registry.example.com}/cert-manager-cmctl:latest
```

**Volume Mount**
Mount Kubernetes configuration for cluster access

```bash
docker run -v $HOME/.kube:/home/user/.kube:ro {registry.example.com}/cert-manager-cmctl:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9402:9402 {registry.example.com}/cert-manager-cmctl:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| KUBECONFIG | /home/user/.kube/config | Path to Kubernetes configuration file |
| NAMESPACE | cert-manager | Target Kubernetes namespace |
| LOG_LEVEL | info | Logging verbosity level |

**Security Best Practices**
Recommended security configurations and practices

- Use read-only filesystem mounts for kubeconfig
- Implement RBAC policies for cluster access
- Regular certificate rotation and monitoring
- Secure storage of certificate private keys
- Audit logging for certificate operations
- Network policy implementation

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cert-manager-cmctl
- **Cert-Manager Documentation**: https://cert-manager.io/docs/