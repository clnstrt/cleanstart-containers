**Container Documentation for Cert-Manager-Cmctl-Fips**

A FIPS-compliant command-line tool (cmctl) for managing and interacting with cert-manager resources in Kubernetes clusters. This container provides secure certificate management capabilities while maintaining compliance with Federal Information Processing Standards (FIPS 140-2).

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cert-manager-cmctl-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant certificate management
- Secure Kubernetes certificate automation
- Command-line interface for cert-manager operations
- Enterprise-grade security compliance

**Common Use Cases**
Typical scenarios where this container excels

- Managing TLS certificates in Kubernetes clusters
- Automating certificate issuance and renewal
- Certificate lifecycle management in regulated environments
- FIPS-compliant certificate operations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cert-manager-cmctl-fips:latest
```

```bash
docker pull {registry.example.com}/cert-manager-cmctl-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cert-manager-cmctl {registry.example.com}/cert-manager-cmctl-fips:latest status
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cert-manager-cmctl-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v $HOME/.kube/config:/home/user/.kube/config:ro \
  {registry.example.com}/cert-manager-cmctl-fips:latest
```

**Volume Mount**
Mount Kubernetes configuration for cluster access

```bash
docker run -v $HOME/.kube:/home/user/.kube:ro {registry.example.com}/cert-manager-cmctl-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9402:9402 {registry.example.com}/cert-manager-cmctl-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| KUBECONFIG | /home/user/.kube/config | Path to Kubernetes configuration file |
| HOME | /home/user | User home directory |
| USER | user | Default username |
| CMCTL_DEBUG | false | Enable debug logging |

**Security Best Practices**
Recommended security configurations and practices

- Mount Kubernetes configuration as read-only
- Use specific version tags instead of latest
- Run container with non-root user
- Enable read-only root filesystem
- Implement proper RBAC policies
- Regular security updates and patches
- Audit certificate operations
- Monitor for compliance violations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cert-manager-cmctl-fips
- **Cert-Manager Documentation**: https://cert-manager.io/docs/