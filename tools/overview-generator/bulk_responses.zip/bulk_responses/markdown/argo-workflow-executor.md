**Container Documentation for Argo-Workflow-Executor**

Argo Workflow Executor is a specialized container designed to execute individual steps within Argo Workflows, providing a robust environment for running workflow tasks in Kubernetes. It handles task execution, artifact management, script running, and resource cleanup within workflow pods, making it an essential component for orchestrating complex, containerized workflows in enterprise environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argo-workflow-executor`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Efficient workflow step execution in Kubernetes environments
- Integrated artifact management and storage
- Script execution and resource management
- Automated cleanup and resource handling

**Common Use Cases**
Typical scenarios where this runtime container excels

- CI/CD pipeline automation
- Data processing workflows
- Machine learning pipelines
- Batch processing operations

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argo-workflow-executor:latest
```

```bash
docker pull {registry.example.com}/argo-workflow-executor:v3.4
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name workflow-executor-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argo-workflow-executor:latest /bin/sh
```

**Run Hello World**
Execute a simple Hello World workflow

```bash
docker run --rm {registry.example.com}/argo-workflow-executor:latest argoexec --version
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/artifacts -w /artifacts {registry.example.com}/argo-workflow-executor:latest
```

**Application Server**
Run workflow executor with necessary configurations

```bash
docker run -d --name workflow-executor \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v $(pwd):/workflows \
  {registry.example.com}/argo-workflow-executor:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGO_TEMPLATE |  | Workflow template configuration |
| ARGO_POD_NAME |  | Pod name for the workflow step |
| ARGO_ARTIFACT_REPOSITORY |  | Artifact repository configuration |
| ARGO_WORKFLOW_NAME |  | Name of the workflow |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Implement proper RBAC policies
- Secure artifact storage configurations
- Regular security patches and updates
- Configure resource quotas and limits
- Enable audit logging
- Use secure communication channels
- Implement proper secret management

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 999
  runAsGroup: 999
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo Workflows Documentation**: https://argoproj.github.io/argo-workflows/
- **GitHub Repository**: https://github.com/argoproj/argo-workflows