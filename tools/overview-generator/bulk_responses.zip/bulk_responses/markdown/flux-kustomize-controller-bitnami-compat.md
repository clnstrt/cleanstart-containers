**Container Documentation for Flux-Kustomize-Controller-Bitnami-Compat**

A specialized container image that provides Flux Kustomize Controller functionality with Bitnami compatibility layer. This container enables GitOps-based continuous delivery with enhanced support for Bitnami-packaged applications, offering seamless integration between Flux CD's Kustomize controller and Bitnami's application catalog.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-kustomize-controller-bitnami-compat`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Bitnami compatibility layer for seamless integration
- Enhanced Kustomize controller with enterprise features
- GitOps-ready deployment configuration
- Automated reconciliation capabilities

**Common Use Cases**
Typical scenarios where this container excels

- GitOps-based application deployment
- Continuous delivery pipelines
- Kubernetes manifest management
- Bitnami application orchestration

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-kustomize-controller-bitnami-compat:latest
```

```bash
docker pull {registry.example.com}/flux-kustomize-controller-bitnami-compat:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-kustomize-controller-bitnami-compat-test {registry.example.com}/flux-kustomize-controller-bitnami-compat:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-kustomize-controller-bitnami-compat-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/flux-kustomize-controller-bitnami-compat:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/flux-kustomize-controller-bitnami-compat:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/flux-kustomize-controller-bitnami-compat:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| KUSTOMIZE_CONTROLLER_LOG_LEVEL | info | Logging level configuration |
| KUSTOMIZE_CONTROLLER_METRICS_ADDR | :8080 | Metrics endpoint address |
| KUSTOMIZE_CONTROLLER_WATCH_ALL_NAMESPACES | true | Enable watching all namespaces |
| RUNTIME_NAMESPACE | flux-system | Namespace for runtime operations |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production (avoid latest)
- Configure resource limits: memory and CPU constraints
- Enable read-only root filesystem when possible
- Run containers with non-root user (--user 1000:1000)
- Use --security-opt=no-new-privileges flag
- Regularly update container images for security patches
- Implement proper network segmentation
- Monitor container metrics for anomalies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-kustomize-controller-bitnami-compat