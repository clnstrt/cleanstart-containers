**Container Documentation for Flux-Kustomize-Controller-Bitnami-Compat-Fips**

A FIPS-compliant, security-hardened version of the Flux Kustomize Controller container, optimized for enterprise Kubernetes GitOps deployments. This container provides secure, automated configuration management and deployment capabilities while maintaining FIPS 140-2 compliance and Bitnami compatibility.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-kustomize-controller-bitnami-compat-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant runtime environment
- Automated Kubernetes configuration management
- GitOps-ready deployment capabilities
- Bitnami compatibility layer

**Common Use Cases**
Typical scenarios where this container excels

- Enterprise Kubernetes GitOps deployments
- Regulated environment configuration management
- Secure continuous delivery pipelines
- Compliance-focused infrastructure automation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-kustomize-controller-bitnami-compat-fips:latest
```

```bash
docker pull {registry.example.com}/flux-kustomize-controller-bitnami-compat-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-kustomize-controller {registry.example.com}/flux-kustomize-controller-bitnami-compat-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-kustomize-controller \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/kubernetes:/etc/kubernetes:ro \
  {registry.example.com}/flux-kustomize-controller-bitnami-compat-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/manifests:/workspace {registry.example.com}/flux-kustomize-controller-bitnami-compat-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:8080 {registry.example.com}/flux-kustomize-controller-bitnami-compat-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| KUBERNETES_SERVICE_HOST |  | Kubernetes API server host |
| KUBERNETES_SERVICE_PORT | 6443 | Kubernetes API server port |
| RUNTIME_NAMESPACE | flux-system | Namespace for controller operation |
| FIPS_MODE | true | Enable FIPS mode operation |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use RBAC policies to limit controller permissions
- Enable audit logging for all operations
- Implement network policies for pod communication
- Regular security scanning of deployed manifests
- Use sealed secrets for sensitive data

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-kustomize-controller-bitnami-compat-fips
- **Flux Documentation**: https://fluxcd.io/docs/
- **Kustomize Documentation**: https://kubectl.docs.kubernetes.io/guides/introduction/kustomize/