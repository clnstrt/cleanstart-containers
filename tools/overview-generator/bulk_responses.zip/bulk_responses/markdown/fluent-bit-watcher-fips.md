**Container Documentation for Fluent-Bit-Watcher-Fips**

A FIPS-compliant container image that monitors and manages Fluent Bit log processing configurations. Provides secure log forwarding capabilities with FIPS 140-2 validated cryptographic modules, designed for enterprise environments requiring strict security compliance.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/fluent-bit-watcher-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Real-time Fluent Bit configuration monitoring
- Automated configuration validation and reload
- Enterprise-grade security compliance

**Common Use Cases**
Typical scenarios where this container excels

- Government and military logging systems
- Financial services log management
- Healthcare data logging compliance
- Enterprise security monitoring

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/fluent-bit-watcher-fips:latest
```

```bash
docker pull {registry.example.com}/fluent-bit-watcher-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name fluent-bit-watcher-fips-test {registry.example.com}/fluent-bit-watcher-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name fluent-bit-watcher-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/fluent-bit-watcher-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/fluent-bit/config {registry.example.com}/fluent-bit-watcher-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 2020:2020 {registry.example.com}/fluent-bit-watcher-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLUENT_BIT_CONFIG_DIR | /etc/fluent-bit/config | Configuration directory path |
| WATCH_INTERVAL | 30 | Configuration check interval (seconds) |
| LOG_LEVEL | info | Logging level (debug, info, warn, error) |
| FIPS_MODE | enabled | FIPS mode enforcement |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Implement proper access controls for log files
- Use TLS 1.2+ for all network communications
- Regular security compliance audits
- Monitor container resource usage
- Implement proper backup procedures
- Use secure configuration management
- Regular security patch updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/fluent-bit-watcher-fips