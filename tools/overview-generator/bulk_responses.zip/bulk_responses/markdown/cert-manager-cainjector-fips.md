**Container Documentation for Cert-Manager-Cainjector-Fips**

The cert-manager-cainjector-fips container is a FIPS-compliant component of the cert-manager system that ensures TLS certificates are automatically injected into Kubernetes resources. It monitors and updates certificate configurations across namespaces, maintaining secure communications in enterprise environments that require FIPS 140-2 compliance.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cert-manager-cainjector-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant certificate injection
- Automated certificate configuration management
- Kubernetes-native integration
- Cross-namespace certificate synchronization

**Common Use Cases**
Typical scenarios where this container excels

- Enterprise Kubernetes certificate management
- FIPS-compliant environments
- Automated TLS certificate deployment
- Multi-cluster certificate synchronization

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cert-manager-cainjector-fips:latest
```

```bash
docker pull {registry.example.com}/cert-manager-cainjector-fips:1.12.0-fips
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cert-manager-cainjector {registry.example.com}/cert-manager-cainjector-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cert-manager-cainjector-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/kubernetes:/etc/kubernetes:ro \
  {registry.example.com}/cert-manager-cainjector-fips:latest
```

**Volume Mount**
Mount Kubernetes configuration for certificate management

```bash
docker run -v /etc/kubernetes:/etc/kubernetes:ro {registry.example.com}/cert-manager-cainjector-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9402:9402 {registry.example.com}/cert-manager-cainjector-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| NAMESPACE | cert-manager | Namespace for certificate management |
| LOG_LEVEL | 2 | Logging verbosity level |
| LEADER_ELECT | true | Enable leader election |
| KUBECONFIG | /etc/kubernetes/kubeconfig | Path to Kubernetes configuration |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies to restrict certificate access
- Enable audit logging for certificate operations
- Implement network policies for pod communication
- Regular security scanning of container images
- Monitor certificate lifecycle and expiration
- Use separate service accounts per namespace
- Implement pod security policies
- Regular backup of certificate configurations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cert-manager-cainjector-fips
- **Cert-Manager Documentation**: https://cert-manager.io/docs/