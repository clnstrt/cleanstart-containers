**Container Documentation for Etcd-Bitnami-Fips**

FIPS-validated etcd container image based on Bitnami's implementation, designed for secure distributed key-value store in enterprise environments. Features high availability, strong consistency, and secure communication with FIPS 140-2 compliance for regulated industries.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/etcd-bitnami-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Distributed key-value store with strong consistency
- High availability and fault tolerance
- Secure TLS communication between nodes

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster data store
- Service discovery and configuration management
- Distributed locking and leader election
- Secure configuration storage for regulated environments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/etcd-bitnami-fips:latest
```

```bash
docker pull {registry.example.com}/etcd-bitnami-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name etcd-server \
  -p 2379:2379 \
  -p 2380:2380 \
  {registry.example.com}/etcd-bitnami-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name etcd-prod \
  --read-only \
  --security-opt=no-new-privileges \
  -p 2379:2379 -p 2380:2380 \
  -v etcd-data:/bitnami/etcd \
  -e ETCD_ENABLE_V2=false \
  -e ALLOW_NONE_AUTHENTICATION=no \
  -e ETCD_ROOT_PASSWORD=your-secure-password \
  {registry.example.com}/etcd-bitnami-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d --name etcd-server \
  -v $(pwd)/etcd-data:/bitnami/etcd \
  {registry.example.com}/etcd-bitnami-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d --name etcd-server \
  -p 12379:2379 \
  -p 12380:2380 \
  {registry.example.com}/etcd-bitnami-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ALLOW_NONE_AUTHENTICATION | no | Allow unauthenticated access |
| ETCD_ROOT_PASSWORD |  | Root password for etcd authentication |
| ETCD_CLUSTER_DOMAIN | cluster.local | Kubernetes cluster domain |
| ETCD_ENABLE_V2 | false | Enable v2 API support |

**Security Best Practices**
Recommended security configurations and practices

- Always set ALLOW_NONE_AUTHENTICATION=no in production
- Use strong passwords for ETCD_ROOT_PASSWORD
- Enable TLS communication between nodes
- Implement proper backup strategies
- Regular security patches and updates
- Monitor etcd cluster health
- Use role-based access control
- Implement network segmentation

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1001
  fsGroup: 1001
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/etcd-bitnami-fips
- **Etcd Documentation**: https://etcd.io/docs