**Container Documentation for Dex**

Dex is an identity service that uses OpenID Connect to drive authentication for other apps. It acts as a portal to other identity providers through connectors. It can connect to multiple upstream identity providers and broker authentication to client apps. Dex is designed for enterprise use with features like LDAP integration, multi-factor authentication, and OIDC federation.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/dex`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- OpenID Connect provider with pluggable connectors
- Multiple upstream identity provider support
- LDAP and Active Directory integration
- Multi-factor authentication support

**Common Use Cases**
Typical scenarios where this container excels

- Enterprise SSO implementation
- Kubernetes authentication provider
- Identity federation services
- Multi-factor authentication gateway

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/dex:latest
```

```bash
docker pull registry.example.com/dex:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name dex-test -v $(pwd)/config.yaml:/etc/dex/config.yaml registry.example.com/dex:latest-dev serve /etc/dex/config.yaml
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name dex-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v $(pwd)/config.yaml:/etc/dex/config.yaml:ro \
  -p 5556:5556 \
  registry.example.com/dex:latest serve /etc/dex/config.yaml
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/dex -v $(pwd)/data:/var/lib/dex registry.example.com/dex:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 5556:5556 -p 5557:5557 registry.example.com/dex:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| DEX_FRONTEND_DIR | /srv/dex/web | Directory containing web assets |
| DEX_CONFIG | /etc/dex/config.yaml | Path to configuration file |
| DEX_LOGGING_FORMAT | json | Logging format (json or text) |
| DEX_LOGGING_LEVEL | info | Logging level |

**Security Best Practices**
Recommended security configurations and practices

- Use TLS for all connections
- Implement proper secret management
- Regular rotation of client secrets
- Enable audit logging
- Use secure storage for tokens
- Configure appropriate session timeouts
- Implement rate limiting
- Regular security updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/dex
- **Dex Documentation**: https://dexidp.io/docs/