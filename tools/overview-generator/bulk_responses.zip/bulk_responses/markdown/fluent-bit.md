**Container Documentation for Fluent-Bit**

Fluent Bit is a fast and lightweight log processor, forwarder, and aggregator for collecting data/logs from multiple sources, unifying and routing them to different destinations. It's designed with performance and resource efficiency in mind, making it ideal for cloud and containerized environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/fluent-bit`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- High-performance log processing and forwarding
- Minimal memory footprint and resource usage
- Built-in support for multiple input and output plugins
- Stream processing and real-time log analysis

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes logging infrastructure
- Cloud-native log aggregation
- Container and microservices monitoring
- Stream processing and data forwarding

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/fluent-bit:latest
```

```bash
docker pull {registry.example.com}/fluent-bit:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name fluent-bit {registry.example.com}/fluent-bit:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name fluent-bit \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /path/to/config:/fluent-bit/etc \
  {registry.example.com}/fluent-bit:latest
```

**Volume Mount**
Mount configuration and log directories

```bash
docker run -v $(pwd)/fluent-bit.conf:/fluent-bit/etc/fluent-bit.conf \
  -v $(pwd)/logs:/logs \
  {registry.example.com}/fluent-bit:latest
```

**Port Forwarding**
Run with metrics and HTTP server ports

```bash
docker run -p 2020:2020 -p 24224:24224 {registry.example.com}/fluent-bit:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLB_LOG_LEVEL | info | Logging level (debug, info, warn, error) |
| FLB_CONFIG_FILE | /fluent-bit/etc/fluent-bit.conf | Path to configuration file |
| FLB_HTTP_SERVER | Off | Enable/disable built-in HTTP server |
| FLB_HTTP_PORT | 2020 | HTTP server port |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper access controls for log files
- Enable TLS for all remote connections
- Regular security updates and patch management
- Configure resource limits and quotas
- Use read-only root filesystem
- Run as non-root user
- Implement network policies and segmentation

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_BIND_SERVICE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/fluent-bit
- **Official Fluent Bit Documentation**: https://docs.fluentbit.io/