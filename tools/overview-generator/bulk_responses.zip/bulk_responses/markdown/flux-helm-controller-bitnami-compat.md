**Container Documentation for Flux-Helm-Controller-Bitnami-Compat**

A specialized container image that provides Flux Helm Controller functionality with Bitnami compatibility layer, designed for GitOps-based Kubernetes deployments. This container enables automated Helm chart deployments, updates, and reconciliation while maintaining compatibility with Bitnami chart specifications and security requirements.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-helm-controller-bitnami-compat`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automated Helm chart deployment and reconciliation
- Bitnami chart compatibility layer
- GitOps-native workflow support
- Enhanced security features and hardening

**Common Use Cases**
Typical scenarios where this container excels

- Automated Helm chart deployments in Kubernetes
- GitOps-based application lifecycle management
- Continuous deployment pipelines
- Bitnami chart orchestration

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-helm-controller-bitnami-compat:latest
```

```bash
docker pull {registry.example.com}/flux-helm-controller-bitnami-compat:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-helm-controller-bitnami-compat-test {registry.example.com}/flux-helm-controller-bitnami-compat:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-helm-controller-bitnami-compat-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/flux-helm-controller-bitnami-compat:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/charts:/charts {registry.example.com}/flux-helm-controller-bitnami-compat:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9440:9440 {registry.example.com}/flux-helm-controller-bitnami-compat:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| HELM_CONTROLLER_CHARTS_PATH | /charts | Path to Helm charts directory |
| HELM_CONTROLLER_INTERVAL | 1m | Reconciliation interval |
| HELM_CONTROLLER_LOGS_LEVEL | info | Logging level configuration |
| HELM_CONTROLLER_TIMEOUT | 5m | Operation timeout duration |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper RBAC policies in Kubernetes
- Enable read-only root filesystem
- Configure resource quotas and limits
- Regular security scanning of Helm charts
- Monitor controller logs for security events
- Use secure repositories for Helm charts
- Implement network policies for controller access

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-helm-controller-bitnami-compat