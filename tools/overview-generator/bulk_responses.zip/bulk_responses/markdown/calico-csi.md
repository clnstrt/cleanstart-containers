**Container Documentation for Calico-Csi**

Calico CSI (Container Storage Interface) is a storage plugin that enables dynamic provisioning and management of network-attached storage in Kubernetes clusters. It provides seamless integration with Calico networking, supporting persistent volume management with enhanced security features and network policies.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-csi`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Dynamic volume provisioning for Kubernetes
- Integration with Calico networking policies
- Multi-cluster storage management
- Automated storage lifecycle management

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes persistent volume management
- Network-attached storage provisioning
- Multi-tenant storage orchestration
- Cloud-native storage solutions

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-csi:latest
```

```bash
docker pull {registry.example.com}/calico-csi:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-csi-test {registry.example.com}/calico-csi:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-csi-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/calico-csi:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/calico-csi:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/calico-csi:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CSI_ENDPOINT | unix:///var/lib/kubelet/plugins/csi.tigera.io/csi.sock | CSI endpoint socket path |
| KUBECONFIG | /etc/kubernetes/kubeconfig | Kubernetes configuration file path |
| NODE_NAME |  | Kubernetes node name |
| LOG_LEVEL | info | Logging verbosity level |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper RBAC policies
- Enable volume encryption when possible
- Regular security audits of storage access
- Monitor storage usage patterns
- Implement network policies for storage access
- Use secure communication channels
- Regular backup and recovery testing

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["SYS_ADMIN"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-csi
- **Calico CSI Documentation**: https://docs.projectcalico.org/reference/csi