**Container Documentation for Grype-Fips**

Grype-FIPS is a FIPS-validated vulnerability scanner container designed for enterprise security compliance. It provides comprehensive vulnerability analysis for container images and applications while maintaining FIPS 140-2 cryptographic standards. Ideal for organizations requiring strict security compliance and automated vulnerability management.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/grype-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Comprehensive vulnerability scanning capabilities
- Enterprise-grade security compliance
- Automated vulnerability reporting and analysis

**Common Use Cases**
Typical scenarios where this container excels

- Container image vulnerability scanning
- CI/CD pipeline security integration
- Compliance validation workflows
- Security audit automation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/grype-fips:latest
```

```bash
docker pull {registry.example.com}/grype-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name grype-scan {registry.example.com}/grype-fips:latest scan nginx:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name grype-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /var/run/docker.sock:/var/run/docker.sock \
  {registry.example.com}/grype-fips:latest
```

**Volume Mount**
Mount local directory for scan results

```bash
docker run -v $(pwd)/results:/results {registry.example.com}/grype-fips:latest scan --output /results/scan.json nginx:latest
```

**Port Forwarding**
Run with API endpoint exposure

```bash
docker run -p 9279:9279 {registry.example.com}/grype-fips:latest server
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| GRYPE_CHECK_FOR_APP_UPDATE | false | Disable automatic update checks |
| GRYPE_DB_AUTO_UPDATE | true | Enable vulnerability database auto-updates |
| GRYPE_OUTPUT_FORMAT | table | Set output format (table, json, cyclonedx) |
| GRYPE_FAIL_ON_SEVERITY | critical | Set failure threshold severity |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper access controls for scan results
- Regular vulnerability database updates
- Secure storage of scan results
- Integration with security information and event management (SIEM)
- Regular audit of scanning policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_BIND_SERVICE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/grype-fips
- **Security Compliance Guide**: https://{registry.example.com}/docs/security-compliance