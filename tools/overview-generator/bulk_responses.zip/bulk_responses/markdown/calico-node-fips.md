**Container Documentation for Calico-Node-Fips**

Calico Node FIPS is a FIPS 140-2 compliant version of the Calico Node container, providing secure networking for Kubernetes clusters. It includes network policy enforcement, pod networking, and security features that meet federal government security standards.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-node-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 compliant networking components
- Advanced network policy enforcement
- Kubernetes-native pod networking
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- Government and military Kubernetes deployments
- Financial services container environments
- Healthcare infrastructure requiring FIPS compliance
- Highly regulated enterprise environments

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/calico-node-fips:latest
```

```bash
docker pull {registry.example.com}/calico-node-fips:v3.25.0-fips
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name calico-node-fips \
  --privileged \
  --net=host \
  -v /lib/modules:/lib/modules \
  -v /var/run/calico:/var/run/calico \
  {registry.example.com}/calico-node-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CALICO_NETWORKING_BACKEND | bird | Networking backend (bird, vxlan, none) |
| FELIX_LOGSEVERITYSCREEN | INFO | Log severity level |
| IP_AUTODETECTION_METHOD | first-found | Method to detect node IP |
| FELIX_IPINIPENABLED | true | Enable IPIP tunneling |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Configure network policies for pod isolation
- Enable encryption for pod-to-pod communication
- Regular security updates and vulnerability scanning
- Implement proper RBAC policies
- Monitor network traffic patterns
- Configure resource limits
- Use secure endpoints for management access

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["NET_ADMIN", "NET_RAW"]
  allowPrivilegeEscalation: true
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Calico Documentation**: https://docs.projectcalico.org/
- **FIPS Compliance Guide**: https://docs.projectcalico.org/security/fips