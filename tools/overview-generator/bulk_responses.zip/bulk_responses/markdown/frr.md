**Container Documentation for Frr**

FRR (Free Range Routing) is an enterprise-grade IP routing protocol suite designed for Linux and Unix platforms. This container provides a complete routing solution supporting BGP, OSPF, RIP, IS-IS, PIM, and LDP protocols. Ideal for network infrastructure, data centers, and cloud environments requiring advanced routing capabilities.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/frr`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Complete IP routing protocol suite (BGP, OSPF, RIP, IS-IS)
- High-performance routing engine optimized for containerized environments
- Advanced policy-based routing capabilities
- IPv4 and IPv6 support with multicast routing

**Common Use Cases**
Typical scenarios where this container excels

- Data center network routing and infrastructure
- Cloud networking and interconnection
- Internet service provider routing solutions
- Enterprise network routing and management

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/frr:latest
```

```bash
docker pull {registry.example.com}/frr:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name frr-router --privileged --net=host {registry.example.com}/frr:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name frr-prod \
  --privileged \
  --net=host \
  -v frr-config:/etc/frr \
  -v frr-logs:/var/log/frr \
  {registry.example.com}/frr:latest
```

**Volume Mount**
Mount local directory for persistent configuration

```bash
docker run -v $(pwd)/frr-config:/etc/frr {registry.example.com}/frr:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 179:179 -p 2601:2601 {registry.example.com}/frr:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FRR_CONFIG_FILE | /etc/frr/frr.conf | Path to FRR configuration file |
| FRR_USER | frr | FRR process user |
| FRR_GROUP | frr | FRR process group |
| FRR_LOG_LEVEL | informational | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Implement proper access control lists (ACLs)
- Use MD5 authentication for routing protocols
- Regular security updates and patch management
- Monitor routing protocol activities
- Implement route filtering and validation
- Use secure passwords for routing protocol authentication
- Configure proper logging and monitoring
- Implement network segmentation

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["NET_ADMIN", "SYS_ADMIN"]
  hostNetwork: true
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/frr
- **FRR Project Documentation**: https://frrouting.org/