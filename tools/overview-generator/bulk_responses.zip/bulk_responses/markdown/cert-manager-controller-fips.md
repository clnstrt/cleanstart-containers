**Container Documentation for Cert-Manager-Controller-Fips**

Cert-manager controller container with FIPS 140-2 compliance for automated certificate management in enterprise Kubernetes environments. Provides X.509 certificate management for cloud native services with support for multiple issuers including ACME, HashiCorp Vault, and self-signed certificates.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cert-manager-controller-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Automated X.509 certificate management
- Multiple issuer support (ACME, Vault, self-signed)
- Kubernetes-native certificate management

**Common Use Cases**
Typical scenarios where this container excels

- Enterprise Kubernetes certificate automation
- Regulated environments requiring FIPS compliance
- Automated TLS certificate management
- Cloud-native security infrastructure

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cert-manager-controller-fips:latest
```

```bash
docker pull {registry.example.com}/cert-manager-controller-fips:v1.12.0-fips
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cert-manager-controller {registry.example.com}/cert-manager-controller-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cert-manager-controller-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/kubernetes:/etc/kubernetes \
  -v /var/run/secrets:/var/run/secrets \
  {registry.example.com}/cert-manager-controller-fips:latest
```

**Volume Mount**
Mount required Kubernetes volumes

```bash
docker run -v /etc/kubernetes:/etc/kubernetes -v /var/run/secrets:/var/run/secrets {registry.example.com}/cert-manager-controller-fips:latest
```

**Port Forwarding**
Run with required port mappings

```bash
docker run -p 9402:9402 {registry.example.com}/cert-manager-controller-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| NAMESPACE | cert-manager | Kubernetes namespace for cert-manager |
| POD_NAME |  | Name of the cert-manager pod |
| LEADER_ELECTION_NAMESPACE | kube-system | Namespace for leader election |
| FIPS_MODE | true | Enable FIPS mode operation |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies to restrict certificate access
- Enable audit logging for certificate operations
- Implement network policies to control cert-manager traffic
- Regular rotation of CA certificates
- Monitor certificate expiration and renewal events
- Use secure storage for private keys
- Configure appropriate resource limits
- Regular security scanning of container images

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cert-manager-controller-fips
- **Cert-Manager Documentation**: https://cert-manager.io/docs/