**Container Documentation for Etcd**

Etcd is a distributed, reliable key-value store for the most critical data of a distributed system. It's commonly used as the backend for service discovery, configuration management, and distributed locking in cloud-native environments. This container provides a production-ready etcd instance with enhanced security features and enterprise-grade reliability.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/etcd`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- Distributed key-value store with strong consistency
- Built-in disaster recovery and backup capabilities
- Automatic leader election and cluster management
- Watch functionality for real-time updates

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster data store
- Service discovery backend
- Distributed configuration management
- Distributed locking and leader election

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/etcd:latest
```

```bash
docker pull registry.example.com/etcd:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name etcd-single \
  -p 2379:2379 \
  -p 2380:2380 \
  registry.example.com/etcd:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name etcd-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -p 2379:2379 \
  -p 2380:2380 \
  -v etcd-data:/var/lib/etcd \
  registry.example.com/etcd:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d --name etcd-persist \
  -v $(pwd)/etcd-data:/var/lib/etcd \
  registry.example.com/etcd:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d --name etcd-custom \
  -p 12379:2379 \
  -p 12380:2380 \
  registry.example.com/etcd:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ETCD_NAME | etcd0 | Unique name for etcd instance |
| ETCD_DATA_DIR | /var/lib/etcd | Data directory location |
| ETCD_LISTEN_CLIENT_URLS | http://0.0.0.0:2379 | List of URLs to listen on for client traffic |
| ETCD_LISTEN_PEER_URLS | http://0.0.0.0:2380 | List of URLs to listen on for peer traffic |

**Security Best Practices**
Recommended security configurations and practices

- Enable TLS for client and peer communication
- Implement role-based access control (RBAC)
- Regular backup of etcd data
- Monitor cluster health and performance
- Use authentication for client access
- Implement proper network segmentation
- Regular security updates and patches
- Configure resource limits and quotas

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/etcd
- **Official etcd Documentation**: https://etcd.io/docs