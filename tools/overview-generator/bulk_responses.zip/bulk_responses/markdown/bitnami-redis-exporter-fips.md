**Container Documentation for Bitnami-Redis-Exporter-Fips**

Redis Exporter container with FIPS 140-2 compliance for monitoring Redis instances in enterprise environments. Exports Redis metrics in Prometheus format, supporting high-security requirements and comprehensive monitoring capabilities.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/bitnami-redis-exporter-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities of the Redis Exporter container

- FIPS 140-2 compliant implementation
- Prometheus-format metrics export
- Comprehensive Redis metrics collection
- Enterprise-grade security features

**Common Use Cases**
Typical scenarios for Redis monitoring

- Enterprise Redis performance monitoring
- Compliance-required environments
- Cloud-native Redis deployments
- Production Redis cluster monitoring

**Pull Latest Image**
Download the Redis Exporter container image

```bash
docker pull {registry.example.com}/bitnami-redis-exporter-fips:latest
```

**Production Deployment**
Deploy Redis Exporter with security settings

```bash
docker run -d --name redis-exporter \
  -p 9121:9121 \
  -e REDIS_ADDR=redis://redis:6379 \
  --security-opt=no-new-privileges \
  {registry.example.com}/bitnami-redis-exporter-fips:latest
```

**Development Setup**
Quick setup for development and testing

```bash
docker run -d --name redis-exporter-dev \
  -p 9121:9121 \
  -e REDIS_ADDR=redis://localhost:6379 \
  {registry.example.com}/bitnami-redis-exporter-fips:latest
```

**Docker Compose Setup**
Complete Redis Exporter service configuration

```yaml
version: '3.8'
services:
  redis-exporter:
    image: {registry.example.com}/bitnami-redis-exporter-fips:latest
    container_name: redis-exporter
    restart: unless-stopped
    ports:
      - "9121:9121"
    environment:
      - REDIS_ADDR=redis://redis:6379
    security_opt:
      - no-new-privileges:true
```

**Environment Variables**
Configuration options through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| REDIS_ADDR | redis://localhost:6379 | Redis instance address to monitor |
| REDIS_PASSWORD |  | Password for Redis authentication |
| REDIS_EXPORTER_WEB_LISTEN_ADDRESS | :9121 | Address to listen on for web interface and telemetry |
| REDIS_EXPORTER_WEB_TELEMETRY_PATH | /metrics | Path under which to expose metrics |

**Security Best Practices**
Recommended security configurations

- Use TLS encryption for Redis connections
- Implement proper authentication
- Configure network segmentation
- Regular security updates
- Monitor access logs
- Use read-only filesystem

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1001
  runAsGroup: 1001
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources

- **Container Registry**: https://{registry.example.com}
- **Redis Exporter GitHub**: https://github.com/oliver006/redis_exporter

**Access Metrics Endpoint**
View Prometheus metrics

```bash
curl http://localhost:9121/metrics
```