**Container Documentation for Cleanstart-Base-Fips**

A FIPS-validated, security-hardened base container image designed for enterprise environments requiring strict compliance and enhanced security measures. Features comprehensive STIG hardening, minimal attack surface, and validated cryptographic modules for regulated industries.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cleanstart-base-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- Minimal base image with reduced attack surface
- Enterprise-grade security controls

**Common Use Cases**
Typical scenarios where this container excels

- Government and military applications
- Financial services and banking systems
- Healthcare information systems
- Regulated industry deployments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cleanstart-base-fips:latest
```

```bash
docker pull {registry.example.com}/cleanstart-base-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cleanstart-base-fips-test {registry.example.com}/cleanstart-base-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cleanstart-base-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cleanstart-base-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/cleanstart-base-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/cleanstart-base-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FIPS_MODE | enabled | FIPS mode configuration |
| STIG_PROFILE | high | STIG compliance level |
| AUDIT_LEVEL | basic | Audit logging level |
| CRYPTO_POLICY | FIPS:OSPP | System-wide crypto policy |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled using fips-mode-setup --check
- Implement mandatory access controls
- Configure audit logging for compliance
- Use security-enhanced Linux (SELinux) policies
- Regular security compliance scanning
- Monitor cryptographic operations
- Implement secure key management
- Regular security patch updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seLinuxOptions:
    type: container_t
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cleanstart-base-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance
- **Security Hardening Guide**: https://{registry.example.com}/docs/security-hardening