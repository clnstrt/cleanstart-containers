**Container Documentation for Fluent-Operator**

Fluent Operator is a Kubernetes operator for unified logging management. It provides automated deployment and management of Fluent Bit and Fluentd, enabling efficient log collection, processing, and forwarding in containerized environments. The operator simplifies log management at scale, supports multiple output destinations, and offers advanced configuration capabilities for enterprise logging requirements.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/fluent-operator`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automated deployment and management of Fluent Bit and Fluentd
- Unified logging pipeline management
- Multiple output destination support
- Advanced configuration capabilities

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster logging management
- Centralized log aggregation
- Multi-cluster logging infrastructure
- Cloud-native observability solutions

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/fluent-operator:latest
```

```bash
docker pull {registry.example.com}/fluent-operator:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name fluent-operator-test {registry.example.com}/fluent-operator:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name fluent-operator-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/fluent-operator:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/fluent-operator/config {registry.example.com}/fluent-operator:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 24224:24224 {registry.example.com}/fluent-operator:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| OPERATOR_NAMESPACE | default | Namespace where operator is deployed |
| LOG_LEVEL | info | Logging level configuration |
| WATCH_NAMESPACE |  | Namespace(s) to watch for custom resources |
| METRICS_PORT | 8080 | Port for metrics endpoint |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies to limit operator permissions
- Enable secure communication with TLS
- Implement proper network policies
- Regular security updates and patches
- Monitor operator logs for security events
- Use secure credentials management

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/fluent-operator