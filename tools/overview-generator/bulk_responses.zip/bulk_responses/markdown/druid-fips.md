**Container Documentation for Druid-Fips**

Apache Druid FIPS-compliant container image optimized for enterprise data analytics. Features FIPS 140-2 validated cryptographic modules, STIG-hardened configuration, and enhanced security controls for regulated environments. Designed for high-performance real-time analytics while maintaining compliance requirements.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/druid-fips`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-hardened base configuration
- Real-time analytics and data ingestion
- Sub-second query performance
- Scalable distributed architecture
- Enterprise security compliance

**Common Use Cases**
Typical scenarios where this container excels

- Real-time data analytics in regulated environments
- Compliance-focused business intelligence
- Security-enhanced data warehousing
- Government and military applications
- Healthcare analytics systems

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/druid-fips:latest
```

```bash
docker pull registry.example.com/druid-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name druid-fips-test registry.example.com/druid-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name druid-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -p 8888:8888 \
  -v druid-data:/opt/druid/data \
  registry.example.com/druid-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/druid-data:/opt/druid/data registry.example.com/druid-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8888:8888 -p 8082:8082 registry.example.com/druid-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| DRUID_XMS | 1g | Initial heap size |
| DRUID_XMX | 1g | Maximum heap size |
| DRUID_FIPS_ENABLED | true | Enable FIPS mode |
| DRUID_LOG_LEVEL | info | Logging level |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Implement TLS for all communications
- Configure authentication and authorization
- Regular security patch updates
- Audit logging configuration
- Network segmentation implementation

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/druid-fips
- **Security Compliance Guide**: https://registry.example.com/docs/security