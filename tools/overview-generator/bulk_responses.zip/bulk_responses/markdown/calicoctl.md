**Container Documentation for Calicoctl**

Calicoctl is a command-line interface for managing Calico network policies, IP address management, and network configurations in Kubernetes clusters. It provides essential tools for implementing network security, configuring BGP peering, and managing Calico resources across enterprise container environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calicoctl`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Network policy management and enforcement
- BGP peering and route configuration
- IP address management (IPAM)
- Kubernetes network security controls

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster network management
- Network policy implementation
- Container security enforcement
- Cross-cluster networking configuration

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calicoctl:latest
```

```bash
docker pull {registry.example.com}/calicoctl:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calicoctl-test {registry.example.com}/calicoctl:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calicoctl-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/calicoctl:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/calico {registry.example.com}/calicoctl:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9091:9091 {registry.example.com}/calicoctl:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| DATASTORE_TYPE | kubernetes | Backend datastore type |
| KUBECONFIG | /etc/calico/kubeconfig | Path to Kubernetes config file |
| CALICO_NETWORKING_BACKEND | bird | Networking backend type |
| CALICO_IPAM_TYPE | calico-ipam | IP address management type |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement strict network policies
- Enable read-only root filesystem
- Run as non-root user
- Regular security updates and patches
- Secure API access credentials
- Monitor network traffic patterns
- Implement proper RBAC controls

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calicoctl