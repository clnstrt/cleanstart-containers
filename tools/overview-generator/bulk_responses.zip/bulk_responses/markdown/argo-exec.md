**Container Documentation for Argo-Exec**

Argo-Exec is a container runtime environment designed for executing workflow tasks and automation processes in enterprise environments. It provides a secure, scalable platform for running containerized workloads with built-in support for CI/CD pipelines, task orchestration, and workflow automation.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argo-exec`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Secure container runtime environment for workflow execution
- Built-in task orchestration and automation capabilities
- Native CI/CD pipeline integration support
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- Automated CI/CD pipeline execution
- Containerized workflow automation
- Task orchestration in distributed systems
- Enterprise workflow management

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argo-exec:latest
```

```bash
docker pull {registry.example.com}/argo-exec:latest-dev
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-exec-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argo-exec:latest-dev /bin/sh
```

**Run Hello World**
Execute a simple Hello World program

```bash
docker run --rm {registry.example.com}/argo-exec:latest-dev -c 'echo "Hello, World!"'
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/argo-exec:latest-dev argo-exec --version
```

**Application Server**
Run application with port forwarding

```bash
docker run -d --name argo-exec-app \
  -p 8000:8000 \
  -v $(pwd):/app \
  -w /app \
  {registry.example.com}/argo-exec:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| PATH | /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin | System PATH configuration |
| LANG | C.UTF-8 | Language and locale settings |
| ARGO_EXEC_VERSION | latest | Runtime version |
| HOME | /home/argo-exec | User home directory |

**Security Best Practices**
Recommended security configurations and practices

- Use specific runtime versions in production
- Implement proper access controls and authentication
- Enable audit logging for all operations
- Regular security updates and vulnerability scanning
- Use read-only filesystems where possible
- Implement proper logging and monitoring
- Configure resource limits and constraints
- Use secure communication protocols

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo-Exec Official Documentation**: https://argo-exec.org/