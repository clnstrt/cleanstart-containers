**Container Documentation for Flux-Notification-Controller-Fips**

The Flux Notification Controller FIPS container provides secure, FIPS-validated notification handling for GitOps workflows in Flux CD. It manages alerts, notifications, and event processing for Flux deployments while maintaining compliance with Federal Information Processing Standards (FIPS 140-2). This controller enables enterprise organizations to implement secure GitOps practices with automated notifications and alerts in regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-notification-controller-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Secure event notification processing
- Integration with multiple notification providers
- Automated alert management for GitOps workflows

**Common Use Cases**
Typical scenarios where this container excels

- Regulated enterprise GitOps deployments
- Secure continuous delivery pipelines
- Compliance-focused deployment monitoring
- Automated security alert processing

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-notification-controller-fips:latest
```

```bash
docker pull {registry.example.com}/flux-notification-controller-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-notification-controller-fips-test {registry.example.com}/flux-notification-controller-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-notification-controller-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/flux-notification-controller-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/flux/config {registry.example.com}/flux-notification-controller-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9292:9292 {registry.example.com}/flux-notification-controller-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| NOTIFICATION_CONTROLLER_LOG_LEVEL | info | Log level setting (debug, info, warn, error) |
| NOTIFICATION_CONTROLLER_METRICS_ADDR | :9292 | Metrics server address |
| NOTIFICATION_CONTROLLER_WATCH_ALL_NAMESPACES | true | Watch all namespaces for resources |
| NOTIFICATION_CONTROLLER_CONCURRENT | 2 | Number of concurrent notification operations |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production environments
- Use secure communication channels for notifications
- Implement proper RBAC policies
- Regular security scanning of container images
- Monitor notification patterns for security events
- Maintain audit logs of notification activities
- Use encrypted secrets for provider credentials
- Regular rotation of access tokens and credentials

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-notification-controller-fips
- **Flux Documentation**: https://fluxcd.io/docs/