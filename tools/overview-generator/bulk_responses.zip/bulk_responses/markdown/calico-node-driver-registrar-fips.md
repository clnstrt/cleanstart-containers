**Container Documentation for Calico-Node-Driver-Registrar-Fips**

The Calico Node Driver Registrar FIPS container is a specialized component that registers Calico's CSI drivers with Kubernetes, enabling secure network policy enforcement and routing. This FIPS-compliant version is specifically hardened for environments requiring Federal Information Processing Standards compliance, making it suitable for government and highly regulated enterprise deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-node-driver-registrar-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 compliant implementation
- Automated CSI driver registration with Kubernetes
- Secure communication channel with Kubernetes control plane
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- Government and military Kubernetes deployments
- Financial services containerized environments
- Healthcare Kubernetes clusters
- Regulated enterprise environments

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/calico-node-driver-registrar-fips:latest
```

```bash
docker pull {registry.example.com}/calico-node-driver-registrar-fips:v3.26.0-fips
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name calico-node-driver-registrar-fips \
  --privileged \
  -v /var/lib/kubelet:/var/lib/kubelet \
  {registry.example.com}/calico-node-driver-registrar-fips:latest /bin/sh
```

**Run Hello World**
Execute a simple test registration

```bash
docker run --rm {registry.example.com}/calico-node-driver-registrar-fips:latest --version
```

**Mount Workspace**
Run container with required Kubernetes mounts

```bash
docker run --rm \
  -v /var/lib/kubelet:/var/lib/kubelet \
  -v /var/run/kubernetes:/var/run/kubernetes \
  {registry.example.com}/calico-node-driver-registrar-fips:latest
```

**Application Server**
Run as a Kubernetes DaemonSet

```bash
kubectl apply -f https://raw.githubusercontent.com/projectcalico/calico/master/manifests/node-driver-registrar-fips.yaml
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| DRIVER_REG_SOCK_PATH | /var/lib/kubelet/plugins/csi-node/csi.sock | Path to CSI driver socket |
| KUBE_NODE_NAME |  | Kubernetes node name |
| CSI_ENDPOINT | unix:///csi/csi.sock | CSI endpoint path |
| FIPS_MODE | true | Enable FIPS mode |

**Security Best Practices**
Recommended security configurations and practices

- Run with minimum required privileges
- Use FIPS-validated cryptographic modules
- Implement proper RBAC policies
- Regular security updates and patches
- Monitor container logs for security events
- Use secure communication channels
- Implement network policies
- Regular security audits

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["SYS_ADMIN"]
  seLinuxOptions:
    level: "s0:c123,c456"
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Calico Documentation**: https://docs.projectcalico.org/
- **FIPS Compliance Guide**: https://docs.projectcalico.org/security/fips