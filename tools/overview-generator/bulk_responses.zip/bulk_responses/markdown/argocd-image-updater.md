**Container Documentation for Argocd-Image-Updater**

ArgoCD Image Updater is a tool designed to automatically update image versions in Kubernetes applications managed by Argo CD. It monitors container registries for new versions of images used in your applications and automatically creates pull requests or updates manifests when new versions are found, enabling automated continuous deployment workflows.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argocd-image-updater`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Automated image version updates for Argo CD applications
- Support for multiple container registries
- Flexible version constraint specifications
- Kubernetes-native design and integration

**Common Use Cases**
Typical scenarios where this runtime container excels

- Automated continuous deployment pipelines
- GitOps workflow automation
- Kubernetes application version management
- Container image lifecycle automation

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argocd-image-updater:latest
```

```bash
docker pull {registry.example.com}/argocd-image-updater:v0.12.0
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argocd-image-updater-dev \
  -v $(pwd):/app \
  -w /app \
  {registry.example.com}/argocd-image-updater:latest /bin/sh
```

**Run Hello World**
Execute a simple version check

```bash
docker run --rm {registry.example.com}/argocd-image-updater:latest version
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/config -w /config {registry.example.com}/argocd-image-updater:latest --config /config/config.yaml
```

**Application Server**
Run image updater with ArgoCD server connection

```bash
docker run -d --name argocd-image-updater \
  -v /path/to/config:/app/config \
  -e ARGOCD_SERVER=argocd-server.example.com \
  -e ARGOCD_TOKEN=<your-token> \
  {registry.example.com}/argocd-image-updater:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGOCD_SERVER |  | ArgoCD server address |
| ARGOCD_TOKEN |  | ArgoCD API token |
| ARGOCD_INSECURE | false | Skip TLS verification for ArgoCD server |
| LOG_LEVEL | info | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Implement proper RBAC controls
- Secure API tokens and credentials
- Regular security updates and patches
- Use read-only filesystem mounts
- Configure appropriate resource limits
- Enable audit logging
- Use secure communication channels

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **ArgoCD Image Updater Documentation**: https://argocd-image-updater.readthedocs.io/
- **GitHub Repository**: https://github.com/argoproj-labs/argocd-image-updater