**Container Documentation for Consul-K8S**

HashiCorp Consul Kubernetes integration container providing service mesh, service discovery, and network security automation capabilities for Kubernetes clusters. Features automated service networking, zero-trust security, and multi-cluster service mesh functionality for enterprise environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/consul-k8s`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Native Kubernetes integration with service mesh capabilities
- Automated service discovery and load balancing
- Zero-trust network security automation
- Multi-cluster federation support

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes service mesh implementation
- Multi-cluster service discovery
- Zero-trust network security
- Microservices connectivity management

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/consul-k8s:latest
```

```bash
docker pull {registry.example.com}/consul-k8s:1.2.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name consul-k8s {registry.example.com}/consul-k8s:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name consul-k8s-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 100:100 \
  {registry.example.com}/consul-k8s:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/consul-data:/consul/data {registry.example.com}/consul-k8s:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8500:8500 -p 8600:8600/udp {registry.example.com}/consul-k8s:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CONSUL_HTTP_ADDR | http://localhost:8500 | Consul HTTP API address |
| CONSUL_DATACENTER | dc1 | Consul datacenter name |
| CONSUL_ALLOW_PRIVILEGED_PORTS | false | Enable privileged ports access |
| CONSUL_CLIENT_CERT |  | Client certificate file path |

**Security Best Practices**
Recommended security configurations and practices

- Enable TLS encryption for all communication
- Implement ACL tokens for access control
- Use dedicated service accounts
- Configure proper network policies
- Regular security updates and patches
- Enable audit logging

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 100
  runAsGroup: 100
  fsGroup: 100
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]

```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/consul-k8s
- **Consul K8s Documentation**: https://www.consul.io/docs/k8s