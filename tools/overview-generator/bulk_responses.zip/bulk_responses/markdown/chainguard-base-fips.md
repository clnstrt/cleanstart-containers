**Container Documentation for Chainguard-Base-Fips**

Chainguard-Base-FIPS is a minimal, FIPS-validated base container image designed for secure enterprise deployments. It provides a hardened foundation for containerized applications requiring FIPS 140-2 compliance, featuring minimal attack surface, built-in security controls, and enterprise-grade support.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/chainguard-base-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- Minimal base image with reduced attack surface
- Enterprise-grade security controls and hardening

**Common Use Cases**
Typical scenarios where this container excels

- Government and military applications requiring FIPS compliance
- Financial services and healthcare deployments
- Secure enterprise application hosting
- Regulated industry workloads

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/chainguard-base-fips:latest
```

```bash
docker pull {registry.example.com}/chainguard-base-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name chainguard-base-fips-test {registry.example.com}/chainguard-base-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name chainguard-base-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/chainguard-base-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/chainguard-base-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/chainguard-base-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| PATH | /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin | System PATH configuration |
| HOME | /home/user | User home directory |
| USER | user | Default username |
| SHELL | /bin/sh | Default shell |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production environments
- Implement strict access controls and authentication
- Enable audit logging for all container operations
- Regular security scanning and vulnerability assessment
- Maintain compliance with security standards
- Use secure communication protocols only
- Monitor for security events and anomalies
- Regular updates and patch management

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/chainguard-base-fips