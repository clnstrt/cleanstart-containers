**Container Documentation for Crane-Fips**

Crane-FIPS is a FIPS 140-2 validated container image designed for secure enterprise environments requiring stringent cryptographic standards compliance. It provides a hardened runtime environment with validated cryptographic modules, making it ideal for government, healthcare, and financial sector deployments where FIPS compliance is mandatory.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/crane-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- Minimal attack surface with hardened base image
- Enterprise-grade security controls

**Common Use Cases**
Typical scenarios where this container excels

- Government and military applications requiring FIPS compliance
- Healthcare systems processing sensitive patient data
- Financial services applications handling regulated data
- Enterprise security-critical workloads

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/crane-fips:latest
```

```bash
docker pull {registry.example.com}/crane-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name crane-fips-test {registry.example.com}/crane-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name crane-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/crane-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/crane-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/crane-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FIPS_MODE | enabled | FIPS mode configuration |
| SECURITY_LEVEL | high | Security level setting |
| AUDIT_LEVEL | verbose | Audit logging level |
| TLS_MIN_VERSION | 1.2 | Minimum TLS version |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled before deployment
- Implement strict network policies
- Enable audit logging for all operations
- Regular security compliance checks
- Monitor cryptographic operations
- Maintain up-to-date security patches

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/crane-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance