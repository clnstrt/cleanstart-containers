**Container Documentation for Amazon-Cloudwatch-Agent-Operator-Fips**

The Amazon CloudWatch Agent Operator FIPS container provides a FIPS-compliant implementation for managing and operating CloudWatch agents in Kubernetes environments. It automates the deployment, configuration, and lifecycle management of CloudWatch agents across clusters while maintaining FIPS 140-2 compliance for enhanced security in regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/amazon-cloudwatch-agent-operator-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant implementation
- Automated CloudWatch agent management
- Kubernetes-native operator patterns
- Secure metrics and logs collection

**Common Use Cases**
Typical scenarios where this container excels

- Government and regulated industry deployments
- Enterprise Kubernetes monitoring
- Compliance-focused observability
- Secure cloud-native operations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/amazon-cloudwatch-agent-operator-fips:latest
```

```bash
docker pull {registry.example.com}/amazon-cloudwatch-agent-operator-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cloudwatch-operator {registry.example.com}/amazon-cloudwatch-agent-operator-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cloudwatch-operator-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /var/run/kubernetes:/var/run/kubernetes \
  {registry.example.com}/amazon-cloudwatch-agent-operator-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/cloudwatch-agent/config {registry.example.com}/amazon-cloudwatch-agent-operator-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:8080 {registry.example.com}/amazon-cloudwatch-agent-operator-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_REGION | us-east-1 | AWS region for CloudWatch |
| OPERATOR_NAME | cloudwatch-agent-operator | Name of the operator deployment |
| LOG_LEVEL | info | Logging level configuration |
| METRICS_PORT | 8080 | Metrics endpoint port |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled and properly configured
- Use IAM roles for authentication
- Implement proper RBAC policies
- Regular security patch updates
- Monitor operator logs for security events
- Use secure communication channels
- Implement network policies
- Regular security audits

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/amazon-cloudwatch-agent-operator-fips
- **AWS CloudWatch Documentation**: https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/