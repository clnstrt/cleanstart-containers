**Container Documentation for Calico-Cni-Fips**

Calico CNI FIPS is a FIPS 140-2 validated container networking interface plugin for Kubernetes that provides secure, scalable networking capabilities. It enables policy-driven network security, supports network policies, and ensures FIPS-compliant cryptographic operations for enterprise environments requiring high security standards.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-cni-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Kubernetes network policy enforcement
- Advanced security controls and isolation
- Enterprise-grade container networking

**Common Use Cases**
Typical scenarios where this container excels

- Government and military deployments requiring FIPS compliance
- Regulated industry Kubernetes clusters
- High-security enterprise environments
- Zero-trust network implementations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-cni-fips:latest
```

```bash
docker pull {registry.example.com}/calico-cni-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --privileged --net=host --name calico-cni-fips {registry.example.com}/calico-cni-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-cni-fips \
  --privileged \
  --net=host \
  -v /opt/cni/bin:/opt/cni/bin \
  -v /etc/cni:/etc/cni \
  {registry.example.com}/calico-cni-fips:latest
```

**Volume Mount**
Mount required directories for CNI operation

```bash
docker run -v /opt/cni:/opt/cni -v /etc/cni:/etc/cni {registry.example.com}/calico-cni-fips:latest
```

**Port Forwarding**
Network configuration for CNI operation

```bash
docker run --net=host {registry.example.com}/calico-cni-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CALICO_NETWORKING_BACKEND | bird | Networking backend (bird, vxlan, none) |
| FELIX_LOGSEVERITYSCREEN | info | Log severity level |
| FELIX_IPINIPMTU | 1440 | MTU for the IPIP tunnel device |
| FELIX_VXLANMTU | 1410 | MTU for the VXLAN tunnel device |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled and operational
- Implement strict network policies
- Regular security patch updates
- Monitor CNI logs for security events
- Use encrypted communication channels
- Implement pod security policies
- Regular compliance audits
- Secure key management practices

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["NET_ADMIN", "NET_RAW"]
  allowPrivilegeEscalation: true
  hostNetwork: true
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-cni-fips