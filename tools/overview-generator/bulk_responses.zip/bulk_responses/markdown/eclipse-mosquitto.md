**Container Documentation for Eclipse-Mosquitto**

Eclipse Mosquitto is a lightweight open source message broker that implements the MQTT protocol, making it ideal for Internet of Things messaging, low power sensors, mobile devices, embedded computers, and machine-to-machine communication. This container provides a production-ready, security-hardened implementation suitable for enterprise deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/eclipse-mosquitto`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Full MQTT v5.0, v3.1.1, and v3.1 protocol support
- TLS encryption and authentication capabilities
- Lightweight and efficient message broker implementation
- Persistent session and message queue support

**Common Use Cases**
Typical scenarios where this container excels

- IoT device message routing and communication
- Real-time sensor data collection and distribution
- Mobile application messaging infrastructure
- Distributed system message broker deployment

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/eclipse-mosquitto:latest
```

```bash
docker pull {registry.example.com}/eclipse-mosquitto:2.0.15
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it -p 1883:1883 -p 9001:9001 --name mosquitto {registry.example.com}/eclipse-mosquitto:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name mosquitto-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1883:1883 \
  -p 1883:1883 -p 9001:9001 \
  -v mosquitto-config:/mosquitto/config \
  -v mosquitto-data:/mosquitto/data \
  -v mosquitto-log:/mosquitto/log \
  {registry.example.com}/eclipse-mosquitto:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/mosquitto/config:/mosquitto/config \
  -v $(pwd)/mosquitto/data:/mosquitto/data \
  -v $(pwd)/mosquitto/log:/mosquitto/log \
  {registry.example.com}/eclipse-mosquitto:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 1883:1883 -p 9001:9001 {registry.example.com}/eclipse-mosquitto:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| MOSQUITTO_USERNAME |  | Default MQTT broker username |
| MOSQUITTO_PASSWORD |  | Default MQTT broker password |
| MOSQUITTO_CERTIFICATES_DIR | /mosquitto/certs | TLS certificates directory |
| MOSQUITTO_LOG_DEST | stdout | Logging destination |

**Security Best Practices**
Recommended security configurations and practices

- Enable TLS encryption for all connections
- Configure authentication for all clients
- Implement proper ACL rules
- Regular security updates and patches
- Monitor broker metrics and logs
- Use secure passwords and certificate management
- Implement network segmentation
- Regular backup of configuration and data

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1883
  runAsGroup: 1883
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  fsGroup: 1883
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/eclipse-mosquitto
- **Official Mosquitto Documentation**: https://mosquitto.org/documentation/