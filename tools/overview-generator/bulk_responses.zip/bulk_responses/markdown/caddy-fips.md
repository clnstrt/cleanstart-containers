**Container Documentation for Caddy-Fips**

FIPS-compliant web server container based on Caddy, providing secure and efficient HTTP/HTTPS services with automatic TLS certificate management. Designed for enterprise environments requiring FIPS 140-2 compliance and enhanced security features.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/caddy-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic modules
- Automatic HTTPS with managed SSL/TLS certificates
- Security-hardened configuration by default
- HTTP/2 and HTTP/3 support with modern performance features

**Common Use Cases**
Typical scenarios where this container excels

- Government and military web applications requiring FIPS compliance
- Enterprise web service deployments with strict security requirements
- Secure reverse proxy and load balancing
- Static file serving with enhanced security controls

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/caddy-fips:latest
```

```bash
docker pull {registry.example.com}/caddy-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name caddy-fips \
  -p 80:80 -p 443:443 \
  -v caddy_data:/data \
  -v caddy_config:/config \
  {registry.example.com}/caddy-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name caddy-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -p 80:80 -p 443:443 \
  -v caddy_data:/data \
  -v caddy_config:/config \
  -v $(pwd)/Caddyfile:/etc/caddy/Caddyfile:ro \
  {registry.example.com}/caddy-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d \
  -v $(pwd)/site:/srv \
  -v caddy_data:/data \
  -v caddy_config:/config \
  {registry.example.com}/caddy-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d \
  -p 8080:80 \
  -p 8443:443 \
  {registry.example.com}/caddy-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CADDY_FIPS_MODE | true | Enable/disable FIPS mode |
| XDG_DATA_HOME | /data | Data directory location |
| XDG_CONFIG_HOME | /config | Configuration directory location |
| CADDY_LOG_LEVEL | INFO | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use custom Caddyfile with secure defaults
- Implement strict TLS configuration
- Enable security headers and CSP
- Regular security audits and updates
- Monitor TLS certificate expiration
- Implement proper access controls
- Use secure DNS resolution

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_BIND_SERVICE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/caddy-fips
- **FIPS Compliance Documentation**: https://{registry.example.com}/docs/fips