**Container Documentation for Go1.23-Fips**

Enterprise-grade Go 1.23 runtime environment with FIPS 140-2 validated cryptographic modules, designed for secure development and deployment of Go applications in regulated environments. Features comprehensive security controls, STIG hardening, and validated cryptographic operations for government and enterprise compliance requirements.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/go1.23-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security hardening
- Enterprise-ready Go 1.23 runtime environment
- Optimized for cloud-native deployments

**Common Use Cases**
Typical scenarios where this runtime container excels

- Government and regulated industry applications
- Financial services and banking systems
- Healthcare application development
- Enterprise microservices deployment

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/go1.23-fips:latest
```

```bash
docker pull {registry.example.com}/go1.23-fips:latest-dev
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name go1.23-fips-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/go1.23-fips:latest-dev /bin/sh
```

**Run Hello World**
Execute a simple Hello World program

```bash
docker run --rm {registry.example.com}/go1.23-fips:latest-dev go run -c 'fmt.Println("Hello, World!")'
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/go1.23-fips:latest-dev go version
```

**Application Server**
Run application with port forwarding

```bash
docker run -d --name go1.23-fips-app \
  -p 8080:8080 \
  -v $(pwd):/app \
  -w /app \
  {registry.example.com}/go1.23-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| GOPATH | /go | Go workspace directory |
| GOROOT | /usr/local/go | Go installation directory |
| GO111MODULE | on | Go modules configuration |
| GOOS | linux | Target operating system |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled for cryptographic operations
- Use vendored dependencies for reproducible builds
- Implement secure coding guidelines
- Regular security patches and updates
- Enable Go module verification
- Configure appropriate resource limits
- Implement proper access controls
- Use security scanning tools

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Go Documentation**: https://golang.org/doc/
- **FIPS 140-2 Documentation**: https://csrc.nist.gov/publications/detail/fips/140/2/final