**Container Documentation for Argo-Rollouts-Fips**

Argo Rollouts FIPS is a progressive delivery controller for Kubernetes that supports advanced deployment patterns like canary, blue-green, and experimentation. This FIPS-validated version ensures compliance with Federal Information Processing Standards, making it suitable for government and regulated enterprise environments. It provides sophisticated deployment strategies with automated analysis and promotion, while maintaining the highest security standards.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argo-rollouts-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 validated cryptographic modules
- Progressive delivery controller for Kubernetes
- Blue-green and canary deployment strategies
- Automated analysis and promotion

**Common Use Cases**
Typical scenarios where this runtime container excels

- Government and regulated industry deployments
- Enterprise Kubernetes progressive delivery
- Zero-downtime application updates
- Automated canary analysis

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argo-rollouts-fips:latest
```

```bash
docker pull {registry.example.com}/argo-rollouts-fips:v1.5.0-fips
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-rollouts-fips-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argo-rollouts-fips:latest /bin/sh
```

**Run Hello World**
Execute a simple rollout

```bash
kubectl create -f https://raw.githubusercontent.com/argoproj/argo-rollouts/stable/docs/getting-started/basic/rollout.yaml
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/argo-rollouts-fips:latest kubectl argo rollouts version
```

**Application Server**
Deploy Argo Rollouts controller

```bash
kubectl create namespace argo-rollouts
kubectl apply -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/latest/download/install.yaml
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ROLLOUT_NAMESPACE | default | Kubernetes namespace for rollouts |
| ANALYSIS_INTERVAL | 30s | Interval between analysis runs |
| FIPS_MODE | enabled | FIPS mode configuration |
| LOG_LEVEL | info | Logging verbosity level |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC for access control
- Enable audit logging
- Implement network policies
- Regular security patches and updates
- Use secure communication channels
- Monitor for security events
- Configure resource quotas
- Implement pod security policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo Rollouts Documentation**: https://argoproj.github.io/argo-rollouts/
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance