**Container Documentation for Amazon-Cloudwatch-Agent**

The Amazon CloudWatch Agent container enables collection and transmission of system metrics, logs, and traces to Amazon CloudWatch. It provides comprehensive monitoring capabilities for containerized environments with support for custom metrics, automated log collection, and integration with AWS services.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/amazon-cloudwatch-agent`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Unified metrics and logs collection for AWS CloudWatch
- Support for custom metrics and dimensions
- Automated log collection and processing
- Integration with AWS services and monitoring

**Common Use Cases**
Typical scenarios where this container excels

- Container and host monitoring in AWS environments
- Application performance monitoring
- System resource utilization tracking
- Log aggregation and analysis

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/amazon-cloudwatch-agent:latest
```

```bash
docker pull {registry.example.com}/amazon-cloudwatch-agent:1.247.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name cloudwatch-agent \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v /config/agent-config.json:/etc/cwagentconfig/agent-config.json \
  {registry.example.com}/amazon-cloudwatch-agent:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cloudwatch-agent-prod \
  --read-only \
  --security-opt=no-new-privileges \
  -v /var/run/docker.sock:/var/run/docker.sock:ro \
  -v /config/agent-config.json:/etc/cwagentconfig/agent-config.json:ro \
  -e AWS_REGION=us-east-1 \
  {registry.example.com}/amazon-cloudwatch-agent:latest
```

**Volume Mount**
Mount configuration and log directories

```bash
docker run -d \
  -v /var/log:/var/log:ro \
  -v /config/agent-config.json:/etc/cwagentconfig/agent-config.json:ro \
  {registry.example.com}/amazon-cloudwatch-agent:latest
```

**Port Forwarding**
Run with StatsD endpoint exposed

```bash
docker run -d -p 8125:8125/udp {registry.example.com}/amazon-cloudwatch-agent:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_REGION | us-east-1 | AWS region for CloudWatch |
| CW_CONFIG_CONTENT |  | Agent configuration as JSON string |
| AWS_ACCESS_KEY_ID |  | AWS access key ID |
| AWS_SECRET_ACCESS_KEY |  | AWS secret access key |

**Security Best Practices**
Recommended security configurations and practices

- Use IAM roles instead of access keys when possible
- Mount configuration files as read-only
- Implement least privilege access principles
- Regular security patches and updates
- Enable encryption for sensitive data
- Monitor agent logs for security events

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["SYS_PTRACE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/amazon-cloudwatch-agent
- **AWS CloudWatch Documentation**: https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/