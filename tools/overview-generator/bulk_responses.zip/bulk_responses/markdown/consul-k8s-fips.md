**Container Documentation for Consul-K8S-Fips**

HashiCorp Consul Kubernetes FIPS-compliant container image for service mesh, service discovery, and network infrastructure automation in regulated enterprise environments. Features FIPS 140-2 validated cryptographic modules and security-hardened configuration for compliance-focused deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/consul-k8s-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Native Kubernetes integration with service mesh capabilities
- Zero-trust network security controls
- Service discovery and configuration management

**Common Use Cases**
Typical scenarios where this container excels

- Regulated enterprise Kubernetes deployments
- Government and defense microservices architectures
- Financial services compliance environments
- Healthcare data processing systems

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/consul-k8s-fips:latest
```

```bash
docker pull {registry.example.com}/consul-k8s-fips:1.2.0-fips
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name consul-k8s \
  -p 8500:8500 \
  -p 8600:8600/udp \
  {registry.example.com}/consul-k8s-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name consul-k8s-prod \
  --cap-drop ALL \
  --security-opt=no-new-privileges \
  -p 8500:8500 \
  -p 8600:8600/udp \
  -v consul-data:/consul/data \
  -v consul-config:/consul/config \
  {registry.example.com}/consul-k8s-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d \
  -v $(pwd)/consul-data:/consul/data \
  -v $(pwd)/consul-config:/consul/config \
  {registry.example.com}/consul-k8s-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d \
  -p 8500:8500 \
  -p 8600:8600/udp \
  -p 8300:8300 \
  -p 8301:8301 \
  {registry.example.com}/consul-k8s-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CONSUL_HTTP_ADDR | http://localhost:8500 | HTTP API address |
| CONSUL_DATACENTER | dc1 | Datacenter name |
| CONSUL_ENCRYPT |  | Encryption key |
| CONSUL_CLIENT_CERT |  | TLS client certificate path |

**Security Best Practices**
Recommended security configurations and practices

- Enable ACLs for access control
- Configure TLS encryption for all communication
- Use FIPS-compliant encryption settings
- Implement proper network segmentation
- Regular security audits and updates
- Monitor service mesh metrics
- Implement proper backup strategies
- Use secure gossip encryption

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 100
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/consul-k8s-fips
- **Consul Documentation**: https://www.consul.io/docs
- **FIPS Compliance Guide**: https://www.consul.io/docs/enterprise/fips