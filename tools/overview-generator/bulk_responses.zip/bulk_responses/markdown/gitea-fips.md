**Container Documentation for Gitea-Fips**

Enterprise-grade Gitea container with FIPS 140-2 compliance, providing a secure, self-hosted Git service with integrated CI/CD capabilities. Features enhanced security controls, STIG hardening, and comprehensive audit logging for regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/gitea-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- Built-in audit logging and monitoring
- Enterprise authentication integration

**Common Use Cases**
Typical scenarios where this container excels

- Secure source code management in regulated environments
- Enterprise DevSecOps implementations
- Government and military software development
- Financial services code repositories

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/gitea-fips:latest
```

```bash
docker pull {registry.example.com}/gitea-fips:1.20
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name gitea-fips \
  -p 3000:3000 \
  -v gitea-data:/data \
  {registry.example.com}/gitea-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name gitea-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v gitea-data:/data \
  -v gitea-config:/etc/gitea \
  -p 3000:3000 \
  -p 22:22 \
  {registry.example.com}/gitea-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d \
  -v $(pwd)/gitea-data:/data \
  -v $(pwd)/gitea-config:/etc/gitea \
  {registry.example.com}/gitea-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d \
  -p 8080:3000 \
  -p 2222:22 \
  {registry.example.com}/gitea-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| GITEA_CUSTOM | /data/gitea | Custom configuration directory |
| GITEA_WORK_DIR | /data | Working directory |
| GITEA_APP_NAME | Gitea | Application name |
| GITEA_RUN_MODE | prod | Run mode (prod/dev) |

**Security Best Practices**
Recommended security configurations and practices

- Enable FIPS mode in configuration
- Configure SSL/TLS for all connections
- Implement regular security audits
- Use external authentication (LDAP/SAML)
- Enable audit logging
- Regular backup of Git repositories
- Monitor system resources
- Apply security patches promptly

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/gitea-fips
- **Security Compliance**: https://{registry.example.com}/gitea-fips/security