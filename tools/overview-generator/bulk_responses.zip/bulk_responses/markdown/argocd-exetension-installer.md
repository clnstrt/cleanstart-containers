**Container Documentation for Argocd-Exetension-Installer**

The Argocd-Extension-Installer container provides a specialized environment for installing and managing Argo CD extensions in enterprise Kubernetes environments. It includes tools and utilities necessary for deploying, configuring, and maintaining Argo CD plugins and extensions, supporting GitOps workflows and continuous delivery practices.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argocd-exetension-installer`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Automated Argo CD extension installation and management
- Built-in dependency resolution system
- Integration with Kubernetes native tooling
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- Argo CD plugin deployment and management
- GitOps workflow automation
- Continuous delivery pipeline integration
- Kubernetes extension management

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argocd-exetension-installer:latest
```

```bash
docker pull {registry.example.com}/argocd-exetension-installer:latest-dev
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argocd-exetension-installer-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argocd-exetension-installer:latest-dev /bin/sh
```

**Run Hello World**
Execute a simple Hello World program

```bash
docker run --rm {registry.example.com}/argocd-exetension-installer:latest-dev --version
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/argocd-exetension-installer:latest-dev install --plugin-name example-plugin
```

**Application Server**
Run application with port forwarding

```bash
docker run -d --name argocd-exetension-installer-app \
  -p 8080:8080 \
  -v $(pwd):/app \
  -w /app \
  {registry.example.com}/argocd-exetension-installer:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| PLUGIN_PATH | /opt/argocd/plugins | Plugin installation directory |
| ARGOCD_SERVER | argocd-server.argocd.svc | Argo CD server address |
| INSTALLER_LOG_LEVEL | info | Logging verbosity level |
| KUBERNETES_NAMESPACE | argocd | Target Kubernetes namespace |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags in production
- Implement proper RBAC configurations
- Enable plugin verification and validation
- Regular security updates and vulnerability scanning
- Use read-only filesystems where possible
- Configure proper logging and monitoring
- Implement network policies
- Use secure plugin sources

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo CD Documentation**: https://argo-cd.readthedocs.io/