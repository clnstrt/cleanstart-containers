**Container Documentation for Glibc-Openssl-Fips**

Enterprise-grade container image featuring FIPS-validated OpenSSL implementation and glibc runtime, designed for secure, compliant deployments in regulated environments. Provides a hardened foundation for applications requiring FIPS 140-2 cryptographic modules and standardized C library support.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/glibc-openssl-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated OpenSSL cryptographic modules
- Optimized glibc runtime environment
- Security-hardened base configuration
- Multi-architecture support (amd64/arm64)

**Common Use Cases**
Typical scenarios where this container excels

- Government and military applications requiring FIPS compliance
- Financial services and healthcare systems
- Secure communication infrastructure
- Regulated industry deployments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/glibc-openssl-fips:latest
```

```bash
docker pull {registry.example.com}/glibc-openssl-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name glibc-openssl-fips-test {registry.example.com}/glibc-openssl-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name glibc-openssl-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/glibc-openssl-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/glibc-openssl-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/glibc-openssl-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| OPENSSL_FIPS | 1 | Enable FIPS mode (1=enabled, 0=disabled) |
| OPENSSL_CONF | /etc/ssl/openssl.cnf | OpenSSL configuration file path |
| LD_LIBRARY_PATH | /usr/lib | Library search path |
| LANG | C.UTF-8 | Default system locale |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled using openssl version -a
- Implement proper key management and rotation
- Regular security compliance audits
- Monitor cryptographic operations for compliance
- Maintain secure configuration backups
- Use access control lists for sensitive operations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/glibc-openssl-fips
- **FIPS 140-2 Documentation**: https://{registry.example.com}/docs/fips