**Container Documentation for Bash-Fips**

FIPS 140-2 validated Bash shell environment container providing secure command-line operations for regulated enterprise environments. Features hardened security configurations, validated cryptographic modules, and compliance with federal security standards.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/bash-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- Minimal attack surface with hardened base
- Enterprise-ready audit logging capabilities

**Common Use Cases**
Typical scenarios where this container excels

- Government and military deployments requiring FIPS compliance
- Financial services applications with strict security requirements
- Healthcare systems processing sensitive data
- Secure CI/CD pipeline operations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/bash-fips:latest
```

```bash
docker pull {registry.example.com}/bash-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name bash-fips-test {registry.example.com}/bash-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name bash-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/bash-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/bash-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/bash-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FIPS_MODE | enabled | FIPS mode enforcement (enabled/disabled) |
| AUDIT_LEVEL | high | Audit logging level (low/medium/high) |
| SHELL | /bin/bash | Default shell path |
| CRYPTO_POLICY | FIPS | System-wide crypto policy |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled before deployment
- Implement comprehensive audit logging
- Use SELinux or AppArmor profiles
- Regular security compliance scanning
- Monitor cryptographic operations
- Maintain strict access controls
- Regular security patch updates
- Implement network security policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/bash-fips
- **FIPS 140-2 Certification**: https://{registry.example.com}/certifications/fips