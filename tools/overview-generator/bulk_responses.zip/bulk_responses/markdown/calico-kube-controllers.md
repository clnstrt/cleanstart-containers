**Container Documentation for Calico-Kube-Controllers**

Calico Kubernetes Controllers provide essential control plane functions for Calico networking and network policy in Kubernetes clusters. These controllers manage IP address allocation, node status monitoring, policy enforcement, and network connectivity across cluster nodes.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-kube-controllers`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- IP address management and allocation
- Node status monitoring and health checks
- Network policy enforcement
- Cross-node networking coordination

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster networking management
- Network policy implementation
- Multi-tenant network isolation
- Container network interface (CNI) orchestration

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-kube-controllers:latest
```

```bash
docker pull {registry.example.com}/calico-kube-controllers:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-kube-controllers-test {registry.example.com}/calico-kube-controllers:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-kube-controllers-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/calico-kube-controllers:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/calico-kube-controllers:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9094:9094 {registry.example.com}/calico-kube-controllers:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ENABLED_CONTROLLERS | node,policy,namespace,serviceaccount,workloadendpoint | Comma-separated list of controllers to enable |
| KUBECONFIG | /etc/calico/kubeconfig | Path to Kubernetes configuration file |
| LOG_LEVEL | info | Logging level (debug, info, warning, error) |
| DATASTORE_TYPE | kubernetes | Type of datastore to use |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies to limit controller access
- Enable network policies for controller pod
- Configure resource limits and requests
- Use secure communication channels
- Regularly update to latest security patches
- Implement proper pod security policies
- Monitor controller logs for security events
- Use secure secrets management

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-kube-controllers