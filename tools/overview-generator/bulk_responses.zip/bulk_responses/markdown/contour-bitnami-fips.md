**Container Documentation for Contour-Bitnami-Fips**

Enterprise-grade Contour ingress controller container image with FIPS 140-2 compliance and Bitnami hardening. Provides secure, high-performance ingress control for Kubernetes clusters with advanced traffic routing, load balancing, and TLS termination capabilities.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/contour-bitnami-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Bitnami security hardening and optimization
- Advanced ingress control and traffic routing
- Enterprise-grade TLS termination

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes ingress control in regulated environments
- High-security enterprise traffic management
- FIPS-compliant load balancing solutions
- Government and military deployment scenarios

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/contour-bitnami-fips:latest
```

```bash
docker pull {registry.example.com}/contour-bitnami-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name contour-bitnami-fips-test {registry.example.com}/contour-bitnami-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name contour-bitnami-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/contour-bitnami-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/contour {registry.example.com}/contour-bitnami-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8001:8001 -p 8000:8000 {registry.example.com}/contour-bitnami-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CONTOUR_NAMESPACE | projectcontour | Kubernetes namespace for Contour |
| CONTOUR_CERT_DIR | /certs | Directory containing TLS certificates |
| CONTOUR_CONFIG_PATH | /config/contour.yaml | Path to Contour configuration file |
| CONTOUR_FIPS_MODE | true | Enable FIPS mode operation |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use TLS 1.2 or higher for all connections
- Implement strict network policies
- Regular security scanning and updates
- Monitor ingress traffic patterns
- Configure proper access controls
- Enable audit logging
- Use secure communication channels

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1001
  runAsGroup: 1001
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_BIND_SERVICE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/contour-bitnami-fips