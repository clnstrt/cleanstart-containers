**Container Documentation for Gitlab-Runner-Fips**

GitLab Runner FIPS container image provides a FIPS 140-2 compliant continuous integration executor that integrates with GitLab CI/CD pipelines. This hardened container includes validated cryptographic modules and security controls suitable for regulated enterprise environments requiring FIPS compliance.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/gitlab-runner-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic modules
- Integrated GitLab CI/CD pipeline execution
- Multi-architecture support (amd64/arm64)
- Security-hardened configuration baseline

**Common Use Cases**
Typical scenarios where this container excels

- Regulated enterprise CI/CD pipelines
- Government and defense software development
- Financial services compliance environments
- Healthcare software deployment pipelines

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/gitlab-runner-fips:latest
```

```bash
docker pull {registry.example.com}/gitlab-runner-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name gitlab-runner-fips \
  -v /etc/gitlab-runner:/etc/gitlab-runner \
  -v /var/run/docker.sock:/var/run/docker.sock \
  {registry.example.com}/gitlab-runner-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name gitlab-runner-fips-prod \
  --restart always \
  --read-only \
  --security-opt=no-new-privileges \
  -v /etc/gitlab-runner:/etc/gitlab-runner \
  -v /var/run/docker.sock:/var/run/docker.sock \
  {registry.example.com}/gitlab-runner-fips:latest register \
  --non-interactive \
  --url "https://gitlab.example.com/" \
  --registration-token "REGISTRATION_TOKEN" \
  --executor "docker" \
  --docker-image alpine:latest \
  --description "docker-runner-fips" \
  --tag-list "docker,fips" \
  --run-untagged="true" \
  --locked="false"
```

**Volume Mount**
Mount configuration and Docker socket

```bash
docker run -v /etc/gitlab-runner:/etc/gitlab-runner -v /var/run/docker.sock:/var/run/docker.sock {registry.example.com}/gitlab-runner-fips:latest
```

**Port Forwarding**
Run with metrics endpoint exposed

```bash
docker run -p 9252:9252 {registry.example.com}/gitlab-runner-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| REGISTER_NON_INTERACTIVE | true | Enable non-interactive registration |
| RUNNER_NAME | docker-runner-fips | Runner name |
| REGISTRATION_TOKEN |  | GitLab registration token |
| GITLAB_URL |  | GitLab instance URL |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Implement proper access controls for registration tokens
- Regular security updates and patch management
- Monitor runner logs for security events
- Configure resource limits for CI jobs
- Use secure runner executors
- Implement network segmentation
- Regular security scanning of built artifacts

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/gitlab-runner-fips
- **GitLab Runner Documentation**: https://docs.gitlab.com/runner/