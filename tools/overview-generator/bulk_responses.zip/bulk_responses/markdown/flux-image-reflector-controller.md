**Container Documentation for Flux-Image-Reflector-Controller**

The Flux Image Reflector Controller is a critical component of the Flux GitOps toolkit that automatically monitors container registries for new image versions. It enables automated image updates in Kubernetes clusters by scanning specified container registries, detecting new image tags, and updating the corresponding Kubernetes manifests. This controller is essential for maintaining up-to-date deployments and implementing continuous delivery workflows in enterprise environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-image-reflector-controller`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automated container registry monitoring and scanning
- Support for multiple registry providers and authentication methods
- Efficient image metadata caching and polling
- Seamless integration with Flux GitOps toolkit

**Common Use Cases**
Typical scenarios where this container excels

- Automated image updates in GitOps workflows
- Continuous deployment pipelines
- Container registry monitoring and automation
- Kubernetes-native image policy enforcement

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-image-reflector-controller:latest
```

```bash
docker pull {registry.example.com}/flux-image-reflector-controller:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-image-reflector-controller {registry.example.com}/flux-image-reflector-controller:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-image-reflector-controller \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /etc/kubernetes/config:/etc/kubernetes/config \
  {registry.example.com}/flux-image-reflector-controller:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/etc/kubernetes/config {registry.example.com}/flux-image-reflector-controller:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9090:9090 {registry.example.com}/flux-image-reflector-controller:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| RUNTIME_NAMESPACE | flux-system | Namespace where the controller runs |
| WATCH_INTERVAL | 1m | Registry scanning interval |
| LOG_LEVEL | info | Logging verbosity level |
| METRICS_ADDR | :9090 | Metrics server address |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper RBAC policies
- Secure registry credentials using Kubernetes secrets
- Enable audit logging for all operations
- Regular security scanning of base images
- Implement network policies for controller access
- Use read-only root filesystem
- Configure resource limits and requests

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-image-reflector-controller
- **Flux Documentation**: https://fluxcd.io/docs/