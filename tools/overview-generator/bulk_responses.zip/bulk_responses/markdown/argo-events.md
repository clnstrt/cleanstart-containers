**Container Documentation for Argo-Events**

Argo Events is an event-driven workflow automation framework for Kubernetes that helps you trigger workflows, serverless workloads, or any other actions based on various events from multiple sources. It enables complex event dependencies, event filtering, and multi-source event processing.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argo-events`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Event-driven workflow automation for Kubernetes
- Support for multiple event sources and triggers
- Complex event dependency management
- Scalable event processing architecture

**Common Use Cases**
Typical scenarios where this runtime container excels

- CI/CD pipeline automation
- Kubernetes-native event processing
- Serverless workflow triggers
- Multi-source event orchestration

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argo-events:latest
```

```bash
docker pull {registry.example.com}/argo-events:v1.7.0
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-events-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argo-events:latest /bin/sh
```

**Run Hello World**
Execute a simple event sensor

```bash
kubectl apply -f https://raw.githubusercontent.com/argoproj/argo-events/stable/examples/sensors/hello-world.yaml
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/argo-events:latest version
```

**Application Server**
Deploy event controller with port forwarding

```bash
kubectl port-forward deployment/argo-events-controller-manager 8080:8080 -n argo-events
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| NAMESPACE | argo-events | Kubernetes namespace for deployment |
| EVENT_BUS_NAME | default | Name of the event bus |
| CONTROLLER_CONFIG_MAP | controller-config | Controller configuration map name |
| LOG_LEVEL | info | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies for access control
- Implement network policies for event sources
- Regular security updates and patches
- Configure secure TLS endpoints
- Use secrets for sensitive information
- Enable audit logging
- Implement resource quotas
- Use pod security policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo Events Documentation**: https://argoproj.github.io/argo-events/
- **GitHub Repository**: https://github.com/argoproj/argo-events