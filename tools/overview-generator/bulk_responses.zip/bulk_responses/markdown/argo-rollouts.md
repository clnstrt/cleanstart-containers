**Container Documentation for Argo-Rollouts**

Argo Rollouts is a Kubernetes controller and set of CRDs which provide advanced deployment capabilities such as blue-green, canary, canary analysis, experimentation, and progressive delivery features to Kubernetes. It provides additional deployment strategies and fine-grained control over the progression of application updates.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argo-rollouts`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Blue-Green deployment strategy support
- Canary deployment with automated analysis
- Progressive delivery capabilities
- Integration with metrics providers

**Common Use Cases**
Typical scenarios where this runtime container excels

- Zero-downtime application deployments
- Automated canary analysis
- Progressive feature rollouts
- Advanced deployment orchestration

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argo-rollouts:latest
```

```bash
docker pull {registry.example.com}/argo-rollouts:v1.5.0
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-rollouts-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argo-rollouts:latest /bin/sh
```

**Run Hello World**
Execute a simple rollout

```bash
kubectl create namespace argo-rollouts
kubectl apply -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/latest/download/install.yaml
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/argo-rollouts:latest kubectl argo rollouts version
```

**Application Server**
Deploy Argo Rollouts controller

```bash
kubectl create namespace argo-rollouts
kubectl apply -n argo-rollouts -f https://raw.githubusercontent.com/argoproj/argo-rollouts/stable/manifests/install.yaml
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGO_ROLLOUT_NAMESPACE | argo-rollouts | Namespace for Argo Rollouts deployment |
| ROLLOUT_TIMEOUT | 600 | Timeout for rollout operations (seconds) |
| ANALYSIS_INTERVAL | 30 | Interval between analysis runs (seconds) |
| LOG_LEVEL | info | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC to limit controller permissions
- Implement network policies for rollout traffic
- Regular security updates and patches
- Configure secure metrics endpoints
- Use secure service mesh integration
- Enable audit logging
- Configure resource quotas
- Use pod security policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo Rollouts Documentation**: https://argoproj.github.io/argo-rollouts/
- **GitHub Repository**: https://github.com/argoproj/argo-rollouts