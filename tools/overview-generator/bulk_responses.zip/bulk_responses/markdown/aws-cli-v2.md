**Container Documentation for Aws-Cli-V2**

AWS CLI v2 container provides a unified command line interface for interacting with AWS services. This enterprise-ready container includes the latest AWS CLI version with support for all AWS services, multi-factor authentication, and advanced features like auto-prompt and serverless application management.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/aws-cli-v2`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- Latest AWS CLI v2 with all service capabilities
- Multi-factor authentication support
- Auto-prompt and intelligent command suggestions
- Serverless application management tools

**Common Use Cases**
Typical scenarios where this container excels

- AWS resource management and automation
- CI/CD pipeline integration
- Cloud infrastructure deployment
- AWS service configuration and monitoring

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/aws-cli-v2:latest
```

```bash
docker pull registry.example.com/aws-cli-v2:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name aws-cli-v2-test registry.example.com/aws-cli-v2:latest-dev aws --version
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name aws-cli-v2-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v ~/.aws:/home/aws/.aws \
  registry.example.com/aws-cli-v2:latest
```

**Volume Mount**
Mount AWS credentials and configuration

```bash
docker run -v ~/.aws:/home/aws/.aws registry.example.com/aws-cli-v2:latest aws s3 ls
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 registry.example.com/aws-cli-v2:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_ACCESS_KEY_ID |  | AWS access key credential |
| AWS_SECRET_ACCESS_KEY |  | AWS secret key credential |
| AWS_DEFAULT_REGION | us-east-1 | Default AWS region |
| AWS_PROFILE | default | AWS credentials profile |

**Security Best Practices**
Recommended security configurations and practices

- Use IAM roles instead of hardcoded credentials
- Implement least privilege access principles
- Enable AWS CLI MFA when possible
- Regularly rotate access keys
- Use secure credential storage solutions
- Monitor AWS CloudTrail for CLI activities
- Implement proper network security groups
- Enable AWS CLI audit logging

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/aws-cli-v2
- **AWS CLI Documentation**: https://aws.amazon.com/cli/