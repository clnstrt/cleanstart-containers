**Container Documentation for Flux-Helm-Controller-Bitnami-Compat-Fips**

A FIPS-compliant, security-hardened Helm controller container for Flux CD that provides compatibility with Bitnami charts. This container enables secure, automated Helm operations in regulated environments requiring FIPS validation, while maintaining compatibility with Bitnami's extensive chart repository.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/flux-helm-controller-bitnami-compat-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic modules
- Bitnami chart compatibility layer
- Automated Helm operations for Flux CD
- Security-hardened configuration

**Common Use Cases**
Typical scenarios where this container excels

- Regulated enterprise Kubernetes environments
- GitOps-based deployment workflows
- Automated Helm chart management
- Secure continuous delivery pipelines

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/flux-helm-controller-bitnami-compat-fips:latest
```

```bash
docker pull {registry.example.com}/flux-helm-controller-bitnami-compat-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name flux-helm-controller-bitnami-compat-fips-test {registry.example.com}/flux-helm-controller-bitnami-compat-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name flux-helm-controller-bitnami-compat-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/flux-helm-controller-bitnami-compat-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/charts:/charts {registry.example.com}/flux-helm-controller-bitnami-compat-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9440:9440 {registry.example.com}/flux-helm-controller-bitnami-compat-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| HELM_CONTROLLER_CHARTS_PATH | /charts | Path to Helm charts directory |
| HELM_CONTROLLER_NAMESPACE | flux-system | Kubernetes namespace for controller |
| HELM_CONTROLLER_LOG_LEVEL | info | Logging level configuration |
| HELM_CONTROLLER_CONCURRENT | 4 | Number of concurrent reconciles |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Enable RBAC with minimal required permissions
- Configure resource limits and requests
- Implement network policies for controller access
- Regular security scanning of Helm charts
- Monitor controller logs for security events
- Use sealed secrets for sensitive data
- Implement pod security standards

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/flux-helm-controller-bitnami-compat-fips
- **Flux Documentation**: https://fluxcd.io/docs/
- **Helm Documentation**: https://helm.sh/docs/