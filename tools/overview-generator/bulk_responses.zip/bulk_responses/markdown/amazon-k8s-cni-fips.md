**Container Documentation for Amazon-K8S-Cni-Fips**

Amazon Kubernetes CNI FIPS container provides FIPS-validated networking capabilities for Kubernetes clusters. This container implements AWS VPC networking for Kubernetes, enabling native VPC networking and enhanced security features in compliance with Federal Information Processing Standards (FIPS).

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/amazon-k8s-cni-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Native AWS VPC networking integration
- High-performance container networking
- Security-enhanced network policies

**Common Use Cases**
Typical scenarios where this container excels

- Government and regulated industry Kubernetes deployments
- FIPS-compliant cloud environments
- Secure container networking in AWS
- Enterprise Kubernetes clusters requiring FIPS validation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/amazon-k8s-cni-fips:latest
```

```bash
docker pull {registry.example.com}/amazon-k8s-cni-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name amazon-k8s-cni-fips-test {registry.example.com}/amazon-k8s-cni-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name amazon-k8s-cni-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/amazon-k8s-cni-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/amazon-k8s-cni-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/amazon-k8s-cni-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| AWS_VPC_K8S_CNI_LOGLEVEL | DEBUG | Sets the logging level |
| AWS_VPC_ENI_MTU | 9001 | Sets the MTU size |
| AWS_VPC_K8S_CNI_EXTERNALSNAT | false | Configure external SNAT |
| AWS_VPC_K8S_CNI_VETHPREFIX | eni | Prefix for the virtual ethernet devices |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled and validated
- Implement proper IAM roles and permissions
- Enable network policy enforcement
- Regular security patch updates
- Monitor CNI metrics and logs
- Use secure communication channels
- Implement pod security policies
- Regular compliance audits

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_ADMIN", "NET_RAW"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/amazon-k8s-cni-fips