**Container Documentation for Bazel**

Enterprise-ready Bazel build system container optimized for large-scale software development and testing. Features hermetic builds, reproducible outputs, and extensive caching capabilities for efficient CI/CD pipelines and development workflows.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/bazel`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- Hermetic build environment for reproducible builds
- Incremental and parallel build support
- Multi-language build system support
- Extensive caching and build optimization

**Common Use Cases**
Typical scenarios where this container excels

- Large-scale software builds and testing
- Continuous Integration/Continuous Deployment pipelines
- Cross-platform development environments
- Monorepo build management

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/bazel:latest
```

```bash
docker pull registry.example.com/bazel:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name bazel-test registry.example.com/bazel:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name bazel-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  registry.example.com/bazel:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data registry.example.com/bazel:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 registry.example.com/bazel:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| BAZEL_HOME | /home/bazel | Bazel home directory |
| BAZEL_OPTS |  | Additional Bazel command options |
| JAVA_HOME | /usr/lib/jvm/java-11 | Java installation directory |
| PATH | /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin | System PATH configuration |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production (avoid latest)
- Configure resource limits for builds
- Enable read-only root filesystem
- Run as non-root user
- Implement proper cache management
- Regular security updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/bazel