**Container Documentation for Chainguard-Base**

Chainguard-base is a minimalist, security-hardened container base image designed for enterprise containerized applications. It provides a secure foundation for building and deploying cloud-native applications with reduced attack surface, optimized performance, and comprehensive security controls. Ideal for organizations requiring FIPS compliance and enhanced security posture.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/chainguard-base`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Optimized container runtime environment
- Security-hardened base configuration
- Enterprise-ready deployment capabilities
- Multi-architecture support and compatibility

**Common Use Cases**
Typical scenarios where this container excels

- Application deployment and hosting
- Microservices architecture components
- Development and testing environments
- Production workload execution

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/chainguard-base:latest
```

```bash
docker pull {registry.example.com}/chainguard-base:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name chainguard-base-test {registry.example.com}/chainguard-base:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name chainguard-base-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/chainguard-base:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/chainguard-base:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/chainguard-base:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| PATH | /usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin | System PATH configuration |
| HOME | /home/user | User home directory |
| USER | user | Default username |
| SHELL | /bin/sh | Default shell |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production (avoid latest)
- Configure resource limits: memory and CPU constraints
- Enable read-only root filesystem when possible
- Run containers with non-root user (--user 1000:1000)
- Use --security-opt=no-new-privileges flag
- Regularly update container images for security patches
- Implement proper network segmentation
- Monitor container metrics for anomalies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/chainguard-base