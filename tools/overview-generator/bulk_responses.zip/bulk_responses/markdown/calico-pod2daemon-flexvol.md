**Container Documentation for Calico-Pod2Daemon-Flexvol**

Calico Pod2Daemon Flexvol is a critical component of the Calico networking solution that enables flexible volume management for Kubernetes pods. It facilitates communication between pods and the host system for network policy enforcement, providing essential functionality for container networking and security in enterprise Kubernetes deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-pod2daemon-flexvol`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Flexible volume management for Kubernetes pods
- Seamless integration with Calico networking
- Enhanced container-to-host communication
- Network policy enforcement support

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster networking
- Container network policy management
- Multi-tenant network isolation
- Secure pod-to-pod communication

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-pod2daemon-flexvol:latest
```

```bash
docker pull {registry.example.com}/calico-pod2daemon-flexvol:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-pod2daemon-flexvol-test {registry.example.com}/calico-pod2daemon-flexvol:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-pod2daemon-flexvol-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/calico-pod2daemon-flexvol:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/calico-pod2daemon-flexvol:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/calico-pod2daemon-flexvol:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLEXVOL_DIR | /usr/libexec/kubernetes/kubelet-plugins/volume/exec/ | FlexVolume plugin directory |
| LOG_LEVEL | info | Logging level configuration |
| KUBERNETES_SERVICE_HOST |  | Kubernetes API server host |
| KUBERNETES_SERVICE_PORT | 6443 | Kubernetes API server port |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper RBAC policies
- Enable network policy enforcement
- Regular security updates and patches
- Monitor pod-to-pod communication
- Implement network segmentation
- Use secure communication protocols
- Regular security audits

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-pod2daemon-flexvol