**Container Documentation for External-Secrets**

External Secrets Operator is a Kubernetes operator that integrates external secret management systems like AWS Secrets Manager, HashiCorp Vault, Google Secrets Manager, Azure Key Vault and many more. It synchronizes secrets from external APIs into Kubernetes, enabling secure and automated secret management for cloud-native applications.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/external-secrets`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Seamless integration with multiple secret management systems
- Automated secret synchronization with Kubernetes
- Support for multiple cloud providers and platforms
- Template-based secret generation and transformation

**Common Use Cases**
Typical scenarios where this container excels

- Cloud-native application secret management
- Multi-cloud secret synchronization
- Automated credential rotation
- Secure secret distribution in Kubernetes clusters

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/external-secrets:latest
```

```bash
docker pull {registry.example.com}/external-secrets:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name external-secrets-test {registry.example.com}/external-secrets:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name external-secrets-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/external-secrets:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/config:/config {registry.example.com}/external-secrets:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:8080 {registry.example.com}/external-secrets:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| EXTERNAL_SECRETS_NAMESPACE | default | Kubernetes namespace for operation |
| EXTERNAL_SECRETS_METRICS_PORT | 8080 | Metrics endpoint port |
| EXTERNAL_SECRETS_LOG_LEVEL | info | Logging level configuration |
| EXTERNAL_SECRETS_SECRET_STORE |  | Default secret store configuration |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies to limit access to secrets
- Enable encryption for secrets at rest
- Implement proper secret rotation policies
- Use secure communication channels for secret retrieval
- Regular security audits of secret access
- Monitor secret usage patterns
- Implement least privilege access
- Enable audit logging for secret operations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/external-secrets