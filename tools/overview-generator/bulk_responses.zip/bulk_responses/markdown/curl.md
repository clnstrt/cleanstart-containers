**Container Documentation for Curl**

Enterprise-ready curl container image providing secure and efficient HTTP client capabilities for automated data transfer, API testing, and network diagnostics. Features include TLS support, multiple protocol handling, and comprehensive debugging options, optimized for cloud-native environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/curl`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- Comprehensive HTTP/HTTPS client functionality
- Support for multiple protocols including FTP, FTPS, SCP, SFTP, TFTP
- Advanced SSL/TLS capabilities with certificate validation
- Robust proxy support and authentication mechanisms

**Common Use Cases**
Typical scenarios where this container excels

- API testing and integration validation
- Automated file transfers and downloads
- Network diagnostics and debugging
- CI/CD pipeline automation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/curl:latest
```

```bash
docker pull registry.example.com/curl:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name curl-test registry.example.com/curl:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name curl-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  registry.example.com/curl:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data registry.example.com/curl:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 registry.example.com/curl:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CURL_CA_BUNDLE | /etc/ssl/certs/ca-certificates.crt | Custom CA certificate bundle path |
| HTTP_PROXY |  | HTTP proxy server configuration |
| HTTPS_PROXY |  | HTTPS proxy server configuration |
| NO_PROXY |  | Comma-separated list of hosts to exclude from proxy |

**Security Best Practices**
Recommended security configurations and practices

- Always verify SSL certificates in production
- Use specific version tags instead of latest
- Implement proper credential management
- Regular security updates and patches

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/curl