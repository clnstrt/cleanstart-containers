**Container Documentation for Clamav**

ClamAV is an open-source antivirus engine for detecting trojans, viruses, malware, and other malicious threats. This container provides a secure, enterprise-ready deployment of ClamAV with automated virus database updates, real-time file scanning capabilities, and integration options for email servers and file systems.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from Registry.Example Registry.

**Image Path**: `registry.example.com/clamav`
**Registry**: Registry.Example Registry

**Key Features**
Core capabilities and strengths of this container

- Real-time virus scanning and detection
- Automated virus database updates
- Multi-threaded scanner for improved performance
- Integration with email servers and file systems

**Common Use Cases**
Typical scenarios where this container excels

- Email server virus scanning
- File upload malware detection
- Network storage virus scanning
- Automated security pipelines

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull registry.example.com/clamav:latest
```

```bash
docker pull registry.example.com/clamav:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name clamav registry.example.com/clamav:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name clamav-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v /var/lib/clamav:/var/lib/clamav \
  registry.example.com/clamav:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v /var/lib/clamav:/var/lib/clamav registry.example.com/clamav:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 3310:3310 registry.example.com/clamav:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FRESHCLAM_DELAY | 3600 | Delay in seconds between virus database updates |
| MAX_SCAN_SIZE | 100M | Maximum file size to scan |
| MAX_FILE_SIZE | 25M | Maximum size of files to extract |
| MAX_RECURSION | 16 | Maximum archive recursion level |

**Security Best Practices**
Recommended security configurations and practices

- Regularly update virus definitions
- Use read-only filesystem for production
- Configure resource limits appropriately
- Run as non-root user
- Implement proper logging and monitoring
- Use specific version tags in production

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://registry.example.com
- **Container Documentation**: https://registry.example.com/clamav
- **ClamAV Documentation**: https://www.clamav.net/documents