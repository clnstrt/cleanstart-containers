**Container Documentation for Filebeat-Fips**

Filebeat-FIPS is a FIPS 140-2 compliant log file shipper for enterprise environments. This container provides secure log data collection and forwarding capabilities while maintaining compliance with federal security standards. It features automated log harvesting, secure data transmission, and integration with major log analytics platforms.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/filebeat-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant logging operations
- Secure log collection and forwarding
- Automated log harvesting and processing
- Enterprise security compliance support

**Common Use Cases**
Typical scenarios where this container excels

- Federal and government system logging
- Healthcare data compliance monitoring
- Financial services audit logging
- Enterprise security operations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/filebeat-fips:latest
```

```bash
docker pull {registry.example.com}/filebeat-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d \
  --name filebeat-fips \
  -v $(pwd)/filebeat.yml:/usr/share/filebeat/filebeat.yml \
  {registry.example.com}/filebeat-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name filebeat-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v $(pwd)/filebeat.yml:/usr/share/filebeat/filebeat.yml:ro \
  -v $(pwd)/logs:/logs:ro \
  {registry.example.com}/filebeat-fips:latest
```

**Volume Mount**
Mount log directories for monitoring

```bash
docker run -d \
  -v /var/log:/logs:ro \
  -v $(pwd)/filebeat.yml:/usr/share/filebeat/filebeat.yml:ro \
  {registry.example.com}/filebeat-fips:latest
```

**Port Forwarding**
Configure network ports for monitoring

```bash
docker run -d \
  -p 5066:5066 \
  {registry.example.com}/filebeat-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ELASTICSEARCH_HOST | localhost:9200 | Elasticsearch host address |
| ELASTICSEARCH_USERNAME | elastic | Elasticsearch authentication username |
| ELASTICSEARCH_PASSWORD |  | Elasticsearch authentication password |
| KIBANA_HOST | localhost:5601 | Kibana host address |

**Security Best Practices**
Recommended security configurations and practices

- Use FIPS mode for all cryptographic operations
- Implement proper access controls for log files
- Enable TLS for all network communications
- Regular security patches and updates
- Monitor file integrity and access patterns
- Implement proper log rotation policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_BIND_SERVICE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/filebeat-fips
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance