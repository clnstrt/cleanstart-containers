**Container Documentation for Cass-Operator-Fips**

The Cassandra Operator FIPS container provides a FIPS-compliant Kubernetes operator for managing Apache Cassandra clusters in enterprise environments. It automates deployment, scaling, backup, and recovery operations while maintaining FIPS 140-2 compliance for security-sensitive deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cass-operator-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant Cassandra operator implementation
- Automated Cassandra cluster lifecycle management
- Advanced backup and recovery operations
- Kubernetes-native scaling and operations

**Common Use Cases**
Typical scenarios where this container excels

- Managing Cassandra clusters in regulated environments
- Government and military database deployments
- Financial services and healthcare applications
- Enterprise-scale data management

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cass-operator-fips:latest
```

```bash
docker pull {registry.example.com}/cass-operator-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cass-operator-fips-test {registry.example.com}/cass-operator-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cass-operator-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cass-operator-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/cass-operator-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9042:9042 {registry.example.com}/cass-operator-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| OPERATOR_NAME | cassandra-operator | Name of the operator deployment |
| WATCH_NAMESPACE |  | Namespace to watch for custom resources |
| POD_NAME |  | Name of the operator pod |
| LOG_LEVEL | info | Logging level configuration |

**Security Best Practices**
Recommended security configurations and practices

- Implement RBAC policies for operator access
- Enable TLS encryption for all cluster communication
- Configure authentication for Cassandra access
- Regular security audits and compliance checks
- Monitor operator logs for security events
- Use secure secrets management
- Implement network policies
- Regular backup verification

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cass-operator-fips
- **Operator Documentation**: https://{registry.example.com}/docs/cass-operator