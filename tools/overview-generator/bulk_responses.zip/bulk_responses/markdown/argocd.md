**Container Documentation for Argocd**

Argo CD is a declarative, GitOps continuous delivery tool for Kubernetes. It automates the deployment of applications to Kubernetes clusters by monitoring Git repositories and synchronizing the desired state with the actual state in the cluster. Features include automated deployment, application health monitoring, SSO integration, and audit trails.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argocd`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Automated synchronization of Kubernetes manifests from Git repositories
- Web UI for application deployment visualization and management
- Multi-cluster deployment capabilities
- SSO integration and RBAC support

**Common Use Cases**
Typical scenarios where this runtime container excels

- GitOps-based continuous delivery workflows
- Multi-environment Kubernetes deployments
- Application configuration management
- Kubernetes cluster management and monitoring

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argocd:latest
```

```bash
docker pull {registry.example.com}/argocd:v2.8.0
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argocd-dev \
  -p 8080:8080 \
  -v ~/.kube:/home/argocd/.kube \
  {registry.example.com}/argocd:latest
```

**Run Hello World**
Start a basic Argo CD server instance

```bash
docker run --rm -p 8080:8080 {registry.example.com}/argocd:latest argocd-server
```

**Mount Workspace**
Run container with local configuration mounted

```bash
docker run --rm -v $(pwd)/config:/config \
  -v ~/.kube:/home/argocd/.kube \
  {registry.example.com}/argocd:latest
```

**Application Server**
Run Argo CD server with necessary ports

```bash
docker run -d --name argocd-server \
  -p 8080:8080 \
  -p 8083:8083 \
  -v ~/.kube:/home/argocd/.kube \
  {registry.example.com}/argocd:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGOCD_SERVER | localhost:8080 | Argo CD server address |
| KUBECONFIG | /home/argocd/.kube/config | Kubernetes configuration file path |
| ARGOCD_OPTS |  | Additional Argo CD CLI options |
| ARGOCD_TLS_CERTIFICATE_PATH | /app/config/tls/tls.crt | TLS certificate path |

**Security Best Practices**
Recommended security configurations and practices

- Enable SSO integration for authentication
- Implement RBAC policies
- Use TLS for all communications
- Regularly rotate credentials and tokens
- Monitor audit logs
- Use non-root user for container execution
- Enable network policies
- Regular security updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 999
  fsGroup: 999
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo CD Documentation**: https://argo-cd.readthedocs.io/
- **GitHub Repository**: https://github.com/argoproj/argo-cd