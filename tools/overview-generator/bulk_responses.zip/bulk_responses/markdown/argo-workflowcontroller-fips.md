**Container Documentation for Argo-Workflowcontroller-Fips**

Argo Workflow Controller FIPS is a containerized component of the Argo Workflows system, specifically designed for enterprise environments requiring FIPS 140-2 compliance. It manages and orchestrates workflows, handles workflow execution logic, and maintains workflow state while adhering to Federal Information Processing Standards (FIPS).

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argo-workflowcontroller-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 compliant workflow controller
- Enterprise-grade security features and hardening
- Kubernetes-native workflow orchestration
- Scalable workflow management capabilities

**Common Use Cases**
Typical scenarios where this runtime container excels

- Government and regulated industry deployments
- CI/CD pipeline orchestration
- Machine learning workflows
- Data processing pipelines

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argo-workflowcontroller-fips:latest
```

```bash
docker pull {registry.example.com}/argo-workflowcontroller-fips:stable
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-workflowcontroller-fips \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argo-workflowcontroller-fips:latest /bin/sh
```

**Run Hello World**
Execute a simple workflow controller test

```bash
docker run --rm {registry.example.com}/argo-workflowcontroller-fips:latest version
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/etc/argo \
  {registry.example.com}/argo-workflowcontroller-fips:latest \
  --configmap /etc/argo/config.yaml
```

**Application Server**
Run workflow controller with port forwarding

```bash
docker run -d --name argo-workflowcontroller \
  -p 8001:8001 \
  -v $(pwd):/etc/argo \
  {registry.example.com}/argo-workflowcontroller-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGO_NAMESPACE | argo | Kubernetes namespace for Argo operations |
| CONTROLLER_CONFIG_MAP | workflow-controller-configmap | ConfigMap name for controller configuration |
| FIPS_MODE | true | Enable FIPS mode operation |
| KUBELET_PORT | 10250 | Kubelet port for node communication |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC policies for workflow execution
- Enable audit logging for all operations
- Implement network policies for workflow pods
- Regular security updates and vulnerability scanning
- Configure resource quotas and limits
- Use secure communication channels
- Implement proper secrets management
- Enable pod security policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 999
  runAsGroup: 999
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo Workflows Documentation**: https://argoproj.github.io/argo-workflows/
- **FIPS Compliance Guide**: https://csrc.nist.gov/publications/detail/fips/140/2/final