**Container Documentation for Amazon-K8S-Cni**

Amazon Kubernetes CNI plugin for container networking, providing high-performance networking capabilities for Kubernetes clusters. Features include pod networking, network policy enforcement, and optimized IP address management for enterprise Kubernetes deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/amazon-k8s-cni`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- High-performance pod networking implementation
- Integrated IP address management (IPAM)
- Network policy enforcement capabilities
- Kubernetes native networking interface

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster networking configuration
- Container network policy management
- Multi-tenant network isolation
- High-performance container networking

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/amazon-k8s-cni:latest
```

```bash
docker pull {registry.example.com}/amazon-k8s-cni:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name amazon-k8s-cni-test --privileged --network host {registry.example.com}/amazon-k8s-cni:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name amazon-k8s-cni-prod \
  --privileged \
  --network host \
  -v /opt/cni/bin:/opt/cni/bin \
  -v /var/run/kubernetes:/var/run/kubernetes \
  {registry.example.com}/amazon-k8s-cni:latest
```

**Volume Mount**
Mount required directories for CNI operation

```bash
docker run -v /opt/cni/bin:/opt/cni/bin -v /var/run/kubernetes:/var/run/kubernetes {registry.example.com}/amazon-k8s-cni:latest
```

**Port Forwarding**
Network configuration for CNI plugin

```bash
docker run --network host {registry.example.com}/amazon-k8s-cni:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| KUBERNETES_SERVICE_HOST |  | Kubernetes API server hostname |
| KUBERNETES_SERVICE_PORT | 6443 | Kubernetes API server port |
| AWS_VPC_K8S_CNI_LOGLEVEL | DEBUG | Logging level configuration |
| AWS_VPC_ENI_MTU | 9001 | MTU size for network interfaces |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper RBAC policies
- Regular security updates and patches
- Monitor CNI logs for security events
- Configure network policies appropriately
- Secure access to Kubernetes API server
- Implement pod security policies
- Regular audit of network configurations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["NET_ADMIN", "NET_RAW"]
  seLinuxOptions:
    type: container_runtime_t
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/amazon-k8s-cni
- **GitHub Repository**: https://github.com/aws/amazon-vpc-cni-k8s