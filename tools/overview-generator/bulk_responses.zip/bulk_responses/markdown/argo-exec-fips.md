**Container Documentation for Argo-Exec-Fips**

Argo-Exec-Fips is a FIPS 140-2 validated container runtime environment designed for executing Argo workflows in highly regulated enterprise environments. It provides secure execution capabilities with built-in compliance features, audit logging, and enhanced security controls suitable for government, financial, and healthcare sectors.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argo-exec-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configurations
- Integrated audit logging and monitoring
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- Government and military workflow automation
- Healthcare data processing pipelines
- Financial services automation
- Regulated industry compliance workflows

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argo-exec-fips:latest
```

```bash
docker pull {registry.example.com}/argo-exec-fips:latest-dev
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-exec-fips-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argo-exec-fips:latest-dev /bin/sh
```

**Run Hello World**
Execute a simple Hello World program

```bash
docker run --rm {registry.example.com}/argo-exec-fips:latest-dev -c 'echo "Hello, World!"'
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/argo-exec-fips:latest-dev argo-exec-fips --version
```

**Application Server**
Run application with port forwarding

```bash
docker run -d --name argo-exec-fips-app \
  -p 8000:8000 \
  -v $(pwd):/app \
  -w /app \
  {registry.example.com}/argo-exec-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FIPS_MODE | enabled | FIPS mode configuration |
| AUDIT_LEVEL | INFO | Audit logging level |
| ARGO_EXEC_VERSION | latest | Runtime version |
| COMPLIANCE_MODE | strict | Compliance enforcement level |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Configure comprehensive audit logging
- Implement strict access controls
- Regular security updates and vulnerability scanning
- Use read-only filesystems where possible
- Enable all recommended STIG controls
- Configure resource limits and constraints
- Implement secure key management

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo-Exec-Fips Documentation**: https://docs.argo-exec-fips.example.com