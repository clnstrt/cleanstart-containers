**Container Documentation for Docker-Cli-Fips**

FIPS-validated Docker CLI container providing secure container management capabilities for regulated enterprise environments. Features FIPS 140-2 cryptographic modules, STIG-hardened configuration, and enterprise-grade security controls.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/docker-cli-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- STIG-compliant security configuration
- Enterprise-ready container management capabilities
- Multi-architecture support for amd64 and arm64

**Common Use Cases**
Typical scenarios where this container excels

- Government and regulated industry deployments
- Secure container orchestration environments
- Compliance-focused Docker operations
- High-security production workloads

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/docker-cli-fips:latest
```

```bash
docker pull {registry.example.com}/docker-cli-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name docker-cli-fips-test {registry.example.com}/docker-cli-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name docker-cli-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/docker-cli-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/data:/data {registry.example.com}/docker-cli-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:80 {registry.example.com}/docker-cli-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| DOCKER_FIPS_MODE | enabled | Enable/disable FIPS mode |
| DOCKER_CERT_PATH | /certs | Path to TLS certificates |
| DOCKER_TLS_VERIFY | 1 | Enable TLS verification |
| DOCKER_HOST | unix:///var/run/docker.sock | Docker daemon socket |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use TLS for all Docker daemon communications
- Implement strict access controls
- Regular security compliance audits
- Monitor cryptographic operations
- Maintain proper key management
- Follow STIG guidelines
- Regular security patches and updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/docker-cli-fips