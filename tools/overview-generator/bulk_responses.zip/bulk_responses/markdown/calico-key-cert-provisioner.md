**Container Documentation for Calico-Key-Cert-Provisioner**

The Calico Key and Certificate Provisioner container provides automated management of security credentials for Calico networking components in Kubernetes clusters. It handles the generation, distribution, and renewal of TLS certificates and encryption keys required for secure communication between Calico components, ensuring robust network security and compliance in enterprise environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-key-cert-provisioner`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automated TLS certificate management for Calico components
- Secure key generation and distribution
- Certificate lifecycle management and renewal
- Integration with Kubernetes secrets management

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster security configuration
- Calico networking component authentication
- Zero-trust network implementation
- Enterprise security compliance

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-key-cert-provisioner:latest
```

```bash
docker pull {registry.example.com}/calico-key-cert-provisioner:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-key-cert-provisioner-test {registry.example.com}/calico-key-cert-provisioner:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-key-cert-provisioner-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/calico-key-cert-provisioner:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/certs:/certs -v $(pwd)/keys:/keys {registry.example.com}/calico-key-cert-provisioner:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:8080 {registry.example.com}/calico-key-cert-provisioner:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CERT_VALIDITY_PERIOD | 365 | Certificate validity period in days |
| KEY_SIZE | 2048 | RSA key size in bits |
| CERT_OUTPUT_PATH | /certs | Certificate output directory |
| KEY_OUTPUT_PATH | /keys | Key output directory |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper access controls for certificate storage
- Regular rotation of certificates and keys
- Monitor certificate expiration dates
- Secure storage of generated keys
- Regular security audits of certificate usage
- Implementation of certificate revocation procedures
- Backup of certificate and key materials

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  fsGroup: 1000
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-key-cert-provisioner
- **Calico Documentation**: https://docs.projectcalico.org