**Container Documentation for Fluentd-Fips**

FIPS-compliant Fluentd logging agent container optimized for enterprise environments. Features enhanced security, FIPS 140-2 validated cryptographic modules, and comprehensive log management capabilities for regulated industries. Designed for secure log collection, processing, and forwarding in compliance-focused deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/fluentd-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Enhanced security logging and audit capabilities
- Optimized for enterprise log management
- Multi-source log aggregation support

**Common Use Cases**
Typical scenarios where this container excels

- Regulated industry log management
- Secure log aggregation and forwarding
- Compliance-focused logging solutions
- Enterprise-wide log collection

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/fluentd-fips:latest
```

```bash
docker pull {registry.example.com}/fluentd-fips:1.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name fluentd-fips {registry.example.com}/fluentd-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name fluentd-fips \
  --read-only \
  --security-opt=no-new-privileges \
  -v /var/log:/var/log:ro \
  -v /etc/fluentd:/etc/fluentd \
  {registry.example.com}/fluentd-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d \
  -v /var/log:/var/log:ro \
  -v /etc/fluentd:/etc/fluentd \
  {registry.example.com}/fluentd-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d \
  -p 24224:24224 \
  -p 24224:24224/udp \
  {registry.example.com}/fluentd-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| FLUENTD_CONF | fluent.conf | Fluentd configuration file name |
| FLUENT_ELASTICSEARCH_HOST | localhost | Elasticsearch host |
| FLUENT_ELASTICSEARCH_PORT | 9200 | Elasticsearch port |
| FLUENT_ELASTICSEARCH_SCHEME | https | Elasticsearch connection scheme |

**Security Best Practices**
Recommended security configurations and practices

- Use FIPS mode for all cryptographic operations
- Configure secure TLS connections for log forwarding
- Implement proper log rotation and retention policies
- Use read-only mounts for log sources
- Enable audit logging for container operations
- Regular security patch updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 100
  runAsGroup: 101
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
    add: ["NET_BIND_SERVICE"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Fluentd Documentation**: https://docs.fluentd.org
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance