**Container Documentation for Coredns**

CoreDNS is a flexible, extensible DNS server that can serve as the foundation for service discovery in cloud-native environments. It provides DNS services to Kubernetes clusters and supports multiple backends for storing DNS records. CoreDNS is designed to be secure, high-performance, and easily configurable through its plugin architecture.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/coredns`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Plugin-based architecture for extensibility
- Native Kubernetes integration
- High performance DNS server
- Service discovery support

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster DNS service
- Service discovery in microservices
- DNS forwarding and proxying
- Custom DNS resolution rules

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/coredns:latest
```

```bash
docker pull {registry.example.com}/coredns:1.10.1
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name coredns \
  -v $(pwd)/Corefile:/Corefile \
  -p 53:53/udp \
  {registry.example.com}/coredns:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name coredns-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -v $(pwd)/Corefile:/Corefile:ro \
  -p 53:53/udp \
  {registry.example.com}/coredns:latest
```

**Volume Mount**
Mount configuration and zone files

```bash
docker run -v $(pwd)/config:/config:ro \
  -v $(pwd)/zones:/zones:ro \
  {registry.example.com}/coredns:latest
```

**Port Forwarding**
Run with DNS ports exposed

```bash
docker run -p 53:53/udp -p 53:53/tcp {registry.example.com}/coredns:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| COREFILE | /Corefile | Path to CoreDNS configuration file |
| DNS_PORT | 53 | DNS server port |
| PLUGINS_PATH | /plugins | Custom plugins directory |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags in production
- Run as non-root user
- Mount configuration files as read-only
- Enable DNSSEC where appropriate
- Implement proper access controls
- Regular security updates

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    add: ["NET_BIND_SERVICE"]
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **CoreDNS Documentation**: https://coredns.io/manual/toc/
- **GitHub Repository**: https://github.com/coredns/coredns