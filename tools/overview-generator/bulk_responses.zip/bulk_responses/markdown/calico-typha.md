**Container Documentation for Calico-Typha**

Calico-Typha is a specialized component of the Calico networking solution that helps scale Kubernetes clusters by reducing load on the Kubernetes API server. It acts as an intermediary cache and fan-out proxy between Felix agents and the Kubernetes API server, significantly improving cluster performance and reducing API server load in large deployments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-typha`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Efficient API server load reduction
- Optimized data caching and distribution
- Horizontal scaling support
- High-availability configuration options

**Common Use Cases**
Typical scenarios where this container excels

- Large-scale Kubernetes cluster deployments
- High-density node environments
- Multi-tenant cluster configurations
- Enterprise network policy management

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-typha:latest
```

```bash
docker pull {registry.example.com}/calico-typha:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-typha {registry.example.com}/calico-typha:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-typha \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -e TYPHA_LOGSEVERITYSCREEN=info \
  -e TYPHA_PROMETHEUSMETRICSENABLED=true \
  {registry.example.com}/calico-typha:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v /var/run/calico:/var/run/calico {registry.example.com}/calico-typha:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 5473:5473 {registry.example.com}/calico-typha:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| TYPHA_LOGSEVERITYSCREEN | info | Log severity level |
| TYPHA_PROMETHEUSMETRICSENABLED | false | Enable Prometheus metrics |
| TYPHA_HEALTHENABLED | true | Enable health checks |
| TYPHA_DATASTORETYPE | kubernetes | Backend datastore type |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Enable TLS encryption for all communications
- Implement proper RBAC policies
- Regular security updates and patches
- Monitor Typha metrics for anomalies
- Configure resource limits appropriately

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
  capabilities:
    drop: ["ALL"]
  readOnlyRootFilesystem: true
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-typha
- **Calico Documentation**: https://docs.projectcalico.org/reference/typha/