**Container Documentation for Cert-Manager-Startupapicheck-Fips**

A FIPS-compliant container image for cert-manager startup API check functionality. This container performs validation of the cert-manager API installation and ensures proper configuration before deployment. It includes security hardening, FIPS 140-2 compliance, and enterprise-ready features for secure certificate management in regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cert-manager-startupapicheck-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant cryptographic modules
- Automated cert-manager API validation
- Security-hardened configuration
- Enterprise-grade certificate management

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cert-manager deployment validation
- Regulated environment certificate management
- FIPS-compliant infrastructure deployments
- Enterprise PKI infrastructure validation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cert-manager-startupapicheck-fips:latest
```

```bash
docker pull {registry.example.com}/cert-manager-startupapicheck-fips:1.0.0
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cert-manager-check {registry.example.com}/cert-manager-startupapicheck-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cert-manager-check-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cert-manager-startupapicheck-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/cert-config:/etc/cert-manager {registry.example.com}/cert-manager-startupapicheck-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9402:9402 {registry.example.com}/cert-manager-startupapicheck-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CHECK_TIMEOUT | 300 | API check timeout in seconds |
| KUBERNETES_NAMESPACE | cert-manager | Target namespace for cert-manager |
| LOG_LEVEL | info | Logging verbosity level |
| FIPS_MODE | true | Enable FIPS mode |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled in production
- Use specific version tags for deployment
- Implement proper RBAC policies
- Regular security scanning of container images
- Monitor certificate lifecycle events
- Implement network policies for API access
- Use secure communication channels
- Regular audit of certificate management practices

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cert-manager-startupapicheck-fips
- **Cert-Manager Documentation**: https://cert-manager.io/docs/