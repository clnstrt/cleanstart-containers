**Container Documentation for Cert-Manager-Acmesolver**

The cert-manager ACME solver container is a specialized component of the cert-manager ecosystem designed to handle ACME (Automated Certificate Management Environment) challenge solving for automated SSL/TLS certificate issuance and management. It supports various ACME challenge types including HTTP-01 and DNS-01, enabling automated certificate acquisition from ACME-compliant certificate authorities like Let's Encrypt.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cert-manager-acmesolver`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Automated ACME challenge solving for certificate issuance
- Support for HTTP-01 and DNS-01 challenge types
- Integration with major ACME certificate authorities
- Kubernetes-native architecture support

**Common Use Cases**
Typical scenarios where this container excels

- Automated SSL/TLS certificate management
- Domain validation for certificate issuance
- Kubernetes certificate automation
- Let's Encrypt integration

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cert-manager-acmesolver:latest
```

```bash
docker pull {registry.example.com}/cert-manager-acmesolver:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name cert-manager-acmesolver-test {registry.example.com}/cert-manager-acmesolver:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name cert-manager-acmesolver-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/cert-manager-acmesolver:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/challenges:/challenges {registry.example.com}/cert-manager-acmesolver:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8089:8089 {registry.example.com}/cert-manager-acmesolver:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ACME_SERVER_URL | https://acme-v02.api.letsencrypt.org/directory | ACME server endpoint URL |
| CHALLENGE_TYPE | http-01 | ACME challenge type (http-01 or dns-01) |
| DOMAIN_NAME |  | Domain name for certificate request |
| TOKEN_PATH | /tmp/token | Path to store ACME challenge token |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper access controls for challenge tokens
- Secure storage of ACME account credentials
- Regular monitoring of certificate lifecycle
- Implementation of rate limiting for ACME requests
- Proper network security for challenge validation
- Regular security updates and patches
- Audit logging for certificate operations

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cert-manager-acmesolver