**Container Documentation for Calico-Key-Cert-Provisioner-Fips**

The Calico Key Cert Provisioner FIPS container provides automated certificate management and key provisioning for Calico networking components in FIPS-compliant environments. It handles the generation, distribution, and renewal of TLS certificates required for secure communication between Calico components, ensuring compliance with Federal Information Processing Standards (FIPS 140-2).

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-key-cert-provisioner-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant certificate management
- Automated TLS certificate generation and renewal
- Secure key distribution for Calico components
- Integration with enterprise PKI infrastructure

**Common Use Cases**
Typical scenarios where this container excels

- Government and military deployments requiring FIPS compliance
- Enterprise Kubernetes clusters with strict security requirements
- Regulated industry environments (healthcare, finance)
- Zero-trust network implementations

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-key-cert-provisioner-fips:latest
```

```bash
docker pull {registry.example.com}/calico-key-cert-provisioner-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-key-cert-provisioner-fips-test {registry.example.com}/calico-key-cert-provisioner-fips:latest-dev
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-key-cert-provisioner-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  {registry.example.com}/calico-key-cert-provisioner-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v $(pwd)/certs:/etc/calico/certs {registry.example.com}/calico-key-cert-provisioner-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 8080:8080 {registry.example.com}/calico-key-cert-provisioner-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CERT_VALIDITY_PERIOD | 365 | Certificate validity period in days |
| KEY_SIZE | 2048 | RSA key size for certificate generation |
| CA_CERT_PATH | /etc/calico/certs/ca.crt | Path to CA certificate |
| CERT_OUTPUT_PATH | /etc/calico/certs | Output directory for generated certificates |

**Security Best Practices**
Recommended security configurations and practices

- Use FIPS-approved cryptographic modules only
- Implement proper certificate rotation procedures
- Secure storage of private keys and certificates
- Regular security audits and compliance checks
- Monitor certificate expiration dates
- Implement proper access controls for certificate storage
- Use secure communication channels for certificate distribution
- Regular backup of certificate and key material

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  fsGroup: 1000
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-key-cert-provisioner-fips
- **FIPS 140-2 Documentation**: https://csrc.nist.gov/publications/detail/fips/140/2/final