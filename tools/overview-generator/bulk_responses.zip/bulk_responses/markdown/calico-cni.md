**Container Documentation for Calico-Cni**

Calico CNI plugin enables highly scalable and secure network connectivity for containerized applications. It provides a full networking stack for Kubernetes and other container orchestration platforms, offering advanced network policy enforcement, IPAM capabilities, and cross-node networking functionality.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-cni`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- Advanced network policy enforcement
- Scalable IP address management (IPAM)
- Cross-node networking support
- Kubernetes integration

**Common Use Cases**
Typical scenarios where this container excels

- Kubernetes cluster networking
- Network policy enforcement
- Multi-cluster networking
- Container workload isolation

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-cni:latest
```

```bash
docker pull {registry.example.com}/calico-cni:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --privileged --net=host --name calico-cni {registry.example.com}/calico-cni:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-cni-prod \
  --privileged \
  --net=host \
  -v /opt/cni/bin:/opt/cni/bin \
  -v /etc/cni/net.d:/etc/cni/net.d \
  {registry.example.com}/calico-cni:latest
```

**Volume Mount**
Mount required directories for CNI operation

```bash
docker run -v /opt/cni/bin:/opt/cni/bin -v /etc/cni/net.d:/etc/cni/net.d {registry.example.com}/calico-cni:latest
```

**Port Forwarding**
Network configuration for Calico CNI

```bash
docker run --net=host {registry.example.com}/calico-cni:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| CALICO_DATASTORE_TYPE | kubernetes | Backend datastore type |
| KUBERNETES_SERVICE_HOST |  | Kubernetes API server host |
| KUBERNETES_SERVICE_PORT | 6443 | Kubernetes API server port |
| CALICO_IPV4POOL_CIDR | 192.168.0.0/16 | IPv4 pool CIDR |

**Security Best Practices**
Recommended security configurations and practices

- Use specific image tags for production deployments
- Implement proper network policies
- Regularly update Calico CNI for security patches
- Configure appropriate RBAC permissions
- Secure etcd communications with TLS
- Monitor network policy effectiveness
- Implement proper network segmentation
- Use encrypted communication channels

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  privileged: true
  capabilities:
    add: ["NET_ADMIN", "NET_RAW"]
  hostNetwork: true
  hostPID: true
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-cni