**Container Documentation for Cloudnative-Pg-Fips**

CloudNative PostgreSQL FIPS container provides a FIPS 140-2 compliant PostgreSQL database solution optimized for cloud-native environments. This enterprise-ready container includes enhanced security features, automated failover capabilities, and built-in backup and recovery mechanisms, making it ideal for organizations requiring strict compliance and robust database management in containerized environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/cloudnative-pg-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 validated cryptographic modules
- Automated failover and high availability
- Kubernetes-native operations
- Built-in backup and recovery mechanisms

**Common Use Cases**
Typical scenarios where this container excels

- Government and military database deployments
- Financial services applications
- Healthcare data management
- Regulated industry workloads

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/cloudnative-pg-fips:latest
```

```bash
docker pull {registry.example.com}/cloudnative-pg-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -d --name pg-fips -e POSTGRES_PASSWORD=secure_password -p 5432:5432 {registry.example.com}/cloudnative-pg-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name pg-fips-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user postgres \
  -e POSTGRES_PASSWORD=secure_password \
  -e PGDATA=/var/lib/postgresql/data/pgdata \
  -v pg_data:/var/lib/postgresql/data \
  {registry.example.com}/cloudnative-pg-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -d -v pg_data:/var/lib/postgresql/data {registry.example.com}/cloudnative-pg-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -d -p 5433:5432 {registry.example.com}/cloudnative-pg-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| POSTGRES_PASSWORD |  | Required password for PostgreSQL |
| POSTGRES_USER | postgres | PostgreSQL admin user |
| PGDATA | /var/lib/postgresql/data | PostgreSQL data directory |
| POSTGRES_DB | postgres | Default database name |

**Security Best Practices**
Recommended security configurations and practices

- Use strong, unique passwords for database accounts
- Enable SSL/TLS for all connections
- Implement proper access controls and role-based authentication
- Regular security audits and logging
- Keep the container image updated with security patches
- Use network policies to restrict access
- Enable FIPS mode in configuration
- Regular backup and recovery testing

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsUser: 999
  runAsGroup: 999
  fsGroup: 999
  runAsNonRoot: true
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/cloudnative-pg-fips