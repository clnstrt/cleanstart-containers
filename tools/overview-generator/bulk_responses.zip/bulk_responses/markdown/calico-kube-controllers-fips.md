**Container Documentation for Calico-Kube-Controllers-Fips**

Calico Kubernetes Controllers FIPS is a security-hardened container that manages Kubernetes network policies, IP address management, and node lifecycle in compliance with Federal Information Processing Standards (FIPS). It provides essential networking and security controls for enterprise Kubernetes deployments requiring FIPS 140-2 compliance.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/calico-kube-controllers-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this container

- FIPS 140-2 compliant networking controls
- Automated IP address management and allocation
- Kubernetes network policy enforcement
- Node lifecycle management and monitoring

**Common Use Cases**
Typical scenarios where this container excels

- Government and military Kubernetes deployments
- Financial services compliance environments
- Healthcare Kubernetes clusters
- Enterprise security-focused deployments

**Pull Latest Image**
Download the container image from the registry

```bash
docker pull {registry.example.com}/calico-kube-controllers-fips:latest
```

```bash
docker pull {registry.example.com}/calico-kube-controllers-fips:latest-dev
```

**Basic Run**
Run the container with basic configuration

```bash
docker run -it --name calico-controller {registry.example.com}/calico-kube-controllers-fips:latest
```

**Production Deployment**
Deploy with production security settings

```bash
docker run -d --name calico-controller-prod \
  --read-only \
  --security-opt=no-new-privileges \
  --user 1000:1000 \
  -e DATASTORE_TYPE=kubernetes \
  -e ENABLED_CONTROLLERS=node,policy,namespace,serviceaccount,workloadendpoint \
  {registry.example.com}/calico-kube-controllers-fips:latest
```

**Volume Mount**
Mount local directory for persistent data

```bash
docker run -v /var/lib/calico:/var/lib/calico {registry.example.com}/calico-kube-controllers-fips:latest
```

**Port Forwarding**
Run with custom port mappings

```bash
docker run -p 9094:9094 {registry.example.com}/calico-kube-controllers-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| DATASTORE_TYPE | kubernetes | Type of datastore (kubernetes or etcd) |
| ENABLED_CONTROLLERS | node,policy,namespace,serviceaccount,workloadendpoint | Comma-separated list of enabled controllers |
| KUBECONFIG | /etc/calico/kubeconfig | Path to kubeconfig file |
| LOG_LEVEL | info | Logging level (debug, info, warning, error) |

**Security Best Practices**
Recommended security configurations and practices

- Verify FIPS mode is enabled and validated
- Use RBAC policies to restrict controller access
- Enable network policy enforcement
- Implement secure communication channels
- Regular security patch updates
- Monitor controller logs for security events
- Use secure secrets management
- Implement pod security policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Container Documentation**: https://{registry.example.com}/calico-kube-controllers-fips
- **Calico Documentation**: https://docs.projectcalico.org