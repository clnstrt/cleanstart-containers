**Container Documentation for Argo-Events-Fips**

Argo Events FIPS is a FIPS 140-2 compliant event-driven workflow automation framework for Kubernetes. It enables enterprises to trigger workflows and applications based on events from a variety of sources while maintaining compliance with federal security standards. This container provides event-driven dependency management and workflow automation capabilities with enhanced security features for regulated environments.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argo-events-fips`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 compliant event processing
- Native Kubernetes integration
- Event-driven workflow automation
- Enhanced security controls and audit logging

**Common Use Cases**
Typical scenarios where this runtime container excels

- Regulated enterprise environments requiring FIPS compliance
- Event-driven Kubernetes workflow automation
- Cloud-native application deployment triggers
- Automated CI/CD pipeline orchestration

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argo-events-fips:latest
```

```bash
docker pull {registry.example.com}/argo-events-fips:1.0
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-events-fips-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argo-events-fips:latest /bin/sh
```

**Run Hello World**
Execute a simple Hello World event trigger

```bash
docker run --rm {registry.example.com}/argo-events-fips:latest eventbus-controller --version
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/argo-events-fips:latest sensor-controller --version
```

**Application Server**
Run event controller with port forwarding

```bash
docker run -d --name argo-events-controller \
  -p 12000:12000 \
  -v $(pwd):/app \
  -w /app \
  {registry.example.com}/argo-events-fips:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGO_EVENTS_NAMESPACE | argo-events | Kubernetes namespace for Argo Events |
| EVENTBUS_NAME | default | Name of the event bus |
| FIPS_MODE | enabled | FIPS mode configuration |
| LOG_LEVEL | info | Logging verbosity level |

**Security Best Practices**
Recommended security configurations and practices

- Enable FIPS mode in production environments
- Use role-based access control (RBAC)
- Implement event source authentication
- Regular security patches and updates
- Configure audit logging
- Use secure TLS communication
- Implement resource quotas
- Regular security scanning

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo Events Documentation**: https://argoproj.github.io/argo-events/
- **FIPS Compliance Guide**: https://{registry.example.com}/docs/fips-compliance