**Container Documentation for Argocd-Fips-Repo-Server**

ArgoCD FIPS Repo Server is a FIPS-compliant repository server component for ArgoCD, designed for secure continuous delivery in regulated enterprise environments. It provides Git repository management, application manifest processing, and Kubernetes resource handling with FIPS 140-2 validated cryptographic modules.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/argocd-fips-repo-server`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- FIPS 140-2 validated cryptographic modules
- Secure Git repository management
- Kubernetes manifest processing and validation
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- Regulated enterprise GitOps deployments
- Secure continuous delivery pipelines
- Government and defense applications
- Financial services deployment automation

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/argocd-fips-repo-server:latest
```

```bash
docker pull {registry.example.com}/argocd-fips-repo-server:v2.8.0-fips
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argocd-repo-server \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/argocd-fips-repo-server:latest /bin/sh
```

**Run Hello World**
Execute a simple version check

```bash
docker run --rm {registry.example.com}/argocd-fips-repo-server:latest version
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/app -w /app {registry.example.com}/argocd-fips-repo-server:latest repo-server
```

**Application Server**
Run repository server with port forwarding

```bash
docker run -d --name argocd-repo-server \
  -p 8081:8081 \
  -v $(pwd):/app \
  -w /app \
  {registry.example.com}/argocd-fips-repo-server:latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGOCD_REPO_SERVER_PORT | 8081 | Repository server port |
| ARGOCD_REPO_SERVER_LOGFORMAT | text | Log format (text|json) |
| ARGOCD_REPO_SERVER_LOGLEVEL | info | Log level |
| ARGOCD_REPO_SERVER_PARALLELISM_LIMIT | 10 | Parallelism limit for repository operations |

**Security Best Practices**
Recommended security configurations and practices

- Use specific version tags instead of latest
- Configure TLS for all repository connections
- Implement proper access controls
- Regular security updates and vulnerability scanning
- Enable audit logging
- Use SSH keys for Git authentication
- Configure resource limits
- Implement network policies

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 999
  runAsGroup: 999
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **ArgoCD Documentation**: https://argo-cd.readthedocs.io/