**Container Documentation for Argo Workflow (Argo-Workflows-Cli)**

Argo Workflows CLI is a container-native workflow engine for orchestrating parallel jobs on Kubernetes. It enables users to define and run complex workflows and pipelines as sequences of steps or directed acyclic graphs (DAGs). This container provides the command-line interface for managing Argo Workflows, allowing users to create, manage, and monitor workflows directly from their terminal.

📌 **Base Foundation**: Security-hardened, minimal base OS designed for enterprise containerized environments from {Registry.Example} Registry.

**Image Path**: `{registry.example.com}/Argo Workflow (argo-workflows-cli)`
**Registry**: {Registry.Example} Registry

**Key Features**
Core capabilities and strengths of this runtime container

- Command-line interface for Argo Workflows management
- Native Kubernetes integration
- Support for complex workflow orchestration
- Enterprise-grade security features and hardening

**Common Use Cases**
Typical scenarios where this runtime container excels

- CI/CD pipeline automation
- Machine learning workflows
- Data processing pipelines
- Infrastructure automation

**Pull Commands**
Download the runtime container images

```bash
docker pull {registry.example.com}/Argo Workflow (argo-workflows-cli):latest
```

```bash
docker pull {registry.example.com}/Argo Workflow (argo-workflows-cli):latest-dev
```

**Interactive Development**
Start interactive session for development

```bash
docker run -it --name argo-workflows-cli-dev \
  -v $(pwd):/workspace \
  -w /workspace \
  {registry.example.com}/Argo Workflow (argo-workflows-cli):latest-dev /bin/sh
```

**Run Hello World**
Execute a simple workflow

```bash
docker run --rm {registry.example.com}/Argo Workflow (argo-workflows-cli):latest-dev argo submit --watch hello-world.yaml
```

**Mount Workspace**
Run container with local workspace mounted

```bash
docker run --rm -v $(pwd):/workflows -w /workflows {registry.example.com}/Argo Workflow (argo-workflows-cli):latest-dev argo list
```

**Application Server**
Run Argo server with port forwarding

```bash
docker run -d --name argo-workflows \
  -p 2746:2746 \
  -v ~/.kube:/root/.kube \
  {registry.example.com}/Argo Workflow (argo-workflows-cli):latest
```

**Environment Variables**
Configuration options available through environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| ARGO_SERVER | localhost:2746 | Argo Workflows API server address |
| KUBECONFIG | /root/.kube/config | Kubernetes configuration file path |
| ARGO_NAMESPACE | argo | Kubernetes namespace for Argo |
| ARGO_TOKEN |  | Authentication token for Argo server |

**Security Best Practices**
Recommended security configurations and practices

- Use RBAC for access control
- Enable audit logging
- Implement workflow isolation
- Regular security updates
- Use secure service accounts
- Configure resource quotas
- Enable network policies
- Use secrets management

**Kubernetes Security Context**
Recommended security context for Kubernetes deployments

```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

**Documentation Resources**
Essential links and resources for further information

- **Container Registry**: https://{registry.example.com}
- **Argo Workflows Documentation**: https://argoproj.github.io/argo-workflows/